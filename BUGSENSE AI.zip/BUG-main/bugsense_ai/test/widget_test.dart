import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:bugsense_ai/main.dart';
import 'package:bugsense_ai/models/repo_model.dart';
import 'package:bugsense_ai/models/user_model.dart';
import 'package:bugsense_ai/screens/repositories_screen.dart';

void main() {
  testWidgets('App renders BugSense AI title and skeleton tag', (WidgetTester tester) async {
    await tester.pumpWidget(const BugSenseApp());
    await tester.pump();

    expect(find.text('BugSense AI'), findsAtLeastNWidgets(1));
    expect(find.text('Phase 1 — Skeleton'), findsOneWidget);
    expect(find.text('Sign in with GitHub'), findsOneWidget);
  });

  test('GitHubUser model parses JSON correctly', () {
    final json = {
      'login': 'testuser',
      'name': 'Test User',
      'avatar_url': 'https://avatars.githubusercontent.com/u/12345',
      'bio': 'Software engineer and Flutter enthusiast',
      'public_repos': 12,
      'followers': 42,
      'html_url': 'https://github.com/testuser',
    };

    final user = GitHubUser.fromJson(json);
    expect(user.login, 'testuser');
    expect(user.name, 'Test User');
    expect(user.publicRepos, 12);
    expect(user.followers, 42);
    expect(user.avatarUrl, 'https://avatars.githubusercontent.com/u/12345');
  });

  test('GitHubRepo model parses JSON correctly', () {
    final json = {
      'id': 98765,
      'name': 'bugsense_ai',
      'full_name': 'testuser/bugsense_ai',
      'description': 'AI-assisted bug tracking',
      'language': 'Dart',
      'stargazers_count': 150,
      'open_issues_count': 5,
      'forks_count': 20,
      'private': false,
      'owner': {'login': 'testuser'},
      'html_url': 'https://github.com/testuser/bugsense_ai',
    };

    final repo = GitHubRepo.fromJson(json);
    expect(repo.id, 98765);
    expect(repo.name, 'bugsense_ai');
    expect(repo.fullName, 'testuser/bugsense_ai');
    expect(repo.language, 'Dart');
    expect(repo.stargazersCount, 150);
    expect(repo.openIssuesCount, 5);
    expect(repo.isPrivate, false);
    expect(repo.ownerLogin, 'testuser');
  });

  testWidgets('RepositoriesScreen displays user header and search bar', (WidgetTester tester) async {
    const user = GitHubUser(
      login: 'surya6246',
      name: 'Surya',
      publicRepos: 0,
      followers: 1,
    );

    await tester.pumpWidget(
      MaterialApp(
        home: RepositoriesScreen(
          user: user,
          onSignOut: () {},
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Surya'), findsOneWidget);
    expect(find.text('@surya6246'), findsOneWidget);
    expect(find.byType(TextField), findsOneWidget);
  });
}
