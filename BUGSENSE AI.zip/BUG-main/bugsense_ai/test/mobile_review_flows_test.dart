import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:bugsense_ai/models/adaptive_models.dart';
import 'package:bugsense_ai/screens/mobile_review_screen.dart';

void main() {
  group('MobileReviewScreen - Human-in-the-Loop Review Flows', () {
    final mockIssue = {
      'number': 202,
      'title': 'Race condition in cache invalidation',
      'body': 'Concurrent reads cause stale data after write',
      'state': 'open',
      'labels': ['concurrency', 'bug'],
    };

    AdaptiveRoutingResult buildMockResult({
      String systemStatus = 'REQUIRES_HUMAN_REVIEW',
      double systemConfidence = 0.72,
    }) {
      return AdaptiveRoutingResult(
        status: 'completed',
        route: 'STANDARD',
        routePlan: const RoutePlan(
          route: 'STANDARD',
          complexityScore: 0.50,
          confidenceGate: 0.65,
          rationale: 'Moderate complexity concurrency issue',
        ),
        classification: const ClassificationResult(
          category: 'Concurrency',
          severity: 'Medium',
          confidence: 0.88,
        ),
        resolution: const ResolutionResult(
          fixDescription: 'Apply Mutex lock around cache invalidation block',
          confidence: 0.78,
          codeSuggestions: [
            CodeSuggestion(
              fileOrComponent: 'lib/cache_store.dart',
              codeSnippet: 'await _lock.synchronized(() async {\n  _store.clear();\n});',
              explanation: 'Synchronize cache clear operation',
            ),
          ],
          implementationStrategy: ['Wrap in Mutex', 'Run concurrency unit test'],
          testingRecommendations: ['Run 1000 concurrent iterations'],
        ),
        evidenceReport: const EvidenceReport(
          verdict: 'WEAK',
          evidenceScore: 0.68,
          verifiedClaimsCount: 2,
          unverifiedClaimsCount: 1,
        ),
        systemConfidenceReport: ConfidenceReport(
          systemConfidence: systemConfidence,
          systemStatus: systemStatus,
          confidenceBreakdown: const {
            'llm_self_confidence': 0.78,
            'evidence_validator_score': 0.68,
            'rag_avg_similarity': 0.70,
            'inverse_complexity': 0.50,
          },
        ),
        stagesExecuted: const ['classifier', 'root_cause', 'resolver', 'evidence', 'confidence'],
      );
    }

    testWidgets('Approve Flow: enables PR deploy only after explicit human sign-off', (tester) async {
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: buildMockResult(systemStatus: 'REQUIRES_HUMAN_REVIEW'),
          ),
        ),
      );

      // Verify human review required state
      expect(find.text('HUMAN REVIEW REQUIRED'), findsOneWidget);
      expect(find.text('Authorize & Deploy PR'), findsOneWidget);

      final deployBtn = tester.widget<FilledButton>(find.byKey(const Key('btn-deploy-pr')));
      expect(deployBtn.onPressed, isNull, reason: 'Deploy button must be disabled before human approval');

      // Check the sign-off checkbox
      final checkboxFinder = find.byKey(const Key('checkbox-human-approval'));
      expect(checkboxFinder, findsOneWidget);
      await tester.tap(checkboxFinder);
      await tester.pumpAndSettle();

      // Deploy button should now be enabled
      final enabledDeployBtn = tester.widget<FilledButton>(find.byKey(const Key('btn-deploy-pr')));
      expect(enabledDeployBtn.onPressed, isNotNull, reason: 'Deploy button must be enabled after human approval');
    });

    testWidgets('Edit Flow: allows engineer to customize code snippet and displays refinement badge', (tester) async {
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: buildMockResult(systemStatus: 'READY_FOR_PR', systemConfidence: 0.90),
          ),
        ),
      );

      // Verify original snippet is present
      expect(find.text('lib/cache_store.dart'), findsOneWidget);
      expect(find.byKey(const Key('btn-edit-snippet-0')), findsOneWidget);

      // Tap Edit button
      await tester.tap(find.byKey(const Key('btn-edit-snippet-0')));
      await tester.pumpAndSettle();

      // Verify dialog is displayed
      expect(find.byType(AlertDialog), findsOneWidget);
      expect(find.text('Refine: lib/cache_store.dart'), findsOneWidget);
      expect(find.byKey(const Key('input-edit-code')), findsOneWidget);
      expect(find.byKey(const Key('input-edit-explanation')), findsOneWidget);

      // Enter refined code snippet
      await tester.enterText(
        find.byKey(const Key('input-edit-code')),
        'await _lock.synchronized(() async {\n  _store.clear();\n  _invalidationCounter++;\n});',
      );
      await tester.enterText(
        find.byKey(const Key('input-edit-explanation')),
        'Added invalidation counter to synchronized block',
      );
      await tester.pump();

      // Tap Apply Changes
      await tester.tap(find.byKey(const Key('btn-apply-edit')));
      await tester.pumpAndSettle();

      // Verify dialog dismissed
      expect(find.byType(AlertDialog), findsNothing);

      // Verify Hero Gauge now shows "Manually Refined" badge
      expect(find.text('Manually Refined'), findsWidgets);

      // Verify PR Gate card shows "Resolution refined by engineer" banner
      expect(find.byKey(const Key('banner-manually-refined')), findsOneWidget);

      // Verify updated explanation in snippet card
      expect(find.text('Added invalidation counter to synchronized block'), findsOneWidget);
    });

    testWidgets('Reject Flow: dismissing fix permanently locks PR Gate and records reason with undo support', (tester) async {
      tester.view.physicalSize = const Size(800, 1600);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: buildMockResult(systemStatus: 'READY_FOR_PR', systemConfidence: 0.90),
          ),
        ),
      );

      // Initially deploy button is present
      expect(find.byKey(const Key('btn-deploy-pr')), findsOneWidget);
      expect(find.byKey(const Key('btn-reject-fix')), findsOneWidget);

      // Tap Reject button
      await tester.tap(find.byKey(const Key('btn-reject-fix')));
      await tester.pumpAndSettle();

      // Verify Reject Dialog is shown
      expect(find.byType(AlertDialog), findsOneWidget);
      expect(find.descendant(of: find.byType(AlertDialog), matching: find.text('Reject Proposed Fix')), findsOneWidget);
      expect(find.text('Incorrect Root Cause'), findsOneWidget);
      expect(find.text('Hallucinated Code'), findsOneWidget);

      // Enter optional feedback notes
      await tester.enterText(
        find.byKey(const Key('input-rejection-notes')),
        'The bug is in the HTTP client, not the local cache store.',
      );
      await tester.pump();

      // Tap Confirm Reject
      await tester.tap(find.byKey(const Key('btn-confirm-rejection')));
      await tester.pumpAndSettle();

      // Verify Rejection Status Card is now active
      expect(find.byKey(const Key('card-rejection-status')), findsOneWidget);
      expect(find.text('Resolution Dismissed & Gate Locked'), findsOneWidget);
      expect(find.text('Reason: Incorrect Root Cause'), findsOneWidget);
      expect(find.text('Notes: The bug is in the HTTP client, not the local cache store.'), findsOneWidget);

      // Verify PR Deploy button is LOCKED OUT (removed/replaced by rejection status)
      expect(find.byKey(const Key('btn-deploy-pr')), findsNothing);

      // Verify Hero Gauge shows Rejected badge
      expect(find.text('Rejected: Incorrect Root Cause'), findsOneWidget);

      // Test Undo Rejection
      expect(find.byKey(const Key('btn-undo-rejection')), findsOneWidget);
      await tester.tap(find.byKey(const Key('btn-undo-rejection')));
      await tester.pumpAndSettle();

      // Verify PR gate is unlocked and deploy button returns
      expect(find.byKey(const Key('card-rejection-status')), findsNothing);
      expect(find.byKey(const Key('btn-deploy-pr')), findsOneWidget);
    });
  });
}
