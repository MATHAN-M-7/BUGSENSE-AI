import 'package:flutter_test/flutter_test.dart';

import 'package:bugsense_ai/models/analysis_models.dart';

void main() {
  group('ClassificationResult Model Tests', () {
    test('ClassificationResult parses full backend JSON correctly', () {
      final json = {
        'category': 'Bug',
        'severity': 'Critical',
        'confidence': 0.95,
        'evidence_summary': 'Memory leak causing OutOfMemoryError in ImageLoader.',
        'analyzed_by': 'classifier_agent_v1',
        'model': 'gemini-1.5-flash',
        'rag_context': [
          {'issue_number': 42, 'title': 'Bitmap memory leak'}
        ],
      };

      final result = ClassificationResult.fromJson(json);

      expect(result.category, 'Bug');
      expect(result.severity, 'Critical');
      expect(result.confidence, 0.95);
      expect(result.evidenceSummary, 'Memory leak causing OutOfMemoryError in ImageLoader.');
      expect(result.analyzedBy, 'classifier_agent_v1');
      expect(result.model, 'gemini-1.5-flash');
      expect(result.ragContext.length, 1);
    });

    test('ClassificationResult handles empty/missing fields gracefully', () {
      final result = ClassificationResult.fromJson({});

      expect(result.category, 'Unknown');
      expect(result.severity, 'Unknown');
      expect(result.confidence, 0.0);
      expect(result.evidenceSummary, '');
      expect(result.analyzedBy, '');
      expect(result.model, '');
      expect(result.ragContext, isEmpty);
    });

    test('ClassificationResult.toPriorJson serializes for pipeline chaining', () {
      const result = ClassificationResult(
        category: 'Bug',
        severity: 'Critical',
        confidence: 0.9,
        evidenceSummary: 'Crash on login',
      );

      final prior = result.toPriorJson();

      expect(prior['category'], 'Bug');
      expect(prior['severity'], 'Critical');
      expect(prior['evidence_summary'], 'Crash on login');
      expect(prior.containsKey('confidence'), false);
    });
  });

  group('RootCauseResult Model Tests', () {
    test('RootCauseResult parses full backend JSON correctly', () {
      final json = {
        'probable_cause': 'Bitmaps retain strong references without cache eviction policy.',
        'affected_components': ['ImageLoader', 'BitmapCache', 'FeedAdapter'],
        'reproduction_steps': [
          'Open feed screen',
          'Scroll through 50 images rapidly',
          'Observe OOM crash',
        ],
        'investigation_areas': [
          'Check ImageLoader.bitmapCache implementation',
          'Verify Bitmap.recycle() calls',
        ],
        'confidence': 0.88,
        'related_patterns': 'Unbounded in-memory bitmap cache',
        'analysis_summary': 'Strong reference accumulation leads to heap exhaustion.',
        'analyzed_by': 'root_cause_agent_v1',
        'model': 'gemini-1.5-flash',
        'rag_context': [],
      };

      final result = RootCauseResult.fromJson(json);

      expect(result.probableCause, contains('strong references'));
      expect(result.affectedComponents, ['ImageLoader', 'BitmapCache', 'FeedAdapter']);
      expect(result.reproductionSteps.length, 3);
      expect(result.investigationAreas.length, 2);
      expect(result.confidence, 0.88);
      expect(result.relatedPatterns, 'Unbounded in-memory bitmap cache');
      expect(result.analysisSummary, contains('heap exhaustion'));
      expect(result.analyzedBy, 'root_cause_agent_v1');
      expect(result.ragContext, isEmpty);
    });

    test('RootCauseResult handles empty/missing fields gracefully', () {
      final result = RootCauseResult.fromJson({});

      expect(result.probableCause, '');
      expect(result.affectedComponents, isEmpty);
      expect(result.reproductionSteps, isEmpty);
      expect(result.investigationAreas, isEmpty);
      expect(result.confidence, 0.0);
      expect(result.relatedPatterns, '');
      expect(result.analysisSummary, '');
    });

    test('RootCauseResult.toPriorJson serializes for pipeline chaining', () {
      const result = RootCauseResult(
        probableCause: 'Unbounded cache',
        affectedComponents: ['ImageLoader'],
        investigationAreas: ['Cache size limit'],
        confidence: 0.9,
        analysisSummary: 'Memory leak in cache',
      );

      final prior = result.toPriorJson();

      expect(prior['probable_cause'], 'Unbounded cache');
      expect(prior['affected_components'], ['ImageLoader']);
      expect(prior['investigation_areas'], ['Cache size limit']);
      expect(prior['analysis_summary'], 'Memory leak in cache');
    });
  });

  group('ResolutionResult Model Tests', () {
    test('ResolutionResult parses full backend JSON with CodeSuggestions correctly', () {
      final json = {
        'fix_description': 'Implement LruCache with maximum memory budget and SoftReferences.',
        'code_suggestions': [
          {
            'file_or_component': 'ImageLoader.java',
            'code_snippet': 'LruCache<String, Bitmap> cache = new LruCache<>(maxMemory / 8);',
            'explanation': 'Constrain cache to 1/8th of available heap memory.',
          },
        ],
        'implementation_strategy': [
          'Replace HashMap with LruCache',
          'Override sizeOf() to count Bitmap byte size',
          'Add trimMemory() listener',
        ],
        'testing_recommendations': [
          'Run memory profiler while scrolling image list',
          'Stress test with 200 large images',
        ],
        'risk_assessment': 'Low risk — well-established pattern for image caching.',
        'estimated_effort': 'Small',
        'confidence': 0.92,
        'resolution_summary': 'Replace unbounded map with LRU bitmap cache.',
        'analyzed_by': 'resolution_agent_v1',
        'model': 'gemini-1.5-flash',
        'rag_context': [],
      };

      final result = ResolutionResult.fromJson(json);

      expect(result.fixDescription, contains('LruCache'));
      expect(result.codeSuggestions.length, 1);
      expect(result.codeSuggestions.first.fileOrComponent, 'ImageLoader.java');
      expect(result.codeSuggestions.first.codeSnippet, contains('LruCache'));
      expect(result.codeSuggestions.first.explanation, contains('1/8th'));
      expect(result.implementationStrategy.length, 3);
      expect(result.testingRecommendations.length, 2);
      expect(result.riskAssessment, contains('Low risk'));
      expect(result.estimatedEffort, 'Small');
      expect(result.confidence, 0.92);
      expect(result.resolutionSummary, contains('LRU bitmap cache'));
      expect(result.analyzedBy, 'resolution_agent_v1');
    });

    test('ResolutionResult handles empty/missing fields gracefully', () {
      final result = ResolutionResult.fromJson({});

      expect(result.fixDescription, '');
      expect(result.codeSuggestions, isEmpty);
      expect(result.implementationStrategy, isEmpty);
      expect(result.testingRecommendations, isEmpty);
      expect(result.riskAssessment, '');
      expect(result.estimatedEffort, '');
      expect(result.confidence, 0.0);
      expect(result.resolutionSummary, '');
    });
  });
}
