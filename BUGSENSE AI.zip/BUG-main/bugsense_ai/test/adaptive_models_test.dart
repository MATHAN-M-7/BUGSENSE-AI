import 'package:flutter_test/flutter_test.dart';

import 'package:bugsense_ai/models/adaptive_models.dart';

void main() {
  group('Phase 4 Adaptive Models Tests', () {
    test('ComplexityReport parses JSON correctly', () {
      final json = {
        'complexity_score': 0.75,
        'complexity_level': 'High',
        'signals': {
          'description_complexity': 0.8,
          'stack_trace_present': 1.0,
          'referenced_files': 0.5,
        },
        'analyzer_version': 'complexity_analyzer_v1',
      };

      final report = ComplexityReport.fromJson(json);

      expect(report.complexityScore, 0.75);
      expect(report.complexityLevel, 'High');
      expect(report.signals['stack_trace_present'], 1.0);
      expect(report.signals['description_complexity'], 0.8);
      expect(report.analyzerVersion, 'complexity_analyzer_v1');
    });

    test('RoutePlan parses JSON correctly', () {
      final json = {
        'route': 'DEEP_INVESTIGATION',
        'complexity_score': 0.72,
        'confidence_gate': 0.70,
        'recommended_agents': [
          'classifier_agent',
          'root_cause_agent',
          'resolution_agent'
        ],
        'rag_strategy': {'mode': 'expanded', 'k': 5},
        'rationale': 'High complexity stack trace requires deep analysis',
        'planning_latency_ms': 3.5,
      };

      final plan = RoutePlan.fromJson(json);

      expect(plan.route, 'DEEP_INVESTIGATION');
      expect(plan.complexityScore, 0.72);
      expect(plan.confidenceGate, 0.70);
      expect(plan.recommendedAgents.length, 3);
      expect(plan.ragStrategy['mode'], 'expanded');
      expect(plan.rationale, contains('High complexity'));
      expect(plan.planningLatencyMs, 3.5);
    });

    test('EvidenceReport parses JSON correctly', () {
      final json = {
        'verdict': 'SUFFICIENT',
        'evidence_score': 0.88,
        'verified_claims_count': 5,
        'unverified_claims_count': 1,
        'verified_claims': ['Claim A verified in logs', 'Claim B verified in trace'],
        'unverified_claims': ['Claim C'],
        'recommendations': ['Add regression test for edge case'],
      };

      final evidence = EvidenceReport.fromJson(json);

      expect(evidence.verdict, 'SUFFICIENT');
      expect(evidence.evidenceScore, 0.88);
      expect(evidence.verifiedClaimsCount, 5);
      expect(evidence.unverifiedClaimsCount, 1);
      expect(evidence.recommendations, contains('Add regression test for edge case'));
    });

    test('ConfidenceReport parses JSON and getters work', () {
      final json = {
        'system_confidence': 0.91,
        'system_status': 'READY_FOR_PR',
        'confidence_breakdown': {
          'llm_self_confidence': 0.90,
          'evidence_validator_score': 0.92,
          'rag_avg_similarity': 0.85,
          'inverse_complexity': 0.80,
        },
        'penalties_applied': [],
        'evaluated_at': '2026-09-07T16:00:00Z',
      };

      final conf = ConfidenceReport.fromJson(json);

      expect(conf.systemConfidence, 0.91);
      expect(conf.systemStatus, 'READY_FOR_PR');
      expect(conf.isReadyForPr, true);
      expect(conf.requiresHumanReview, false);
      expect(conf.confidenceBreakdown['llm_self_confidence'], 0.90);
      expect(conf.penaltiesApplied, isEmpty);
    });

    test('ConfidenceReport handles penalty status correctly', () {
      final json = {
        'system_confidence': 0.42,
        'system_status': 'LOW_CONFIDENCE',
        'confidence_breakdown': {
          'llm_self_confidence': 0.70,
          'evidence_validator_score': 0.20,
        },
        'penalties_applied': ['Penalty: INSUFFICIENT evidence verdict (x0.50)'],
      };

      final conf = ConfidenceReport.fromJson(json);

      expect(conf.systemConfidence, 0.42);
      expect(conf.systemStatus, 'LOW_CONFIDENCE');
      expect(conf.isLowConfidence, true);
      expect(conf.penaltiesApplied.length, 1);
    });

    test('AdaptiveRoutingResult parses full pipeline output', () {
      final json = {
        'status': 'completed',
        'route': 'FAST_TRACK',
        'route_plan': {
          'route': 'FAST_TRACK',
          'complexity_score': 0.15,
          'confidence_gate': 0.50,
          'recommended_agents': ['classifier_agent'],
          'rationale': 'Trivial doc issue',
        },
        'classification': {
          'category': 'Documentation',
          'severity': 'Low',
          'confidence': 0.98,
        },
        'system_confidence_report': {
          'system_confidence': 0.89,
          'system_status': 'READY_FOR_PR',
        },
        'stages_executed': ['classifier_agent', 'evidence_validator', 'confidence_engine'],
        'adaptation_log': [
          {'action': 'STAGE_SKIPPED', 'reason': 'Defect root cause not applicable'}
        ],
      };

      final result = AdaptiveRoutingResult.fromJson(json);

      expect(result.status, 'completed');
      expect(result.route, 'FAST_TRACK');
      expect(result.routePlan?.complexityScore, 0.15);
      expect(result.classification?.category, 'Documentation');
      expect(result.systemConfidenceReport?.isReadyForPr, true);
      expect(result.stagesExecuted.length, 3);
      expect(result.adaptationLog.length, 1);
    });

    test('PullRequestResult parses response correctly', () {
      final json = {
        'status': 'success',
        'pr_url': 'https://github.com/testowner/testrepo/pull/42',
        'pr_number': 42,
        'branch': 'bugsense/issue-1-123456789',
      };

      final pr = PullRequestResult.fromJson(json);

      expect(pr.status, 'success');
      expect(pr.prUrl, 'https://github.com/testowner/testrepo/pull/42');
      expect(pr.prNumber, 42);
      expect(pr.branch, 'bugsense/issue-1-123456789');
    });
  });
}
