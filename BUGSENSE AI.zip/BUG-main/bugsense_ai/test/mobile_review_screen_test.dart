import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:bugsense_ai/models/adaptive_models.dart';
import 'package:bugsense_ai/screens/mobile_review_screen.dart';

void main() {
  group('MobileReviewScreen Widget Tests', () {
    final mockIssue = {
      'number': 101,
      'title': 'NullPointerException in ImageDownloader',
      'body': 'App crashes when downloading large assets',
      'state': 'open',
      'labels': ['bug', 'crash'],
    };

    final mockResultReadyForPr = AdaptiveRoutingResult(
      status: 'completed',
      route: 'STANDARD',
      routePlan: const RoutePlan(
        route: 'STANDARD',
        complexityScore: 0.45,
        confidenceGate: 0.60,
        recommendedAgents: ['classifier_agent', 'root_cause_agent', 'resolution_agent'],
        rationale: 'Moderate defect requires standard multi-agent pipeline',
        planningLatencyMs: 2.8,
      ),
      classification: const ClassificationResult(
        category: 'Bug',
        severity: 'High',
        confidence: 0.94,
      ),
      resolution: const ResolutionResult(
        fixDescription: 'Add null check before accessing bitmap decoder',
        confidence: 0.92,
        codeSuggestions: [
          CodeSuggestion(
            fileOrComponent: 'ImageDownloader.java',
            codeSnippet: 'if (asset == null) return null;',
            explanation: 'Guards against null asset dereference',
          ),
        ],
        implementationStrategy: ['Verify asset before decoding', 'Add regression test'],
        testingRecommendations: ['Test null URL handling'],
      ),
      evidenceReport: const EvidenceReport(
        verdict: 'SUFFICIENT',
        evidenceScore: 0.90,
        verifiedClaimsCount: 4,
        unverifiedClaimsCount: 0,
        recommendations: ['Check related caching layer'],
      ),
      systemConfidenceReport: const ConfidenceReport(
        systemConfidence: 0.89,
        systemStatus: 'READY_FOR_PR',
        confidenceBreakdown: {
          'llm_self_confidence': 0.92,
          'evidence_validator_score': 0.90,
          'rag_avg_similarity': 0.82,
          'inverse_complexity': 0.55,
        },
      ),
      stagesExecuted: [
        'classifier_agent',
        'root_cause_agent',
        'resolution_agent',
        'evidence_validator',
        'confidence_engine',
      ],
      adaptationLog: [
        {'action': 'GATE_PASSED', 'reason': 'Root cause confidence 0.88 >= 0.60 gate'}
      ],
    );

    testWidgets('Renders executive confidence gauge, badges and PR Gate button', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: mockResultReadyForPr,
          ),
        ),
      );

      // Verify title and issue info
      expect(find.text('Issue #101 Review'), findsOneWidget);
      expect(find.text('NullPointerException in ImageDownloader'), findsOneWidget);

      // Verify Confidence Gauge and Badge
      expect(find.text('89%'), findsOneWidget);
      expect(find.text('READY FOR PR'), findsOneWidget);
      expect(find.text('Route: STANDARD'), findsOneWidget);
      expect(find.text('Complexity: Medium'), findsOneWidget);
      expect(find.text('Evidence: SUFFICIENT'), findsOneWidget);

      // Verify Fix & PR Gate Tab components
      expect(find.text('Safe PR Gate Status'), findsOneWidget);
      expect(find.text('Deploy Pull Request'), findsOneWidget);
      expect(find.text('Recommended Fix'), findsOneWidget);
      expect(find.text('Add null check before accessing bitmap decoder'), findsOneWidget);
      expect(find.text('ImageDownloader.java'), findsOneWidget);
    });

    testWidgets('Renders human sign-off checkbox when REQUIRES_HUMAN_REVIEW', (tester) async {
      final mockResultNeedsReview = AdaptiveRoutingResult(
        status: 'completed',
        route: 'DEEP_INVESTIGATION',
        routePlan: const RoutePlan(
          route: 'DEEP_INVESTIGATION',
          complexityScore: 0.78,
          confidenceGate: 0.70,
          rationale: 'Deep investigation required',
        ),
        resolution: const ResolutionResult(
          fixDescription: 'Complex refactor needed',
          confidence: 0.65,
        ),
        systemConfidenceReport: const ConfidenceReport(
          systemConfidence: 0.68,
          systemStatus: 'REQUIRES_HUMAN_REVIEW',
          penaltiesApplied: ['Penalty: WEAK evidence verdict (x0.80)'],
        ),
      );

      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: mockResultNeedsReview,
          ),
        ),
      );

      expect(find.text('68%'), findsOneWidget);
      expect(find.text('HUMAN REVIEW REQUIRED'), findsOneWidget);
      expect(
        find.text('I have reviewed the patch & authorize opening a Pull Request'),
        findsOneWidget,
      );
      expect(find.text('Authorize & Deploy PR'), findsOneWidget);
    });

    testWidgets('Switches tabs to Confidence & Evidence and Route Audit', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: MobileReviewScreen(
            owner: 'testorg',
            repo: 'testrepo',
            issue: mockIssue,
            initialResult: mockResultReadyForPr,
          ),
        ),
      );

      // Tap Evidence tab
      await tester.tap(find.text('Evidence'));
      await tester.pumpAndSettle();

      expect(find.text('Confidence Signal Composition'), findsOneWidget);
      expect(find.text('Evidence Validator Report'), findsOneWidget);
      expect(find.text('Verified Claims'), findsOneWidget);

      // Tap Audit tab
      await tester.tap(find.text('Audit'));
      await tester.pumpAndSettle();

      expect(find.text('Routing Strategy Rationale'), findsOneWidget);
      expect(find.text('Pipeline Execution Stages'), findsOneWidget);
      expect(find.text('Dynamic Adaptation Event Log'), findsOneWidget);
    });
  });
}
