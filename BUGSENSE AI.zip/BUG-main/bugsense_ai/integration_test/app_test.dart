import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:bugsense_ai/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Authentication Flow Integration Test', () {
    testWidgets('Verify Login -> Welcome screen flow', (WidgetTester tester) async {
      app.main();
      await tester.pumpAndSettle();

      // Find login screen elements
      expect(find.text('Welcome Back'), findsOneWidget);
      expect(find.text('Email Address'), findsOneWidget);
      
      // Enter dummy credentials
      await tester.enterText(find.widgetWithText(TextFormField, 'Email Address'), 'test@bugsense.ai');
      await tester.enterText(find.widgetWithText(TextFormField, 'Password'), 'password123');
      
      // Tap log in
      await tester.tap(find.text('Log In'));
      await tester.pump();
      
      // Wait for loading to finish (1 second delay in our mock)
      await tester.pump(const Duration(seconds: 2));
      await tester.pumpAndSettle();
      
      // Verify we arrived at the Welcome Screen
      expect(find.text('Welcome to BugSense AI'), findsOneWidget);
      expect(find.text('Connect GitHub Account'), findsOneWidget);
    });
  });
}
