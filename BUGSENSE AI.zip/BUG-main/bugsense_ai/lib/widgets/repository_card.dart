import 'package:flutter/material.dart';

import '../models/repo_model.dart';

/// A polished repository card used in the Dashboard.
///
/// Displays repository name, owner, description, language, stars,
/// issues count, forks, and visibility badge with clear hierarchy.
class RepositoryCard extends StatelessWidget {
  final GitHubRepo repo;
  final VoidCallback onTap;

  const RepositoryCard({
    super.key,
    required this.repo,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Row 1: Icon + Name + Visibility badge
              Row(
                children: [
                  Icon(
                    repo.isPrivate ? Icons.lock_outline : Icons.public,
                    size: 16,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      repo.name,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      repo.isPrivate ? 'Private' : 'Public',
                      style: TextStyle(
                        fontSize: 11,
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),

              // Row 2: Owner
              Padding(
                padding: const EdgeInsets.only(left: 24, top: 2),
                child: Text(
                  repo.ownerLogin,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),

              // Row 3: Description
              if (repo.description != null &&
                  repo.description!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  repo.description!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                    height: 1.4,
                  ),
                ),
              ],

              // Row 4: Metadata chips
              const SizedBox(height: 12),
              Row(
                children: [
                  if (repo.language != null) ...[
                    CircleAvatar(
                      radius: 4,
                      backgroundColor: _getLanguageColor(repo.language),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      repo.language!,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 16),
                  ],
                  Icon(
                    Icons.star_rounded,
                    size: 16,
                    color: Colors.amber.shade700,
                  ),
                  const SizedBox(width: 3),
                  Text(
                    '${repo.stargazersCount}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  const SizedBox(width: 14),
                  Icon(
                    Icons.bug_report_rounded,
                    size: 15,
                    color: Colors.redAccent.shade400,
                  ),
                  const SizedBox(width: 3),
                  Text(
                    '${repo.openIssuesCount}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  const SizedBox(width: 14),
                  Icon(
                    Icons.fork_right_rounded,
                    size: 15,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 3),
                  Text(
                    '${repo.forksCount}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  const Spacer(),
                  Icon(
                    Icons.chevron_right_rounded,
                    size: 20,
                    color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.5),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Color _getLanguageColor(String? language) {
    switch (language?.toLowerCase()) {
      case 'dart':
        return Colors.blue.shade600;
      case 'python':
        return Colors.green.shade600;
      case 'javascript':
        return Colors.amber.shade700;
      case 'typescript':
        return Colors.blue.shade800;
      case 'html':
        return Colors.orange.shade700;
      case 'css':
        return Colors.purple.shade600;
      case 'kotlin':
      case 'java':
        return Colors.deepOrange.shade600;
      case 'c++':
      case 'c':
        return Colors.pink.shade600;
      case 'go':
        return Colors.cyan.shade700;
      case 'rust':
        return Colors.brown.shade600;
      case 'swift':
        return Colors.orange.shade800;
      case 'ruby':
        return Colors.red.shade700;
      default:
        return Colors.teal;
    }
  }
}
