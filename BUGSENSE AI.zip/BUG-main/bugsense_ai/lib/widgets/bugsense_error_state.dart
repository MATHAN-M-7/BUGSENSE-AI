import 'package:flutter/material.dart';

/// A production-friendly error state widget.
///
/// Never shows raw technical errors to users. Provides a consistent
/// error presentation with an optional retry button.
class BugSenseErrorState extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final bool isCompact;

  const BugSenseErrorState({
    super.key,
    this.message = 'Something went wrong. Please try again.',
    this.onRetry,
    this.isCompact = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(isCompact ? 16 : 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(isCompact ? 8 : 16),
              decoration: BoxDecoration(
                color: theme.colorScheme.errorContainer.withValues(alpha: 0.4),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.warning_amber_rounded,
                size: isCompact ? 24 : 40,
                color: theme.colorScheme.error,
              ),
            ),
            SizedBox(height: isCompact ? 12 : 20),
            Text(
              message,
              textAlign: TextAlign.center,
              style: (isCompact ? theme.textTheme.bodyMedium : theme.textTheme.bodyLarge)?.copyWith(
                color: theme.colorScheme.onSurface,
              ),
            ),
            if (onRetry != null) ...[
              SizedBox(height: isCompact ? 12 : 24),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Try Again'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
