class GitHubUser {
  final String login;
  final String? name;
  final String? avatarUrl;
  final String? bio;
  final int publicRepos;
  final int followers;
  final String? htmlUrl;

  const GitHubUser({
    required this.login,
    this.name,
    this.avatarUrl,
    this.bio,
    this.publicRepos = 0,
    this.followers = 0,
    this.htmlUrl,
  });

  factory GitHubUser.fromJson(Map<String, dynamic> json) {
    return GitHubUser(
      login: json['login'] as String? ?? '',
      name: json['name'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      bio: json['bio'] as String?,
      publicRepos: json['public_repos'] as int? ?? 0,
      followers: json['followers'] as int? ?? 0,
      htmlUrl: json['html_url'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'login': login,
      'name': name,
      'avatar_url': avatarUrl,
      'bio': bio,
      'public_repos': publicRepos,
      'followers': followers,
      'html_url': htmlUrl,
    };
  }
}

class BugSenseUser {
  final int id;
  final String fullName;
  final String username;
  final String email;
  final int? githubUserId;

  const BugSenseUser({
    required this.id,
    required this.fullName,
    required this.username,
    required this.email,
    this.githubUserId,
  });

  factory BugSenseUser.fromJson(Map<String, dynamic> json) {
    return BugSenseUser(
      id: json['id'] ?? json['user_id'] ?? 0,
      fullName: json['full_name'] ?? '',
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      githubUserId: json['github_user_id'],
    );
  }
}
