// Data models for AI analysis responses from the BugSense backend.

/// Classification result from POST /analysis/classify-rag.
class ClassificationResult {
  final String category;
  final String severity;
  final double confidence;
  final String evidenceSummary;
  final String analyzedBy;
  final String model;
  final List<dynamic> ragContext;

  const ClassificationResult({
    required this.category,
    required this.severity,
    required this.confidence,
    this.evidenceSummary = '',
    this.analyzedBy = '',
    this.model = '',
    this.ragContext = const [],
  });

  factory ClassificationResult.fromJson(Map<String, dynamic> json) {
    return ClassificationResult(
      category: json['category'] as String? ?? 'Unknown',
      severity: json['severity'] as String? ?? 'Unknown',
      confidence: (json['confidence'] as num?)?.toDouble() ??
          (json['category_confidence'] as num?)?.toDouble() ??
          0.0,
      evidenceSummary: json['evidence_summary'] as String? ?? '',
      analyzedBy: json['analyzed_by'] as String? ?? '',
      model: json['model'] as String? ?? '',
      ragContext: json['rag_context'] as List<dynamic>? ?? [],
    );
  }

  Map<String, dynamic> toPriorJson() => {
        'category': category,
        'severity': severity,
        'evidence_summary': evidenceSummary,
      };
}

/// Root cause analysis result from POST /analysis/root-cause.
class RootCauseResult {
  final String probableCause;
  final List<String> affectedComponents;
  final List<String> reproductionSteps;
  final List<String> investigationAreas;
  final double confidence;
  final String relatedPatterns;
  final String analysisSummary;
  final String analyzedBy;
  final String model;
  final List<dynamic> ragContext;

  const RootCauseResult({
    required this.probableCause,
    this.affectedComponents = const [],
    this.reproductionSteps = const [],
    this.investigationAreas = const [],
    required this.confidence,
    this.relatedPatterns = '',
    this.analysisSummary = '',
    this.analyzedBy = '',
    this.model = '',
    this.ragContext = const [],
  });

  factory RootCauseResult.fromJson(Map<String, dynamic> json) {
    return RootCauseResult(
      probableCause: json['probable_cause'] as String? ?? '',
      affectedComponents: _stringList(json['affected_components']),
      reproductionSteps: _stringList(json['reproduction_steps']),
      investigationAreas: _stringList(json['investigation_areas']),
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      relatedPatterns: json['related_patterns'] as String? ?? '',
      analysisSummary: json['analysis_summary'] as String? ?? '',
      analyzedBy: json['analyzed_by'] as String? ?? '',
      model: json['model'] as String? ?? '',
      ragContext: json['rag_context'] as List<dynamic>? ?? [],
    );
  }

  Map<String, dynamic> toPriorJson() => {
        'probable_cause': probableCause,
        'affected_components': affectedComponents,
        'investigation_areas': investigationAreas,
        'analysis_summary': analysisSummary,
      };
}

/// A single code-level fix suggestion.
class CodeSuggestion {
  final String fileOrComponent;
  final String codeSnippet;
  final String explanation;

  const CodeSuggestion({
    required this.fileOrComponent,
    required this.codeSnippet,
    this.explanation = '',
  });

  factory CodeSuggestion.fromJson(Map<String, dynamic> json) {
    return CodeSuggestion(
      fileOrComponent: json['file_or_component'] as String? ?? '',
      codeSnippet: json['code_snippet'] as String? ?? '',
      explanation: json['explanation'] as String? ??
          json['change_description'] as String? ??
          '',
    );
  }

  CodeSuggestion copyWith({
    String? fileOrComponent,
    String? codeSnippet,
    String? explanation,
  }) {
    return CodeSuggestion(
      fileOrComponent: fileOrComponent ?? this.fileOrComponent,
      codeSnippet: codeSnippet ?? this.codeSnippet,
      explanation: explanation ?? this.explanation,
    );
  }
}

/// Resolution / fix generation result from POST /analysis/resolve.
class ResolutionResult {
  final String fixDescription;
  final List<CodeSuggestion> codeSuggestions;
  final List<String> implementationStrategy;
  final List<String> testingRecommendations;
  final String riskAssessment;
  final String estimatedEffort;
  final double confidence;
  final String resolutionSummary;
  final String analyzedBy;
  final String model;
  final List<dynamic> ragContext;

  const ResolutionResult({
    required this.fixDescription,
    this.codeSuggestions = const [],
    this.implementationStrategy = const [],
    this.testingRecommendations = const [],
    this.riskAssessment = '',
    this.estimatedEffort = '',
    required this.confidence,
    this.resolutionSummary = '',
    this.analyzedBy = '',
    this.model = '',
    this.ragContext = const [],
  });

  ResolutionResult copyWith({
    String? fixDescription,
    List<CodeSuggestion>? codeSuggestions,
    List<String>? implementationStrategy,
    List<String>? testingRecommendations,
    String? riskAssessment,
    String? estimatedEffort,
    double? confidence,
    String? resolutionSummary,
    String? analyzedBy,
    String? model,
    List<dynamic>? ragContext,
  }) {
    return ResolutionResult(
      fixDescription: fixDescription ?? this.fixDescription,
      codeSuggestions: codeSuggestions ?? this.codeSuggestions,
      implementationStrategy:
          implementationStrategy ?? this.implementationStrategy,
      testingRecommendations:
          testingRecommendations ?? this.testingRecommendations,
      riskAssessment: riskAssessment ?? this.riskAssessment,
      estimatedEffort: estimatedEffort ?? this.estimatedEffort,
      confidence: confidence ?? this.confidence,
      resolutionSummary: resolutionSummary ?? this.resolutionSummary,
      analyzedBy: analyzedBy ?? this.analyzedBy,
      model: model ?? this.model,
      ragContext: ragContext ?? this.ragContext,
    );
  }

  factory ResolutionResult.fromJson(Map<String, dynamic> json) {
    final suggestions = (json['code_suggestions'] as List<dynamic>?)
            ?.map((e) => CodeSuggestion.fromJson(e as Map<String, dynamic>))
            .toList() ??
        [];

    return ResolutionResult(
      fixDescription: json['fix_description'] as String? ?? '',
      codeSuggestions: suggestions,
      implementationStrategy: _stringList(json['implementation_strategy']),
      testingRecommendations: _stringList(json['testing_recommendations']),
      riskAssessment: json['risk_assessment'] as String? ?? '',
      estimatedEffort: json['estimated_effort'] as String? ?? '',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      resolutionSummary: json['resolution_summary'] as String? ?? '',
      analyzedBy: json['analyzed_by'] as String? ?? '',
      model: json['model'] as String? ?? '',
      ragContext: json['rag_context'] as List<dynamic>? ?? [],
    );
  }
}

// ─── helpers ───

List<String> _stringList(dynamic value) {
  if (value is List) {
    return value.map((e) => e.toString()).toList();
  }
  return [];
}
