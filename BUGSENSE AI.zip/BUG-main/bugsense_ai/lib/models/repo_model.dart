class GitHubRepo {
  final int id;
  final String name;
  final String fullName;
  final String? description;
  final String? language;
  final int stargazersCount;
  final int openIssuesCount;
  final int forksCount;
  final bool isPrivate;
  final String ownerLogin;
  final String? htmlUrl;
  final DateTime? updatedAt;

  const GitHubRepo({
    required this.id,
    required this.name,
    required this.fullName,
    this.description,
    this.language,
    this.stargazersCount = 0,
    this.openIssuesCount = 0,
    this.forksCount = 0,
    this.isPrivate = false,
    required this.ownerLogin,
    this.htmlUrl,
    this.updatedAt,
  });

  factory GitHubRepo.fromJson(Map<String, dynamic> json) {
    final ownerMap = json['owner'] as Map<String, dynamic>?;
    final ownerName = ownerMap != null ? (ownerMap['login'] as String? ?? '') : '';

    DateTime? updated;
    if (json['updated_at'] != null) {
      updated = DateTime.tryParse(json['updated_at'].toString());
    }

    return GitHubRepo(
      id: json['id'] as int? ?? 0,
      name: json['name'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      description: json['description'] as String?,
      language: json['language'] as String?,
      stargazersCount: json['stargazers_count'] as int? ?? 0,
      openIssuesCount: json['open_issues_count'] as int? ?? 0,
      forksCount: json['forks_count'] as int? ?? 0,
      isPrivate: json['private'] as bool? ?? false,
      ownerLogin: ownerName,
      htmlUrl: json['html_url'] as String?,
      updatedAt: updated,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'full_name': fullName,
      'description': description,
      'language': language,
      'stargazers_count': stargazersCount,
      'open_issues_count': openIssuesCount,
      'forks_count': forksCount,
      'private': isPrivate,
      'owner': {'login': ownerLogin},
      'html_url': htmlUrl,
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}
