// Data models for Phase 4 Confidence-Aware Adaptive Routing & Safe PR Gate.

import 'analysis_models.dart';
export 'analysis_models.dart';

/// Issue complexity analysis result from POST /analysis/complexity.
class ComplexityReport {
  final double complexityScore;
  final String complexityLevel;
  final Map<String, double> signals;
  final String analyzerVersion;

  const ComplexityReport({
    required this.complexityScore,
    required this.complexityLevel,
    this.signals = const {},
    this.analyzerVersion = '',
  });

  factory ComplexityReport.fromJson(Map<String, dynamic> json) {
    final rawSignals = json['signals'] as Map<String, dynamic>? ?? {};
    final parsedSignals = <String, double>{};
    for (final entry in rawSignals.entries) {
      if (entry.value is num) {
        parsedSignals[entry.key] = (entry.value as num).toDouble();
      } else if (entry.value is Map && entry.value['score'] is num) {
        parsedSignals[entry.key] = (entry.value['score'] as num).toDouble();
      }
    }

    return ComplexityReport(
      complexityScore: (json['complexity_score'] as num?)?.toDouble() ?? 0.0,
      complexityLevel: json['complexity_level'] as String? ?? 'Low',
      signals: parsedSignals,
      analyzerVersion: json['analyzer_version'] as String? ?? '',
    );
  }
}

/// Adaptive routing plan from POST /analysis/route/plan.
class RoutePlan {
  final String route;
  final double complexityScore;
  final double confidenceGate;
  final List<String> recommendedAgents;
  final Map<String, dynamic> ragStrategy;
  final String rationale;
  final double planningLatencyMs;

  const RoutePlan({
    required this.route,
    required this.complexityScore,
    required this.confidenceGate,
    this.recommendedAgents = const [],
    this.ragStrategy = const {},
    this.rationale = '',
    this.planningLatencyMs = 0.0,
  });

  factory RoutePlan.fromJson(Map<String, dynamic> json) {
    return RoutePlan(
      route: json['route'] as String? ?? 'STANDARD',
      complexityScore: (json['complexity_score'] as num?)?.toDouble() ?? 0.0,
      confidenceGate: (json['confidence_gate'] as num?)?.toDouble() ?? 0.6,
      recommendedAgents: _stringList(json['recommended_agents']),
      ragStrategy: json['rag_strategy'] as Map<String, dynamic>? ?? {},
      rationale: json['rationale'] as String? ?? '',
      planningLatencyMs:
          (json['planning_latency_ms'] as num?)?.toDouble() ?? 0.0,
    );
  }
}

/// Deterministic Evidence Validator report from POST /analysis/validate-evidence.
class EvidenceReport {
  final String verdict; // SUFFICIENT, WEAK, INSUFFICIENT
  final double evidenceScore;
  final int verifiedClaimsCount;
  final int unverifiedClaimsCount;
  final List<dynamic> verifiedClaims;
  final List<dynamic> unverifiedClaims;
  final List<String> recommendations;

  const EvidenceReport({
    required this.verdict,
    required this.evidenceScore,
    this.verifiedClaimsCount = 0,
    this.unverifiedClaimsCount = 0,
    this.verifiedClaims = const [],
    this.unverifiedClaims = const [],
    this.recommendations = const [],
  });

  factory EvidenceReport.fromJson(Map<String, dynamic> json) {
    return EvidenceReport(
      verdict: json['verdict'] as String? ?? 'INSUFFICIENT',
      evidenceScore: (json['evidence_score'] as num?)?.toDouble() ?? 0.0,
      verifiedClaimsCount: json['verified_claims_count'] as int? ??
          (json['verified_claims'] as List?)?.length ??
          0,
      unverifiedClaimsCount: json['unverified_claims_count'] as int? ??
          (json['unverified_claims'] as List?)?.length ??
          0,
      verifiedClaims: json['verified_claims'] as List<dynamic>? ?? const [],
      unverifiedClaims: json['unverified_claims'] as List<dynamic>? ?? const [],
      recommendations: _stringList(json['recommendations']),
    );
  }
}

/// Confidence Engine evaluation report.
class ConfidenceReport {
  final double systemConfidence;
  final String systemStatus; // READY_FOR_PR, REQUIRES_HUMAN_REVIEW, LOW_CONFIDENCE, ABORTED
  final Map<String, double> confidenceBreakdown;
  final List<String> penaltiesApplied;
  final String evaluatedAt;

  const ConfidenceReport({
    required this.systemConfidence,
    required this.systemStatus,
    this.confidenceBreakdown = const {},
    this.penaltiesApplied = const [],
    this.evaluatedAt = '',
  });

  factory ConfidenceReport.fromJson(Map<String, dynamic> json) {
    final rawBreakdown =
        json['confidence_breakdown'] as Map<String, dynamic>? ?? {};
    final parsedBreakdown = <String, double>{};
    for (final entry in rawBreakdown.entries) {
      if (entry.value is num) {
        parsedBreakdown[entry.key] = (entry.value as num).toDouble();
      }
    }

    return ConfidenceReport(
      systemConfidence: (json['system_confidence'] as num?)?.toDouble() ?? 0.0,
      systemStatus: json['system_status'] as String? ?? 'REQUIRES_HUMAN_REVIEW',
      confidenceBreakdown: parsedBreakdown,
      penaltiesApplied: _stringList(json['penalties_applied']),
      evaluatedAt: json['evaluated_at'] as String? ?? '',
    );
  }

  bool get isReadyForPr => systemStatus == 'READY_FOR_PR';
  bool get requiresHumanReview => systemStatus == 'REQUIRES_HUMAN_REVIEW';
  bool get isLowConfidence => systemStatus == 'LOW_CONFIDENCE';
  bool get isAborted => systemStatus == 'ABORTED';
}

/// Complete pipeline result from POST /analysis/route.
class AdaptiveRoutingResult {
  final String status; // completed, gated_early_exit, error
  final String route;
  final RoutePlan? routePlan;
  final ClassificationResult? classification;
  final RootCauseResult? rootCause;
  final ResolutionResult? resolution;
  final EvidenceReport? evidenceReport;
  final ConfidenceReport? systemConfidenceReport;
  final List<String> stagesExecuted;
  final List<Map<String, dynamic>> adaptationLog;

  const AdaptiveRoutingResult({
    required this.status,
    required this.route,
    this.routePlan,
    this.classification,
    this.rootCause,
    this.resolution,
    this.evidenceReport,
    this.systemConfidenceReport,
    this.stagesExecuted = const [],
    this.adaptationLog = const [],
  });

  AdaptiveRoutingResult copyWith({
    String? status,
    String? route,
    RoutePlan? routePlan,
    ClassificationResult? classification,
    RootCauseResult? rootCause,
    ResolutionResult? resolution,
    EvidenceReport? evidenceReport,
    ConfidenceReport? systemConfidenceReport,
    List<String>? stagesExecuted,
    List<Map<String, dynamic>>? adaptationLog,
  }) {
    return AdaptiveRoutingResult(
      status: status ?? this.status,
      route: route ?? this.route,
      routePlan: routePlan ?? this.routePlan,
      classification: classification ?? this.classification,
      rootCause: rootCause ?? this.rootCause,
      resolution: resolution ?? this.resolution,
      evidenceReport: evidenceReport ?? this.evidenceReport,
      systemConfidenceReport:
          systemConfidenceReport ?? this.systemConfidenceReport,
      stagesExecuted: stagesExecuted ?? this.stagesExecuted,
      adaptationLog: adaptationLog ?? this.adaptationLog,
    );
  }

  factory AdaptiveRoutingResult.fromJson(Map<String, dynamic> json) {
    return AdaptiveRoutingResult(
      status: json['status'] as String? ?? 'completed',
      route: json['route'] as String? ?? 'STANDARD',
      routePlan: json['route_plan'] is Map<String, dynamic>
          ? RoutePlan.fromJson(json['route_plan'] as Map<String, dynamic>)
          : null,
      classification: json['classification'] is Map<String, dynamic>
          ? ClassificationResult.fromJson(
              json['classification'] as Map<String, dynamic>)
          : null,
      rootCause: json['root_cause'] is Map<String, dynamic>
          ? RootCauseResult.fromJson(json['root_cause'] as Map<String, dynamic>)
          : null,
      resolution: json['resolution'] is Map<String, dynamic>
          ? ResolutionResult.fromJson(
              json['resolution'] as Map<String, dynamic>)
          : null,
      evidenceReport: json['evidence_report'] is Map<String, dynamic>
          ? EvidenceReport.fromJson(
              json['evidence_report'] as Map<String, dynamic>)
          : null,
      systemConfidenceReport: json['system_confidence_report']
              is Map<String, dynamic>
          ? ConfidenceReport.fromJson(
              json['system_confidence_report'] as Map<String, dynamic>)
          : null,
      stagesExecuted: _stringList(json['stages_executed']),
      adaptationLog: (json['adaptation_log'] as List<dynamic>?)
              ?.map((e) => e is Map<String, dynamic>
                  ? e
                  : <String, dynamic>{'message': e.toString()})
              .toList() ??
          const [],
    );
  }
}

/// Pull request creation response from POST /github/repos/.../generate-pr.
class PullRequestResult {
  final String status;
  final String prUrl;
  final int? prNumber;
  final String branch;

  const PullRequestResult({
    required this.status,
    required this.prUrl,
    this.prNumber,
    required this.branch,
  });

  factory PullRequestResult.fromJson(Map<String, dynamic> json) {
    return PullRequestResult(
      status: json['status'] as String? ?? 'success',
      prUrl: json['pr_url'] as String? ?? '',
      prNumber: json['pr_number'] as int?,
      branch: json['branch'] as String? ?? '',
    );
  }
}

/// Record of a human-in-the-loop review verdict (Approve, Edit, Reject).
class ReviewVerdict {
  final String status;
  final String verdict; // APPROVED, EDITED, REJECTED
  final String repoOwner;
  final String repoName;
  final int issueNumber;
  final String? rejectionReason;
  final String recordedAt;

  const ReviewVerdict({
    required this.status,
    required this.verdict,
    required this.repoOwner,
    required this.repoName,
    required this.issueNumber,
    this.rejectionReason,
    this.recordedAt = '',
  });

  factory ReviewVerdict.fromJson(Map<String, dynamic> json) {
    return ReviewVerdict(
      status: json['status'] as String? ?? 'recorded',
      verdict: json['verdict'] as String? ?? 'APPROVED',
      repoOwner: json['repo_owner'] as String? ?? '',
      repoName: json['repo_name'] as String? ?? '',
      issueNumber: json['issue_number'] as int? ?? 0,
      rejectionReason: json['rejection_reason'] as String?,
      recordedAt: json['recorded_at'] as String? ?? '',
    );
  }
}

// Helper
List<String> _stringList(dynamic value) {
  if (value is List) {
    return value.map((e) => e.toString()).toList();
  }
  return [];
}
