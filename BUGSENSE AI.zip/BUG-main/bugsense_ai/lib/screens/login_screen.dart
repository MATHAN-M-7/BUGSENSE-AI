import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../widgets/bugsense_shared.dart';
import 'signup_screen.dart';
import '../services/api_service.dart';

class LoginScreen extends StatefulWidget {
  final Function(dynamic user, String? token) onLoginSuccess;

  const LoginScreen({super.key, required this.onLoginSuccess});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _rememberMe = false;
  bool _isLoading = false;
  bool _obscurePassword = true;
  String? _errorMessage;
  final ApiService _api = ApiService();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submit() async {
    debugPrint('LOGIN_DEBUG_01_BUTTON_PRESSED');
    debugPrint('LOGIN_DEBUG_02_VALIDATION_START');
    if (_formKey.currentState?.validate() ?? false) {
      debugPrint('LOGIN_DEBUG_03_VALIDATION_PASSED');
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });
      
      try {
        debugPrint('LOGIN_DEBUG_04_API_CALL_START');
        debugPrint('[Login] Button pressed, starting request to: https://bugsense-backend-qiup.onrender.com/auth/login');
        final result = await _api.login(
          usernameOrEmail: _emailController.text.trim(),
          password: _passwordController.text,
        );
        debugPrint('LOGIN_DEBUG_08_TOKEN_RECEIVED');
        debugPrint('[Login] HTTP success received.');
        
        final sessionToken = result['session_token'] as String;
        final userJson = result['user'] as Map<String, dynamic>;
        final bugSenseUser = BugSenseUser.fromJson(userJson);
        
        if (!mounted) return;
        
        widget.onLoginSuccess(bugSenseUser, sessionToken);
      } catch (e) {
        debugPrint('[Login] Error caught: $e');
        if (!mounted) return;
        setState(() {
          final errorStr = e.toString().toLowerCase();
          if (errorStr.contains('timeoutexception') || errorStr.contains('timed out')) {
            _errorMessage = 'The server is taking too long to respond. Please try again.';
          } else if (errorStr.contains('socketexception') || errorStr.contains('connection refused') || errorStr.contains('network')) {
            _errorMessage = 'Unable to connect right now. Please try again.';
          } else if (errorStr.contains('500') || errorStr.contains('502') || errorStr.contains('503')) {
            _errorMessage = 'Server is busy. Please try again.';
          } else if (errorStr.contains('invalid username') || errorStr.contains('incorrect') || errorStr.contains('invalid credentials') || errorStr.contains('401')) {
            _errorMessage = 'Invalid username or password. Please try again.';
          } else if (errorStr.contains('404')) {
            _errorMessage = 'Endpoint not found. Please try again later.';
          } else {
            _errorMessage = 'Unable to sign in. Please check your details and try again.';
          }
        });
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      body: BugSenseBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const BugSenseLogoWidget(showSubtitle: false),
                    const SizedBox(height: 32),
                    
                    const Text(
                      'Welcome Back',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Log in to your BugSense AI account',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey.shade400,
                      ),
                    ),
                    const SizedBox(height: 36),

                    if (_errorMessage != null) ...[
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2D1B1B),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFF6B2E2E)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 22),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                _errorMessage!,
                                style: const TextStyle(color: Color(0xFFFCA5A5), fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],

                    _buildTextField(
                      controller: _emailController,
                      label: 'Email or Username',
                      icon: Icons.person_outline,
                      keyboardType: TextInputType.text,
                      validator: (value) =>
                          (value == null || value.isEmpty) ? 'Please enter your email or username' : null,
                    ),
                    const SizedBox(height: 16),
                    
                    _buildTextField(
                      controller: _passwordController,
                      label: 'Password',
                      icon: Icons.lock_outline,
                      obscureText: _obscurePassword,
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                          color: Colors.grey.shade500,
                        ),
                        onPressed: () {
                          setState(() {
                            _obscurePassword = !_obscurePassword;
                          });
                        },
                      ),
                      validator: (value) =>
                          (value == null || value.length < 6) ? 'Password must be at least 6 characters' : null,
                    ),
                    const SizedBox(height: 16),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              height: 24,
                              width: 24,
                              child: Checkbox(
                                value: _rememberMe,
                                onChanged: (val) => setState(() => _rememberMe = val ?? false),
                                activeColor: colorScheme.primary,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                                side: BorderSide(color: Colors.grey.shade600),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text('Remember me', style: TextStyle(color: Colors.grey.shade300, fontSize: 14)),
                          ],
                        ),
                        TextButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('Forgot Password'),
                                content: const Text('Password reset is currently unavailable. Please try again later.'),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx),
                                    child: const Text('OK'),
                                  ),
                                ],
                              ),
                            );
                          },
                          style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 0), tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                          child: Text('Forgot Password?', style: TextStyle(color: colorScheme.primary, fontSize: 14)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),

                    ElevatedButton(
                      onPressed: _isLoading ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorScheme.primary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                            )
                          : const Text('Log In', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 24),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Don't have an account? ", style: TextStyle(color: Colors.grey.shade400, fontSize: 15)),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (_) => SignupScreen(onLoginSuccess: widget.onLoginSuccess)),
                            );
                          },
                          child: Text('Sign up', style: TextStyle(color: colorScheme.primary, fontSize: 15, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    Widget? suffixIcon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      validator: validator,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey.shade400),
        prefixIcon: Icon(icon, color: Colors.grey.shade500),
        suffixIcon: suffixIcon,
        filled: true,
        fillColor: const Color(0xFF161B22).withValues(alpha: 0.8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF30363D)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF30363D)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF7F56D9), width: 1.8),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFEF4444)),
        ),
      ),
    );
  }
}
