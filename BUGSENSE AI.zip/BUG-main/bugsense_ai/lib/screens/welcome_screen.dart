import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/user_model.dart';
import '../services/api_service.dart';
import '../widgets/bugsense_shared.dart';

class WelcomeScreen extends StatefulWidget {
  final BugSenseUser user;
  final Function(dynamic user, String? token) onLoginSuccess;
  final VoidCallback? onSignOut;

  const WelcomeScreen({
    super.key,
    required this.user,
    required this.onLoginSuccess,
    this.onSignOut,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final ApiService _api = ApiService();

  bool _isConnecting = false;
  String? _errorMessage;

  String _loadingMessage = 'Connecting to GitHub…';
  Timer? _loadingMessageTimer;

  @override
  void dispose() {
    _loadingMessageTimer?.cancel();
    super.dispose();
  }

  Future<void> _loginWithOAuth() async {
    debugPrint('OAUTH_01_BUTTON');
    if (_isConnecting) return;
    setState(() {
      _isConnecting = true;
      _errorMessage = null;
      _loadingMessage = 'Connecting to GitHub…';
    });

    _startLoadingMessages();

    try {
      debugPrint('OAUTH_02_URL');
      final loginData = await _api.getOAuthLoginUrl();
      final authUrl = loginData['auth_url'] as String?;
      debugPrint('GITHUB_FLOW_03_AUTH_URL_RECEIVED: hasUrl=${authUrl != null && authUrl.isNotEmpty}');

      if (authUrl == null || authUrl.isEmpty) {
        throw Exception('no_auth_url');
      }

      if (mounted) setState(() => _loadingMessage = 'Opening GitHub…');

      final uri = Uri.parse(authUrl);
      if (await canLaunchUrl(uri)) {
        debugPrint('OAUTH_03_BROWSER');
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (mounted) {
          setState(() => _loadingMessage = 'Waiting for GitHub authentication…');
        }
      } else {
        throw Exception('no_browser');
      }
    } catch (e) {
      debugPrint('GITHUB_FLOW_ERROR: $e');
      _loadingMessageTimer?.cancel();
      if (mounted) {
        setState(() {
          _errorMessage = _friendlyMessage(e.toString());
          _isConnecting = false;
        });
      }
    }
  }

  void _startLoadingMessages() {
    _loadingMessageTimer?.cancel();
    int tick = 0;
    _loadingMessageTimer = Timer.periodic(const Duration(seconds: 8), (timer) {
      tick++;
      if (!mounted) {
        timer.cancel();
        return;
      }
      switch (tick) {
        case 1:
          setState(() => _loadingMessage = 'Server is waking up. Please wait…');
          break;
        case 2:
          setState(() => _loadingMessage = 'Almost there…');
          break;
        default:
          setState(() => _loadingMessage = 'Still connecting. Please wait…');
          break;
      }
    });
  }

  String _friendlyMessage(String raw) {
    final lower = raw.toLowerCase();
    if (lower.contains('timeout') || lower.contains('timed out')) {
      return 'Taking too long to respond. Please try again.';
    }
    if (lower.contains('socketexception') || lower.contains('connection') || lower.contains('network') || lower.contains('no internet')) {
      return 'Connection problem. Please check your internet and try again.';
    }
    if (lower.contains('503') || lower.contains('502') || lower.contains('unavailable') || lower.contains('busy')) {
      return 'Server is busy. Please try again.';
    }
    if (lower.contains('access_denied') || lower.contains('denied')) {
      return 'GitHub sign-in was cancelled. Please try again.';
    }
    if (lower.contains('invalid_state') || lower.contains('csrf')) {
      return 'Sign-in session expired. Please try again.';
    }
    if (lower.contains('session') || lower.contains('expired') || lower.contains('401')) {
      return 'Your session could not be restored. Please sign in again.';
    }
    return 'Unable to sign in. Please try again.';
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final firstName = widget.user.fullName.isNotEmpty
        ? widget.user.fullName.split(' ').first
        : widget.user.username;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.white),
          onPressed: () {},
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.pest_control_rounded, color: Colors.white, size: 24),
            const SizedBox(width: 8),
            const Text(
              'BugSense ',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 20,
              ),
            ),
            Text(
              'AI',
              style: TextStyle(
                color: colorScheme.primary,
                fontWeight: FontWeight.w800,
                fontSize: 20,
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle_outlined, color: Colors.white),
            onPressed: () {
              if (widget.onSignOut != null) {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Sign Out'),
                    content: const Text('Are you sure you want to sign out?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(ctx);
                          widget.onSignOut!();
                        },
                        child: const Text('Sign Out', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
              }
            },
          ),
        ],
      ),
      body: BugSenseBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 16),
                Text(
                  'Welcome, $firstName!',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Your AI-powered assistant for GitHub bug triage and resolution.',
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey.shade400,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 32),

                // GitHub Auth Card
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: const Color(0xFF161B22),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF30363D)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.code, color: Colors.black, size: 22),
                          ),
                          const SizedBox(width: 16),
                          const Expanded(
                            child: Text(
                              'Connect Your GitHub Account',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Sign in with GitHub to access your repositories, issues and enable all features.',
                        style: TextStyle(color: Colors.grey.shade400, fontSize: 13, height: 1.4),
                      ),
                      const SizedBox(height: 20),

                      if (_errorMessage != null) ...[
                        Container(
                          padding: const EdgeInsets.all(12),
                          margin: const EdgeInsets.only(bottom: 16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF2D1B1B),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFF6B2E2E)),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 18),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _errorMessage!,
                                  style: const TextStyle(color: Color(0xFFFCA5A5), fontSize: 13),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      ElevatedButton(
                        onPressed: _isConnecting ? null : _loginWithOAuth,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          backgroundColor: colorScheme.primary,
                          foregroundColor: Colors.white,
                          disabledBackgroundColor: colorScheme.primary.withAlpha(120),
                          disabledForegroundColor: Colors.white70,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 0,
                        ),
                        child: _isConnecting
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2.5,
                                      color: Colors.white70,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Flexible(
                                    child: Text(
                                      _loadingMessage,
                                      style: const TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              )
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.code, size: 22),
                                  SizedBox(width: 10),
                                  Text(
                                    'Sign in with GitHub',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Icon(Icons.arrow_forward_rounded, size: 20),
                                ],
                              ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 32),

                // Key Features Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Key Features',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(0, 0),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: Text(
                        'View All',
                        style: TextStyle(color: colorScheme.primary, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Key Features Grid
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 0.95,
                  children: const [
                    _FeatureCard(
                      icon: Icons.folder_outlined,
                      title: 'Repository Management',
                      description: 'Connect and manage your GitHub repositories',
                    ),
                    _FeatureCard(
                      icon: Icons.description_outlined,
                      title: 'Issue Management',
                      description: 'View and analyze repository issues',
                    ),
                    _FeatureCard(
                      icon: Icons.psychology_outlined,
                      title: 'AI Issue Classification',
                      description: 'Automatically classify issues by severity',
                    ),
                    _FeatureCard(
                      icon: Icons.search_outlined,
                      title: 'RAG Analysis',
                      description: 'Find relevant code context and analyze',
                    ),
                    _FeatureCard(
                      icon: Icons.code,
                      title: 'Resolution Generation',
                      description: 'Get AI-powered fix suggestions',
                    ),
                    _FeatureCard(
                      icon: Icons.account_tree_outlined,
                      title: 'Create Pull Requests',
                      description: 'Automatically create branches, commits and PRs',
                    ),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF161B22).withOpacity(0.6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF30363D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF7F56D9), size: 28),
          const Spacer(),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            description,
            style: TextStyle(
              color: Colors.grey.shade400,
              fontSize: 12,
              height: 1.3,
            ),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(Icons.arrow_forward_ios_rounded, color: const Color(0xFF7F56D9), size: 14),
            ],
          )
        ],
      ),
    );
  }
}

