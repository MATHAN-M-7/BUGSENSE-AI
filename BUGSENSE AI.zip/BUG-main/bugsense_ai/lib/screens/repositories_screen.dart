import 'package:flutter/material.dart';

import '../models/repo_model.dart';
import '../models/user_model.dart';
import '../screens/issue_detail_screen.dart';
import '../services/api_service.dart';
import '../widgets/bugsense_loading.dart';
import '../widgets/bugsense_empty_state.dart';
import '../widgets/bugsense_error_state.dart';
import '../widgets/repository_card.dart';
import '../widgets/issue_card.dart';

class RepositoriesScreen extends StatefulWidget {
  final GitHubUser user;
  final String? token;
  final VoidCallback onSignOut;
  final VoidCallback onDeleteAccount;

  const RepositoriesScreen({
    super.key,
    required this.user,
    this.token,
    required this.onSignOut,
    required this.onDeleteAccount,
  });

  @override
  State<RepositoriesScreen> createState() => _RepositoriesScreenState();
}

class _RepositoriesScreenState extends State<RepositoriesScreen> {
  final ApiService _api = ApiService();
  final TextEditingController _searchController = TextEditingController();

  List<GitHubRepo> _allRepos = [];
  List<GitHubRepo> _filteredRepos = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchRepos();
    _searchController.addListener(_filterRepos);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchRepos() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final repos = await _api.getRepositories(token: widget.token);
      debugPrint('OAUTH_10_REPOSITORIES_RESPONSE');
      if (mounted) {
        setState(() {
          _allRepos = repos;
          _filterRepos();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = e.toString().replaceFirst('Exception: ', '');
          _isLoading = false;
        });
      }
    }
  }

  void _filterRepos() {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) {
      setState(() {
        _filteredRepos = List.from(_allRepos);
      });
    } else {
      setState(() {
        _filteredRepos = _allRepos.where((repo) {
          final matchesName = repo.name.toLowerCase().contains(query);
          final matchesLang = (repo.language ?? '').toLowerCase().contains(query);
          final matchesDesc = (repo.description ?? '').toLowerCase().contains(query);
          return matchesName || matchesLang || matchesDesc;
        }).toList();
      });
    }
  }

  Future<void> _loadSampleRepo() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final sample = await _api.getRepo('octocat', 'Hello-World', token: widget.token);
      if (mounted) {
        setState(() {
          _allRepos = [sample];
          _filterRepos();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Failed to load sample: $e';
          _isLoading = false;
        });
      }
    }
  }

  Color _getLanguageColor(String? language) {
    switch (language?.toLowerCase()) {
      case 'dart':
        return Colors.blue.shade600;
      case 'python':
        return Colors.green.shade600;
      case 'javascript':
        return Colors.amber.shade700;
      case 'typescript':
        return Colors.blue.shade800;
      case 'html':
        return Colors.orange.shade700;
      case 'css':
        return Colors.purple.shade600;
      case 'kotlin':
      case 'java':
        return Colors.deepOrange.shade600;
      case 'c++':
      case 'c':
        return Colors.pink.shade600;
      default:
        return Colors.teal;
    }
  }

  void _showRepoBottomSheet(GitHubRepo repo) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.45,
          minChildSize: 0.3,
          maxChildSize: 0.75,
          builder: (context, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(
                        repo.isPrivate ? Icons.lock_outline : Icons.public,
                        size: 20,
                        color: Colors.grey.shade700,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          repo.fullName,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (repo.description != null && repo.description!.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      repo.description!,
                      style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
                    ),
                  ],
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    children: [
                      if (repo.language != null)
                        Chip(
                          avatar: CircleAvatar(
                            radius: 5,
                            backgroundColor: _getLanguageColor(repo.language),
                          ),
                          label: Text(repo.language!),
                        ),
                      Chip(
                        avatar: const Icon(Icons.star_rounded, size: 16, color: Colors.amber),
                        label: Text('${repo.stargazersCount} Stars'),
                      ),
                      Chip(
                        avatar: const Icon(Icons.bug_report_rounded, size: 16, color: Colors.redAccent),
                        label: Text('${repo.openIssuesCount} Open Issues'),
                      ),
                      Chip(
                        avatar: const Icon(Icons.fork_right_rounded, size: 16),
                        label: Text('${repo.forksCount} Forks'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _showIssuesDialog(repo);
                    },
                    icon: const Icon(Icons.bug_report),
                    label: const Text('View Repository Issues'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showIssuesDialog(GitHubRepo repo) async {
    showDialog(
      context: context,
      builder: (context) {
        return FutureBuilder<List<Map<String, dynamic>>>(
          future: _api.getRepoIssues(
            repo.ownerLogin,
            repo.name,
            token: widget.token,
          ),
          builder: (context, snapshot) {
            return AlertDialog(
              title: Text('Issues in ${repo.name}'),
              content: SizedBox(
                width: double.maxFinite,
                height: 350,
                child: snapshot.connectionState == ConnectionState.waiting
                    ? const BugSenseLoading(message: 'Loading issues...')
                    : snapshot.hasError
                        ? BugSenseErrorState(message: 'Failed to load issues: ${snapshot.error}')
                        : (snapshot.data == null || snapshot.data!.isEmpty)
                            ? const BugSenseEmptyState(
                                icon: Icons.inbox_rounded,
                                title: 'No issues found',
                                subtitle: 'This repository has no open or closed issues.',
                              )
                            : ListView.builder(
                                itemCount: snapshot.data!.length,
                                itemBuilder: (context, index) {
                                  final issue = snapshot.data![index];
                                  return IssueCard(
                                    issue: issue,
                                    onTap: () {
                                      Navigator.pop(context);
                                      Navigator.push(
                                        this.context,
                                        MaterialPageRoute(
                                          builder: (_) => IssueDetailScreen(
                                            owner: repo.ownerLogin,
                                            repo: repo.name,
                                            issue: issue,
                                            token: widget.token,
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    debugPrint('OAUTH_11_REPOSITORIES_UI');
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: theme.colorScheme.primaryContainer,
              backgroundImage: widget.user.avatarUrl != null
                  ? NetworkImage(widget.user.avatarUrl!)
                  : null,
              child: widget.user.avatarUrl == null
                  ? Text(
                      widget.user.login.isNotEmpty ? widget.user.login[0].toUpperCase() : 'U',
                      style: TextStyle(
                        color: theme.colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    widget.user.name ?? widget.user.login,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    '@${widget.user.login}',
                    style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'sign_out') {
                widget.onSignOut();
              } else if (value == 'delete_account') {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Delete Account'),
                    content: const Text(
                        'Are you sure you want to permanently delete your account and all associated data? This action cannot be undone.'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(true),
                        style: TextButton.styleFrom(foregroundColor: Colors.red),
                        child: const Text('Delete Permanently'),
                      ),
                    ],
                  ),
                );

                if (confirm == true) {
                  // Show loading overlay
                  showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => const Center(child: CircularProgressIndicator()),
                  );
                  try {
                    widget.onDeleteAccount();
                    // Dialog will be dismissed when _handleDeleteAccount navigates away.
                  } catch (e) {
                    Navigator.of(context).pop(); // dismiss loading
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to delete account: $e')),
                    );
                  }
                }
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'sign_out',
                child: Row(
                  children: [
                    Icon(Icons.logout_rounded),
                    SizedBox(width: 8),
                    Text('Sign Out'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete_account',
                child: Row(
                  children: [
                    Icon(Icons.delete_forever, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete Account', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search repositories or languages...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => _searchController.clear(),
                      )
                    : null,
                filled: true,
                fillColor: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // Content Area
          Expanded(
            child: _isLoading
                ? const BugSenseLoading(message: 'Loading your repositories...')
                : _errorMessage != null
                    ? BugSenseErrorState(
                        message: _errorMessage!,
                        onRetry: _fetchRepos,
                      )
                    : _filteredRepos.isEmpty
                        ? BugSenseEmptyState(
                            icon: Icons.folder_open_rounded,
                            title: 'No repositories found',
                            subtitle: widget.user.publicRepos == 0
                                ? 'Your GitHub account currently has 0 personal repositories.'
                                : 'No repositories match your search query.',
                            actionLabel: 'Explore Sample Repo',
                            onAction: _loadSampleRepo,
                          )
                        : RefreshIndicator(
                            onRefresh: _fetchRepos,
                            child: ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              itemCount: _filteredRepos.length,
                              itemBuilder: (context, index) {
                                final repo = _filteredRepos[index];
                                return RepositoryCard(
                                  repo: repo,
                                  onTap: () => _showRepoBottomSheet(repo),
                                );
                              },
                            ),
                          ),
          ),
        ],
      ),
    );
  }
}
