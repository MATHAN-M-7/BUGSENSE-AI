import 'package:flutter/material.dart';

import '../models/analysis_models.dart';
import '../services/api_service.dart';
import '../widgets/bugsense_shared.dart';
import '../widgets/bugsense_error_state.dart';
import 'mobile_review_screen.dart';

/// Full-screen view for a single GitHub issue with AI analysis capabilities.
///
/// Provides three AI action buttons — Classify, Root Cause, Resolve — that
/// progressively chain their results (e.g. Root Cause auto-includes a prior
/// classification if one was already run).
class IssueDetailScreen extends StatefulWidget {
  final String owner;
  final String repo;
  final Map<String, dynamic> issue;
  final String? token;

  const IssueDetailScreen({
    super.key,
    required this.owner,
    required this.repo,
    required this.issue,
    this.token,
  });

  @override
  State<IssueDetailScreen> createState() => _IssueDetailScreenState();
}

class _IssueDetailScreenState extends State<IssueDetailScreen> {
  final ApiService _api = ApiService();

  // Loading states
  bool _isClassifying = false;
  bool _isAnalyzingRootCause = false;
  bool _isResolving = false;

  // Results (null = not yet run)
  ClassificationResult? _classification;
  RootCauseResult? _rootCause;
  ResolutionResult? _resolution;

  // Error messages
  String? _classifyError;
  String? _rootCauseError;
  String? _resolveError;

  // ─── Accessors for issue fields ───
  int? get _issueNumber => widget.issue['number'] as int?;
  String get _title => widget.issue['title'] as String? ?? 'Untitled';
  String get _body => widget.issue['body'] as String? ?? '';
  String get _state => widget.issue['state'] as String? ?? 'open';
  List<String> get _labels {
    final raw = widget.issue['labels'];
    if (raw is List) {
      return raw.map((l) {
        if (l is Map) return l['name']?.toString() ?? '';
        return l.toString();
      }).where((s) => s.isNotEmpty).toList();
    }
    return [];
  }

  // ─── AI Actions ───

  Future<void> _classify() async {
    setState(() {
      _isClassifying = true;
      _classifyError = null;
    });
    try {
      final result = await _api.classifyIssue(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber,
        title: _title,
        body: _body,
        state: _state,
        labels: _labels,
        token: widget.token,
      );
      if (mounted) setState(() => _classification = result);
    } catch (e) {
      if (mounted) {
        String msg = e.toString();
        if (msg.contains('TimeoutException') || msg.contains('Future not completed') || msg.contains('SocketException') || msg.contains('ClientException')) {
          msg = 'Unable to complete the analysis right now. Please try again.';
        } else {
          msg = msg.replaceFirst('Exception: ', '');
        }
        setState(() => _classifyError = msg);
      }
    } finally {
      if (mounted) setState(() => _isClassifying = false);
    }
  }

  Future<void> _analyzeRootCause() async {
    setState(() {
      _isAnalyzingRootCause = true;
      _rootCauseError = null;
    });
    try {
      final result = await _api.analyzeRootCause(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber,
        title: _title,
        body: _body,
        state: _state,
        labels: _labels,
        priorClassification: _classification,
        token: widget.token,
      );
      if (mounted) setState(() => _rootCause = result);
    } catch (e) {
      if (mounted) {
        String msg = e.toString();
        if (msg.contains('TimeoutException') || msg.contains('Future not completed') || msg.contains('SocketException') || msg.contains('ClientException')) {
          msg = 'Unable to complete the analysis right now. Please try again.';
        } else {
          msg = msg.replaceFirst('Exception: ', '');
        }
        setState(() => _rootCauseError = msg);
      }
    } finally {
      if (mounted) setState(() => _isAnalyzingRootCause = false);
    }
  }

  Future<void> _resolve() async {
    setState(() {
      _isResolving = true;
      _resolveError = null;
    });
    try {
      final result = await _api.resolveIssue(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber,
        title: _title,
        body: _body,
        state: _state,
        labels: _labels,
        priorClassification: _classification,
        priorRootCause: _rootCause,
        token: widget.token,
      );
      if (mounted) setState(() => _resolution = result);
    } catch (e) {
      if (mounted) {
        String msg = e.toString();
        if (msg.contains('TimeoutException') || msg.contains('Future not completed') || msg.contains('SocketException') || msg.contains('ClientException')) {
          msg = 'Unable to complete the analysis right now. Please try again.';
        } else {
          msg = msg.replaceFirst('Exception: ', '');
        }
        setState(() => _resolveError = msg);
      }
    } finally {
      if (mounted) setState(() => _isResolving = false);
    }
  }

  // ─── Build ───

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isOpen = _state == 'open';

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${widget.owner}/${widget.repo}',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            if (_issueNumber != null)
              Text(
                'Issue #$_issueNumber',
                style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
              ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        children: [
          // ── Issue Header ──
          _buildIssueHeader(theme, isOpen),
          const SizedBox(height: 16),

          // ── Issue Body ──
          if (_body.isNotEmpty) ...[
            _buildIssueBody(theme),
            const SizedBox(height: 24),
          ],

          // ── Autonomous Review & Safe PR Gate Banner ──
          _buildAutonomousReviewBanner(theme),
          const SizedBox(height: 24),

          // ── AI Actions Bar ──
          _buildAIActionsBar(theme),
          const SizedBox(height: 20),

          // ── Results ──
          if (_classifyError != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: BugSenseErrorState(
                message: 'Classification Error: $_classifyError',
                onRetry: _classify,
                isCompact: true,
              ),
            ),
          if (_classification != null) _buildClassificationCard(theme),

          if (_rootCauseError != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: BugSenseErrorState(
                message: 'Root Cause Error: $_rootCauseError',
                onRetry: _analyzeRootCause,
                isCompact: true,
              ),
            ),
          if (_rootCause != null) _buildRootCauseCard(theme),

          if (_resolveError != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: BugSenseErrorState(
                message: 'Resolution Error: $_resolveError',
                onRetry: _resolve,
                isCompact: true,
              ),
            ),
          if (_resolution != null) _buildResolutionCard(theme),

          const SizedBox(height: 40),
        ],
      ),
    );
  }

  // ─── Autonomous Review Banner ───

  Widget _buildAutonomousReviewBanner(ThemeData theme) {
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF30363D)), // GitHub border color
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F6FEB).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: Color(0xFF58A6FF),
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'BugSense AI Phase 4',
                      style: TextStyle(
                        fontSize: 11,
                        color: theme.colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Text(
                      'Autonomous Review',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Run adaptive agent routing, verify deterministic evidence, evaluate confidence, and deploy PRs safely.',
            style: TextStyle(fontSize: 13, color: theme.colorScheme.onSurfaceVariant, height: 1.4),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF238636), // GitHub primary green
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => MobileReviewScreen(
                      owner: widget.owner,
                      repo: widget.repo,
                      issue: widget.issue,
                      token: widget.token,
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.rocket_launch_rounded, size: 18),
              label: const Text(
                'Launch Safe PR Gate',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Issue Header ───

  Widget _buildIssueHeader(ThemeData theme, bool isOpen) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BugSenseChip(
              label: isOpen ? 'Open' : 'Closed',
              color: isOpen ? const Color(0xFF3FB950) : const Color(0xFFA371F7),
              icon: isOpen ? Icons.error_outline : Icons.check_circle_outline,
            ),
            const SizedBox(width: 10),
            if (_issueNumber != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  '#$_issueNumber',
                  style: TextStyle(
                    fontSize: 14,
                    color: theme.colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          _title,
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
            height: 1.3,
          ),
        ),
        if (_labels.isNotEmpty) ...[
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _labels.map((label) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
                  ),
                ),
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }

  // ─── Issue Body ───

  Widget _buildIssueBody(ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF30363D),
        ),
      ),
      child: Text(
        _body,
        style: TextStyle(
          fontSize: 14,
          height: 1.6,
          color: theme.colorScheme.onSurface,
        ),
      ),
    );
  }

  // ─── AI Actions Bar ───

  Widget _buildAIActionsBar(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.psychology_rounded, size: 20, color: theme.colorScheme.primary),
            const SizedBox(width: 8),
            Text(
              'AI Investigation Pipeline',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: _AIActionButton(
                icon: Icons.label_outline,
                label: 'Classify',
                isLoading: _isClassifying,
                isDone: _classification != null,
                color: const Color(0xFF1F6FEB), // GitHub blue
                onTap: _isClassifying ? null : _classify,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _AIActionButton(
                icon: Icons.search_rounded,
                label: 'Root Cause',
                isLoading: _isAnalyzingRootCause,
                isDone: _rootCause != null,
                color: const Color(0xFFD29922), // GitHub yellow
                onTap: _isAnalyzingRootCause ? null : _analyzeRootCause,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _AIActionButton(
                icon: Icons.build_rounded,
                label: 'Resolve',
                isLoading: _isResolving,
                isDone: _resolution != null,
                color: const Color(0xFF8957E5), // GitHub purple
                onTap: _isResolving ? null : _resolve,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ─── Classification Card ───

  Widget _buildClassificationCard(ThemeData theme) {
    final c = _classification!;
    return _ResultCard(
      icon: Icons.label_outline,
      title: 'Classification',
      color: const Color(0xFF1F6FEB), // GitHub blue
      confidence: c.confidence,
      model: c.model,
      children: [
        Row(
          children: [
            BugSenseChip(label: c.category, color: const Color(0xFF1F6FEB)),
            const SizedBox(width: 8),
            BugSenseChip(label: c.severity, color: _severityColor(c.severity)),
          ],
        ),
        if (c.evidenceSummary.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text(
            c.evidenceSummary,
            style: TextStyle(
              fontSize: 14,
              height: 1.5,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );
  }

  // ─── Root Cause Card ───

  Widget _buildRootCauseCard(ThemeData theme) {
    final r = _rootCause!;
    return _ResultCard(
      icon: Icons.search_rounded,
      title: 'Root Cause Analysis',
      color: const Color(0xFFD29922), // GitHub yellow
      confidence: r.confidence,
      model: r.model,
      children: [
        // Probable cause
        const BugSenseSectionHeader(title: 'Probable Cause'),
        Text(
          r.probableCause,
          style: TextStyle(
            fontSize: 14,
            height: 1.5,
            color: theme.colorScheme.onSurface,
          ),
        ),

        // Affected components
        if (r.affectedComponents.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Affected Components'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: r.affectedComponents
                .map((c) => BugSenseChip(label: c, color: const Color(0xFFD29922)))
                .toList(),
          ),
        ],

        // Reproduction steps
        if (r.reproductionSteps.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Reproduction Steps'),
          ...r.reproductionSteps.asMap().entries.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFD29922).withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '${e.key + 1}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          color: Color(0xFFD29922),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(e.value, style: const TextStyle(fontSize: 14, height: 1.5)),
                    ),
                  ],
                ),
              )),
        ],

        // Investigation areas
        if (r.investigationAreas.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Investigation Areas'),
          ...r.investigationAreas.map((area) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.lightbulb_outline,
                        size: 18, color: Colors.amber.shade700),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(area, style: const TextStyle(fontSize: 14, height: 1.5)),
                    ),
                  ],
                ),
              )),
        ],

        // Summary
        if (r.analysisSummary.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Summary'),
          Text(
            r.analysisSummary,
            style: TextStyle(
              fontSize: 14,
              height: 1.5,
              fontStyle: FontStyle.italic,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );
  }

  // ─── Resolution Card ───

  Widget _buildResolutionCard(ThemeData theme) {
    final res = _resolution!;
    return _ResultCard(
      icon: Icons.build_rounded,
      title: 'Resolution',
      color: const Color(0xFF8957E5), // GitHub purple
      confidence: res.confidence,
      model: res.model,
      children: [
        // Fix description
        const BugSenseSectionHeader(title: 'Fix Description'),
        Text(
          res.fixDescription,
          style: TextStyle(fontSize: 14, height: 1.5, color: theme.colorScheme.onSurface),
        ),

        // Effort + Risk
        const SizedBox(height: 16),
        Row(
          children: [
            BugSenseChip(
              label: 'Effort: ${res.estimatedEffort}',
              color: _effortColor(res.estimatedEffort),
              icon: Icons.timer_outlined,
            ),
          ],
        ),

        // Code suggestions
        if (res.codeSuggestions.isNotEmpty) ...[
          const SizedBox(height: 20),
          const BugSenseSectionHeader(title: 'Code Suggestions'),
          ...res.codeSuggestions.map((cs) => _buildCodeSuggestion(theme, cs)),
        ],

        // Implementation strategy
        if (res.implementationStrategy.isNotEmpty) ...[
          const SizedBox(height: 20),
          const BugSenseSectionHeader(title: 'Implementation Strategy'),
          ...res.implementationStrategy.asMap().entries.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFF8957E5).withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '${e.key + 1}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          color: Color(0xFF8957E5),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(e.value, style: const TextStyle(fontSize: 14, height: 1.5)),
                    ),
                  ],
                ),
              )),
        ],

        // Testing recommendations
        if (res.testingRecommendations.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Testing Recommendations'),
          ...res.testingRecommendations.map((t) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.check_circle_outline, size: 18, color: Colors.green.shade600),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(t, style: const TextStyle(fontSize: 14, height: 1.5)),
                    ),
                  ],
                ),
              )),
        ],

        // Risk assessment
        if (res.riskAssessment.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Risk Assessment'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFD29922).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFD29922).withValues(alpha: 0.3)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.warning_amber_rounded, size: 20, color: Color(0xFFD29922)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    res.riskAssessment,
                    style: const TextStyle(fontSize: 14, height: 1.5, color: Color(0xFFE3B341)),
                  ),
                ),
              ],
            ),
          ),
        ],

        // Summary
        if (res.resolutionSummary.isNotEmpty) ...[
          const SizedBox(height: 16),
          const BugSenseSectionHeader(title: 'Summary'),
          Text(
            res.resolutionSummary,
            style: TextStyle(
              fontSize: 14,
              height: 1.5,
              fontStyle: FontStyle.italic,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildCodeSuggestion(ThemeData theme, CodeSuggestion cs) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.6),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // File header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.6),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(11)),
            ),
            child: Row(
              children: [
                Icon(Icons.insert_drive_file_outlined,
                    size: 16, color: theme.colorScheme.onSurfaceVariant),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    cs.fileOrComponent,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Code snippet
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            color: const Color(0xFF1E1E1E),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Text(
                cs.codeSnippet,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 13,
                  height: 1.5,
                  color: Color(0xFFD4D4D4),
                ),
              ),
            ),
          ),
          // Explanation
          if (cs.explanation.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                cs.explanation,
                style: TextStyle(
                  fontSize: 13,
                  color: theme.colorScheme.onSurfaceVariant,
                  height: 1.5,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ─── Helpers ───

  Color _severityColor(String severity) {
    switch (severity.toLowerCase()) {
      case 'critical':
        return Colors.red.shade700;
      case 'high':
        return Colors.deepOrange;
      case 'medium':
        return Colors.orange;
      case 'low':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  Color _effortColor(String effort) {
    switch (effort.toLowerCase()) {
      case 'trivial':
        return Colors.green;
      case 'small':
        return Colors.teal;
      case 'medium':
        return Colors.orange;
      case 'large':
        return Colors.deepOrange;
      case 'complex':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

// ─────────────────────────────────────────────────────────────
// Reusable helper widgets
// ─────────────────────────────────────────────────────────────

/// An AI action button with loading/done states.
class _AIActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isLoading;
  final bool isDone;
  final Color color;
  final VoidCallback? onTap;

  const _AIActionButton({
    required this.icon,
    required this.label,
    required this.isLoading,
    required this.isDone,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: isDone ? color.withValues(alpha: 0.12) : Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isDone ? color : color.withValues(alpha: 0.3),
              width: isDone ? 1.5 : 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isLoading)
                SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: color,
                  ),
                )
              else if (isDone)
                Icon(Icons.check_circle, color: color, size: 24)
              else
                Icon(icon, color: color, size: 24),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A styled result card with header, confidence bar, and children.
class _ResultCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final double confidence;
  final String model;
  final List<Widget> children;

  const _ResultCard({
    required this.icon,
    required this.title,
    required this.color,
    required this.confidence,
    required this.model,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 20),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: color.withValues(alpha: 0.4)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: color,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Model: $model',
                        style: TextStyle(
                          fontSize: 11,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ConfidenceBar(confidence: confidence, color: color),
            const SizedBox(height: 20),
            ...children,
          ],
        ),
      ),
    );
  }
}
