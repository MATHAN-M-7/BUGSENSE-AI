import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/adaptive_models.dart';
import '../services/api_service.dart';
import '../widgets/bugsense_loading.dart';
import '../widgets/bugsense_error_state.dart';
import '../widgets/bugsense_shared.dart';

/// Full-screen Executive Mobile Review Screen for Phase 4.
///
/// Presents:
/// 1. Executive Confidence Gauge & Readiness Status
/// 2. Code Patch & Safe PR Gate with Human Sign-Off
/// 3. Deterministic Evidence Validator & Confidence Engine signal breakdown
/// 4. Route Selection & Complexity Signal Audit
class MobileReviewScreen extends StatefulWidget {
  final String owner;
  final String repo;
  final Map<String, dynamic> issue;
  final String? token;
  final AdaptiveRoutingResult? initialResult;

  const MobileReviewScreen({
    super.key,
    required this.owner,
    required this.repo,
    required this.issue,
    this.token,
    this.initialResult,
  });

  @override
  State<MobileReviewScreen> createState() => _MobileReviewScreenState();
}

class _MobileReviewScreenState extends State<MobileReviewScreen> {
  final ApiService _api = ApiService();

  // Execution state
  bool _isLoading = false;
  String _loadingStep = '';
  String? _errorMessage;

  AdaptiveRoutingResult? _result;

  // PR Gate state
  bool _humanApproved = false;
  bool _isGeneratingPr = false;
  PullRequestResult? _prResult;
  String? _prErrorMessage;

  // Human-in-the-Loop Review State
  bool _isEdited = false;
  bool _isRejected = false;
  String? _rejectionReason;
  String? _rejectionNotes;

  // Active tab index (0: Fix & PR Gate, 1: Confidence & Evidence, 2: Route & Audit)
  int _activeTab = 0;

  int? get _issueNumber => widget.issue['number'] as int?;
  String get _title => widget.issue['title'] as String? ?? 'Untitled Issue';
  String get _body => widget.issue['body'] as String? ?? '';
  String get _state => widget.issue['state'] as String? ?? 'open';
  List<String> get _labels {
    final raw = widget.issue['labels'];
    if (raw is List) {
      return raw.map((l) {
        if (l is Map) return l['name']?.toString() ?? '';
        return l.toString();
      }).where((s) => s.isNotEmpty).toList();
    }
    return [];
  }

  @override
  void initState() {
    super.initState();
    if (widget.initialResult != null) {
      _result = widget.initialResult;
    } else {
      _runPipeline();
    }
  }

  Future<void> _runPipeline() async {
    setState(() {
      _isLoading = true;
      _loadingStep = 'Running Confidence-Aware Adaptive Pipeline...';
      _errorMessage = null;
    });

    try {
      final res = await _api.runAdaptivePipeline(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber,
        title: _title,
        body: _body,
        state: _state,
        labels: _labels,
        token: widget.token,
      );
      if (mounted) {
        setState(() {
          _result = res;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          String msg = e.toString();
          if (msg.contains('TimeoutException') || msg.contains('Future not completed') || msg.contains('SocketException') || msg.contains('ClientException')) {
            msg = 'Unable to complete the analysis right now. Please try again.';
          } else {
            msg = msg.replaceFirst('Exception: ', '');
          }
          _errorMessage = msg;
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _triggerPrGate() async {
    if (_result == null || _issueNumber == null) return;
    if (_isRejected) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.red,
          content: Text('Cannot deploy PR: Resolution was dismissed/rejected by human review.'),
        ),
      );
      return;
    }

    setState(() {
      _isGeneratingPr = true;
      _prErrorMessage = null;
    });

    try {
      final routingJson = <String, dynamic>{
        'system_confidence_report': {
          'system_status':
              _result!.systemConfidenceReport?.systemStatus ?? 'LOW_CONFIDENCE',
          'system_confidence':
              _result!.systemConfidenceReport?.systemConfidence ?? 0.0,
          'penalties_applied':
              _result!.systemConfidenceReport?.penaltiesApplied ?? [],
        },
        'resolution': _result!.resolution != null
            ? {
                'fix_description': _result!.resolution!.fixDescription,
                'code_suggestions': _result!.resolution!.codeSuggestions
                    .map((cs) => {
                          'file_or_component': cs.fileOrComponent,
                          'change_description': cs.explanation,
                          'code_snippet': cs.codeSnippet,
                        })
                    .toList(),
              }
            : {},
        'is_human_edited': _isEdited,
        'human_approved': _humanApproved,
      };

      final pr = await _api.generatePullRequest(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber!,
        routingResultJson: routingJson,
        humanApproved: _humanApproved,
        token: widget.token,
      );

      _recordVerdictSafely(
        verdict: _isEdited ? 'EDITED' : 'APPROVED',
        notes: _isEdited
            ? 'Human refined code snippet and authorized PR creation'
            : 'Human authorized PR creation',
      );

      if (mounted) {
        setState(() {
          _prResult = pr;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.green.shade800,
            content: Text('Pull Request #${pr.prNumber ?? ""} created successfully!'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          String msg = e.toString();
          if (msg.contains('TimeoutException') || msg.contains('Future not completed') || msg.contains('SocketException') || msg.contains('ClientException')) {
            msg = 'Unable to complete the PR creation right now. Please try again.';
          } else {
            msg = msg.replaceFirst('Exception: ', '');
          }
          _prErrorMessage = msg;
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingPr = false;
        });
      }
    }
  }

  // ─── Human-in-the-Loop Review Actions ───

  void _showEditSnippetDialog(CodeSuggestion cs, int index) {
    final codeController = TextEditingController(text: cs.codeSnippet);
    final explanationController = TextEditingController(text: cs.explanation);

    showDialog<void>(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          title: Row(
            children: [
              const Icon(Icons.edit_note_rounded, size: 22, color: Colors.blueAccent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Refine: ${cs.fileOrComponent}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Customize the code patch or explanation prior to Pull Request generation.',
                  style: TextStyle(fontSize: 13),
                ),
                const SizedBox(height: 16),
                const Text('Code Snippet:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  key: const Key('input-edit-code'),
                  controller: codeController,
                  maxLines: 8,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Color(0xFF1E1E1E),
                    contentPadding: EdgeInsets.all(12),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Explanation:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  key: const Key('input-edit-explanation'),
                  controller: explanationController,
                  maxLines: 3,
                  style: const TextStyle(fontSize: 13),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.all(12),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogCtx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              key: const Key('btn-apply-edit'),
              onPressed: () {
                final newCode = codeController.text;
                final newExp = explanationController.text;
                Navigator.of(dialogCtx).pop();
                _applySnippetEdit(index, cs, newCode, newExp);
              },
              child: const Text('Apply Changes'),
            ),
          ],
        );
      },
    );
  }

  void _applySnippetEdit(int index, CodeSuggestion cs, String newCode, String newExp) {
    if (_result?.resolution == null) return;

    final updatedSuggestions = List<CodeSuggestion>.from(_result!.resolution!.codeSuggestions);
    if (index >= 0 && index < updatedSuggestions.length) {
      updatedSuggestions[index] = cs.copyWith(
        codeSnippet: newCode,
        explanation: newExp,
      );
    }

    final updatedResolution = _result!.resolution!.copyWith(
      codeSuggestions: updatedSuggestions,
    );

    setState(() {
      _result = _result!.copyWith(resolution: updatedResolution);
      _isEdited = true;
    });

    _recordVerdictSafely(
      verdict: 'EDITED',
      notes: 'Customized snippet for ${cs.fileOrComponent}',
      editedResolution: {
        'file_or_component': cs.fileOrComponent,
        'code_snippet': newCode,
        'explanation': newExp,
      },
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        backgroundColor: Colors.blueAccent,
        content: Text('Code suggestion refined by engineer.'),
      ),
    );
  }

  void _showRejectDialog() {
    String selectedReason = 'Incorrect Root Cause';
    final notesController = TextEditingController();
    final reasons = [
      'Incorrect Root Cause',
      'Hallucinated Code',
      'Incomplete Patch',
      'Won\'t Fix / Not a Bug',
      'Other',
    ];

    showDialog<void>(
      context: context,
      builder: (dialogCtx) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Row(
                children: [
                  Icon(Icons.cancel_outlined, color: Colors.red.shade700, size: 22),
                  const SizedBox(width: 8),
                  const Text('Reject Proposed Fix', style: TextStyle(fontSize: 18)),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Dismissing this fix will permanently lock the PR gate and record review feedback.',
                      style: TextStyle(fontSize: 13),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Rejection Reason:',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: RadioGroup<String>(
                        groupValue: selectedReason,
                        onChanged: (val) {
                          if (val != null) {
                            setDialogState(() => selectedReason = val);
                          }
                        },
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: reasons
                              .map((r) => RadioListTile<String>(
                                    title: Text(r, style: const TextStyle(fontSize: 13)),
                                    value: r,
                                    dense: true,
                                  ))
                              .toList(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      key: const Key('input-rejection-notes'),
                      controller: notesController,
                      decoration: const InputDecoration(
                        labelText: 'Feedback Notes (Optional)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                      style: const TextStyle(fontSize: 13),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogCtx).pop(),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  key: const Key('btn-confirm-rejection'),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.red.shade700,
                  ),
                  onPressed: () {
                    Navigator.of(dialogCtx).pop();
                    _applyRejection(selectedReason, notesController.text.trim());
                  },
                  child: const Text('Reject Fix'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _applyRejection(String reason, String notes) {
    setState(() {
      _isRejected = true;
      _rejectionReason = reason;
      _rejectionNotes = notes;
    });

    _recordVerdictSafely(
      verdict: 'REJECTED',
      rejectionReason: reason,
      notes: notes,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red.shade800,
        content: Text('Resolution rejected ($reason). PR Gate locked.'),
      ),
    );
  }

  void _undoRejection() {
    setState(() {
      _isRejected = false;
      _rejectionReason = null;
      _rejectionNotes = null;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Rejection cleared. Safe PR Gate unlocked.'),
      ),
    );
  }

  Future<void> _recordVerdictSafely({
    required String verdict,
    String? rejectionReason,
    String notes = '',
    Map<String, dynamic>? editedResolution,
  }) async {
    try {
      await _api.submitReviewVerdict(
        owner: widget.owner,
        repo: widget.repo,
        issueNumber: _issueNumber ?? 0,
        verdict: verdict,
        reviewer: 'mobile_reviewer',
        rejectionReason: rejectionReason,
        notes: notes,
        editedResolution: editedResolution,
        token: widget.token,
      );
    } catch (_) {
      // Ignored for testing and offline environments
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${widget.owner}/${widget.repo}',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            if (_issueNumber != null)
              Text(
                'Issue #$_issueNumber Review',
                style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
              ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Re-run Pipeline',
            onPressed: _isLoading ? null : _runPipeline,
          ),
        ],
      ),
      body: _isLoading
          ? BugSenseLoading(
              message: 'Autonomous Review in Progress',
              subtitle: _loadingStep,
            )
          : _errorMessage != null
              ? BugSenseErrorState(
                  message: 'Pipeline Evaluation Failed:\n$_errorMessage',
                  onRetry: _runPipeline,
                )
              : _result != null
                  ? _buildContent(theme)
                  : const SizedBox.shrink(),
    );
  }

  // ─── Main Content ───

  Widget _buildContent(ThemeData theme) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        // 1. Executive Hero Header & Confidence Gauge
        _buildHeroGauge(theme),
        const SizedBox(height: 24),

        // 2. Tab Selector
        _buildTabSelector(theme),
        const SizedBox(height: 24),

        // 3. Tab Body
        if (_activeTab == 0) _buildTabFixAndPr(theme),
        if (_activeTab == 1) _buildTabConfidenceAndEvidence(theme),
        if (_activeTab == 2) _buildTabRouteAndAudit(theme),
      ],
    );
  }

  // ─── Executive Hero Gauge ───

  Widget _buildHeroGauge(ThemeData theme) {
    final conf = _result?.systemConfidenceReport;
    final score = conf?.systemConfidence ?? 0.0;
    final status = conf?.systemStatus ?? 'REQUIRES_HUMAN_REVIEW';
    final route = _result?.route ?? 'STANDARD';
    final complexityLevel = _result?.routePlan?.complexityScore != null
        ? _complexityLabel(_result!.routePlan!.complexityScore)
        : 'Medium';

    final statusColor = _statusColor(status);

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title and Open Status
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    _title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      height: 1.3,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                BugSenseChip(
                  label: _state.toUpperCase(),
                  color: _state == 'open' ? Colors.green.shade600 : Colors.purple.shade600,
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Confidence Score Ring + Readiness Badge
            Row(
              children: [
                // Ring gauge
                SizedBox(
                  width: 84,
                  height: 84,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(
                        value: score.clamp(0.0, 1.0),
                        strokeWidth: 8,
                        backgroundColor: statusColor.withValues(alpha: 0.15),
                        valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                        strokeCap: StrokeCap.round,
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${(score * 100).toInt()}%',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: statusColor,
                            ),
                          ),
                          const Text(
                            'CONF',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 24),

                // Status info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: statusColor.withValues(alpha: 0.4)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(_statusIcon(status), size: 16, color: statusColor),
                            const SizedBox(width: 6),
                            Text(
                              _statusLabel(status),
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: statusColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        _statusExplanation(status),
                        style: TextStyle(
                          fontSize: 12,
                          height: 1.4,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 16),

            // Route & Complexity Chips
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (_isRejected)
                  BugSenseChip(
                    label: 'Rejected: ${_rejectionReason ?? "Dismissed"}',
                    color: Colors.red.shade700,
                    icon: Icons.cancel_rounded,
                  ),
                if (_isEdited)
                  BugSenseChip(
                    label: 'Manually Refined',
                    color: Colors.blue.shade700,
                    icon: Icons.edit_note_rounded,
                  ),
                BugSenseChip(
                  label: 'Route: $route',
                  color: _routeColor(route),
                  icon: Icons.alt_route_rounded,
                ),
                BugSenseChip(
                  label: 'Complexity: $complexityLevel',
                  color: _complexityColor(complexityLevel),
                  icon: Icons.analytics_outlined,
                ),
                if (_result?.evidenceReport != null)
                  BugSenseChip(
                    label: 'Evidence: ${_result!.evidenceReport!.verdict}',
                    color: _evidenceVerdictColor(_result!.evidenceReport!.verdict),
                    icon: Icons.verified_outlined,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── Tab Selector ───

  Widget _buildTabSelector(ThemeData theme) {
    return SegmentedButton<int>(
      segments: const [
        ButtonSegment(
          value: 0,
          icon: Icon(Icons.handyman_outlined, size: 18),
          label: Text('Fix & PR', style: TextStyle(fontSize: 13)),
        ),
        ButtonSegment(
          value: 1,
          icon: Icon(Icons.shield_outlined, size: 18),
          label: Text('Evidence', style: TextStyle(fontSize: 13)),
        ),
        ButtonSegment(
          value: 2,
          icon: Icon(Icons.timeline_rounded, size: 18),
          label: Text('Audit', style: TextStyle(fontSize: 13)),
        ),
      ],
      selected: {_activeTab},
      onSelectionChanged: (set) => setState(() => _activeTab = set.first),
      style: SegmentedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
    );
  }

  // ─── Tab 1: Fix & PR Gate ───

  Widget _buildTabFixAndPr(ThemeData theme) {
    final resolution = _result?.resolution;
    final conf = _result?.systemConfidenceReport;
    final status = conf?.systemStatus ?? 'REQUIRES_HUMAN_REVIEW';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Safe PR Gate Action Box
        _buildPrGateCard(theme, status),
        const SizedBox(height: 24),

        if (resolution == null)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blueGrey.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.blueGrey.withValues(alpha: 0.3)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline, size: 20, color: Colors.blueGrey),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'No Resolution Generated',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueGrey,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Pipeline ended or was halted by confidence gating before resolution synthesis.',
                        style: TextStyle(fontSize: 13, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
        else ...[
          // Fix Description
          _buildCard(
            theme,
            title: 'Recommended Fix',
            icon: Icons.lightbulb_outline_rounded,
            color: Colors.teal,
            child: Text(
              resolution.fixDescription,
              style: const TextStyle(fontSize: 14, height: 1.5),
            ),
          ),
          const SizedBox(height: 16),

          // Code Suggestions
          if (resolution.codeSuggestions.isNotEmpty) ...[
            const BugSenseSectionHeader(title: 'Code Suggestions'),
            ...resolution.codeSuggestions.asMap().entries
                .map((e) => _buildCodeSnippetCard(theme, e.value, e.key)),
            const SizedBox(height: 16),
          ],

          // Implementation Strategy
          if (resolution.implementationStrategy.isNotEmpty)
            _buildListCard(
              theme,
              title: 'Implementation Strategy',
              icon: Icons.format_list_numbered_rounded,
              color: Colors.indigo,
              items: resolution.implementationStrategy,
              isNumbered: true,
            ),
          const SizedBox(height: 16),

          // Testing Recommendations
          if (resolution.testingRecommendations.isNotEmpty)
            _buildListCard(
              theme,
              title: 'Testing Recommendations',
              icon: Icons.check_circle_outline,
              color: Colors.green,
              items: resolution.testingRecommendations,
              isNumbered: false,
            ),
          const SizedBox(height: 16),

          // Risk Assessment
          if (resolution.riskAssessment.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.amber.shade300),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.warning_amber_rounded, size: 20, color: Colors.amber.shade800),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Risk Assessment',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.amber.shade900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          resolution.riskAssessment,
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.5,
                            color: Colors.amber.shade900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }

  // ─── Safe PR Gate Action Card ───

  Widget _buildPrGateCard(ThemeData theme, String status) {
    final isReady = status == 'READY_FOR_PR';
    final requiresReview = status == 'REQUIRES_HUMAN_REVIEW';
    final isBlocked = status == 'LOW_CONFIDENCE' || status == 'ABORTED';

    if (_prResult != null) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.green.shade50,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.green.shade400, width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green.shade700, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Pull Request #${_prResult!.prNumber ?? ""} Deployed',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Branch: ${_prResult!.branch}',
              style: TextStyle(fontSize: 14, color: Colors.green.shade900),
            ),
            if (_prResult!.prUrl.isNotEmpty) ...[
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _prResult!.prUrl));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('PR URL copied to clipboard!')),
                  );
                },
                icon: const Icon(Icons.copy_rounded, size: 16),
                label: const Text('Copy PR URL'),
              ),
            ],
          ],
        ),
      );
    }

    if (_isRejected) {
      return Container(
        key: const Key('card-rejection-status'),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.red.shade50,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.red.shade400, width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.cancel_rounded, color: Colors.red.shade800, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Resolution Dismissed & Gate Locked',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.red.shade900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Reason: ${_rejectionReason ?? "Engineer dismissed patch"}',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.red.shade900,
              ),
            ),
            if (_rejectionNotes != null && _rejectionNotes!.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                'Notes: $_rejectionNotes',
                style: TextStyle(fontSize: 13, color: Colors.red.shade800),
              ),
            ],
            const SizedBox(height: 16),
            FilledButton.icon(
              key: const Key('btn-undo-rejection'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFDA3633).withValues(alpha: 0.2),
                foregroundColor: const Color(0xFFDA3633),
              ),
              onPressed: _undoRejection,
              icon: const Icon(Icons.undo_rounded, size: 18),
              label: const Text('Undo Dismissal & Unlock Gate'),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isReady
            ? Colors.green.withValues(alpha: 0.08)
            : requiresReview
                ? Colors.amber.withValues(alpha: 0.1)
                : Colors.red.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isReady
              ? Colors.green.shade400
              : requiresReview
                  ? Colors.amber.shade500
                  : Colors.red.shade300,
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isReady
                    ? Icons.gavel_rounded
                    : requiresReview
                        ? Icons.verified_user_outlined
                        : Icons.block_rounded,
                color: isReady
                    ? Colors.green.shade800
                    : requiresReview
                        ? Colors.amber.shade900
                        : Colors.red.shade800,
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Safe PR Gate Status',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isReady
                        ? Colors.green.shade900
                        : requiresReview
                            ? Colors.amber.shade900
                            : Colors.red.shade900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            isReady
                ? 'Autonomous Gate Passed: High system confidence (>= 85%). Patch verified with evidence.'
                : requiresReview
                    ? 'Human Sign-Off Required: System confidence is moderate or evidence needs engineer review before PR deployment.'
                    : 'Gate Locked: System confidence is below 50% or safety penalties applied. Direct PR creation halted.',
            style: TextStyle(
              fontSize: 13,
              height: 1.5,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 16),

          if (_isEdited) ...[
            Container(
              key: const Key('banner-manually-refined'),
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue.shade300),
              ),
              child: Row(
                children: [
                  Icon(Icons.edit_note_rounded, size: 20, color: Colors.blue.shade800),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Resolution refined by engineer. PR will be tagged as Manually Refined.',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.blue.shade900,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (requiresReview) ...[
            InkWell(
              onTap: () => setState(() => _humanApproved = !_humanApproved),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Checkbox(
                      key: const Key('checkbox-human-approval'),
                      value: _humanApproved,
                      onChanged: (val) => setState(() => _humanApproved = val ?? false),
                    ),
                    const Expanded(
                      child: Text(
                        'I have reviewed the patch & authorize opening a Pull Request',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],

          if (_prErrorMessage != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _prErrorMessage!,
                style: TextStyle(fontSize: 13, color: theme.colorScheme.onErrorContainer),
              ),
            ),
            const SizedBox(height: 16),
          ],

          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              key: const Key('btn-deploy-pr'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                backgroundColor: isReady
                    ? Colors.green.shade700
                    : requiresReview
                        ? Colors.amber.shade800
                        : Colors.grey.shade400,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: (_isGeneratingPr ||
                      isBlocked ||
                      (requiresReview && !_humanApproved))
                  ? null
                  : _triggerPrGate,
              icon: _isGeneratingPr
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Icon(
                      requiresReview
                          ? Icons.verified_rounded
                          : Icons.rocket_launch_rounded,
                      size: 18,
                    ),
              label: Text(
                _isGeneratingPr
                    ? 'Creating PR...'
                    : requiresReview
                        ? 'Authorize & Deploy PR'
                        : isBlocked
                            ? 'PR Gate Locked'
                            : 'Deploy Pull Request',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
          ),
          const SizedBox(height: 12),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              key: const Key('btn-reject-fix'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                foregroundColor: Colors.red.shade700,
                side: BorderSide(color: Colors.red.shade300),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: _isGeneratingPr ? null : _showRejectDialog,
              icon: const Icon(Icons.thumb_down_alt_outlined, size: 18),
              label: const Text('Reject Proposed Fix', style: TextStyle(fontSize: 14)),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Tab 2: Confidence & Evidence Audit ───

  Widget _buildTabConfidenceAndEvidence(ThemeData theme) {
    final conf = _result?.systemConfidenceReport;
    final evidence = _result?.evidenceReport;
    final breakdown = conf?.confidenceBreakdown ?? {};

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const BugSenseSectionHeader(title: 'Confidence Signal Composition'),
        const SizedBox(height: 8),

        _buildSignalMeterRow(
          theme,
          label: 'LLM Self-Confidence',
          weight: '30%',
          score: breakdown['llm_self_confidence'] ?? 0.0,
          color: Colors.blue,
        ),
        _buildSignalMeterRow(
          theme,
          label: 'Evidence Validator Score',
          weight: '40%',
          score: breakdown['evidence_validator_score'] ?? 0.0,
          color: Colors.teal,
        ),
        _buildSignalMeterRow(
          theme,
          label: 'RAG Semantic Similarity',
          weight: '15%',
          score: breakdown['rag_avg_similarity'] ?? 0.0,
          color: Colors.purple,
        ),
        _buildSignalMeterRow(
          theme,
          label: 'Simplicity (Inverse Complexity)',
          weight: '15%',
          score: breakdown['inverse_complexity'] ?? 0.0,
          color: Colors.orange,
        ),
        const SizedBox(height: 24),

        if (conf != null && conf.penaltiesApplied.isNotEmpty) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFDA3633).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFDA3633).withValues(alpha: 0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.remove_circle_outline, size: 18, color: Colors.red.shade800),
                    const SizedBox(width: 8),
                    Text(
                      'Multiplicative Penalties Applied (${conf.penaltiesApplied.length})',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.red.shade900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                ...conf.penaltiesApplied.map(
                  (p) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 4, right: 6),
                          child: Icon(Icons.circle, size: 6, color: Colors.red.shade700),
                        ),
                        Expanded(
                          child: Text(
                            p,
                            style: TextStyle(fontSize: 13, height: 1.4, color: Colors.red.shade900),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],

        if (evidence != null) ...[
          const BugSenseSectionHeader(title: 'Evidence Validator Report'),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Deterministic Verdict',
                        style: TextStyle(fontSize: 14, color: theme.colorScheme.onSurfaceVariant),
                      ),
                      BugSenseChip(
                        label: evidence.verdict,
                        color: _evidenceVerdictColor(evidence.verdict),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _buildMiniStat(
                          'Verified Claims',
                          '${evidence.verifiedClaimsCount}',
                          Colors.green.shade600,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildMiniStat(
                          'Unverified',
                          '${evidence.unverifiedClaimsCount}',
                          Colors.orange.shade700,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildMiniStat(
                          'Evidence Score',
                          '${(evidence.evidenceScore * 100).toInt()}%',
                          Colors.teal.shade600,
                        ),
                      ),
                    ],
                  ),
                  if (evidence.recommendations.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const Divider(),
                    const SizedBox(height: 12),
                    const Text(
                      'Recommendations',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    ...evidence.recommendations.map((r) => Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Icon(Icons.arrow_right_rounded, size: 20, color: theme.colorScheme.primary),
                              ),
                              Expanded(
                                child: Text(r, style: const TextStyle(fontSize: 13, height: 1.4)),
                              ),
                            ],
                          ),
                        )),
                  ],
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  // ─── Tab 3: Route & Adaptation Log ───

  Widget _buildTabRouteAndAudit(ThemeData theme) {
    final routePlan = _result?.routePlan;
    final stages = _result?.stagesExecuted ?? [];
    final adaptationLog = _result?.adaptationLog ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (routePlan != null) ...[
          _buildCard(
            theme,
            title: 'Routing Strategy Rationale',
            icon: Icons.alt_route_rounded,
            color: _routeColor(routePlan.route),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  routePlan.rationale,
                  style: const TextStyle(fontSize: 14, height: 1.5),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    BugSenseChip(
                      icon: Icons.speed_rounded,
                      label: 'Latency: ${routePlan.planningLatencyMs.toStringAsFixed(1)}ms',
                      color: Colors.blueGrey,
                    ),
                    BugSenseChip(
                      icon: Icons.security_rounded,
                      label: 'Confidence Gate: ${(routePlan.confidenceGate * 100).toInt()}%',
                      color: Colors.indigo,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],

        const BugSenseSectionHeader(title: 'Pipeline Execution Stages'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: stages.map((s) {
            return Chip(
              avatar: const Icon(Icons.check_circle, size: 16, color: Colors.green),
              label: Text(s, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              side: BorderSide.none,
            );
          }).toList(),
        ),
        const SizedBox(height: 32),

        if (adaptationLog.isNotEmpty) ...[
          const BugSenseSectionHeader(title: 'Dynamic Adaptation Event Log'),
          ...adaptationLog.map((log) => _buildLogItem(theme, log)),
        ],
      ],
    );
  }

  // ─── Helpers & Widgets ───

  Widget _buildSignalMeterRow(
    ThemeData theme, {
    required String label,
    required String weight,
    required double score,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$label ($weight)',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
              Text(
                '${(score * 100).toInt()}%',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: score.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: color.withValues(alpha: 0.15),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniStat(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildLogItem(ThemeData theme, Map<String, dynamic> log) {
    final action = log['action'] ?? log['event'] ?? 'ADAPTATION';
    final reason = log['reason'] ?? log['message'] ?? log.toString();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.4),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.subdirectory_arrow_right_rounded, size: 20, color: theme.colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  action.toString().toUpperCase(),
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  reason.toString(),
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.4,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCodeSnippetCard(ThemeData theme, dynamic cs, [int index = 0]) {
    final file = cs.fileOrComponent ?? 'Patch';
    final code = cs.codeSnippet ?? '';
    final explanation = cs.explanation ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.6),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(11)),
            ),
            child: Row(
              children: [
                const Icon(Icons.code_rounded, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    file,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                ),
                IconButton(
                  key: Key('btn-edit-snippet-$index'),
                  icon: const Icon(Icons.edit_note_rounded, size: 18),
                  tooltip: 'Refine code snippet',
                  onPressed: () {
                    if (cs is CodeSuggestion) {
                      _showEditSnippetDialog(cs, index);
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.copy_rounded, size: 16),
                  tooltip: 'Copy snippet',
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: code));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Code snippet copied!')),
                    );
                  },
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            color: const Color(0xFF1E1E1E),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Text(
                code,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 13,
                  color: Color(0xFFD4D4D4),
                  height: 1.5,
                ),
              ),
            ),
          ),
          if (explanation.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                explanation,
                style: TextStyle(
                  fontSize: 13,
                  height: 1.4,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCard(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: color.withValues(alpha: 0.3)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: color),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color),
                ),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }

  Widget _buildListCard(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required Color color,
    required List<String> items,
    required bool isNumbered,
  }) {
    return _buildCard(
      theme,
      title: title,
      icon: icon,
      color: color,
      child: Column(
        children: items.asMap().entries.map((e) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isNumbered)
                  Container(
                    width: 24,
                    height: 24,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${e.key + 1}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.only(right: 10, top: 2),
                    child: Icon(Icons.check_circle_outline, size: 18, color: color),
                  ),
                if (isNumbered) const SizedBox(width: 12),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(top: isNumbered ? 2 : 0),
                    child: Text(
                      e.value,
                      style: const TextStyle(fontSize: 14, height: 1.5),
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  // ─── Style Mappings ───

  Color _statusColor(String status) {
    switch (status) {
      case 'READY_FOR_PR':
        return Colors.green.shade700;
      case 'REQUIRES_HUMAN_REVIEW':
        return Colors.amber.shade800;
      case 'LOW_CONFIDENCE':
        return Colors.red.shade700;
      case 'ABORTED':
        return Colors.blueGrey;
      default:
        return Colors.grey.shade700;
    }
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'READY_FOR_PR':
        return Icons.check_circle_rounded;
      case 'REQUIRES_HUMAN_REVIEW':
        return Icons.warning_rounded;
      case 'LOW_CONFIDENCE':
        return Icons.cancel_rounded;
      case 'ABORTED':
        return Icons.stop_circle_rounded;
      default:
        return Icons.help_outline;
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'READY_FOR_PR':
        return 'READY FOR PR';
      case 'REQUIRES_HUMAN_REVIEW':
        return 'HUMAN REVIEW REQUIRED';
      case 'LOW_CONFIDENCE':
        return 'LOW CONFIDENCE';
      case 'ABORTED':
        return 'PIPELINE ABORTED';
      default:
        return status;
    }
  }

  String _statusExplanation(String status) {
    switch (status) {
      case 'READY_FOR_PR':
        return 'Autonomous PR gate is unlocked. Evidence verifies resolution.';
      case 'REQUIRES_HUMAN_REVIEW':
        return 'Manual sign-off required before PR creation can proceed.';
      case 'LOW_CONFIDENCE':
        return 'PR creation disabled to prevent hallucinated code changes.';
      case 'ABORTED':
        return 'Pipeline halted early by adaptive confidence gate.';
      default:
        return '';
    }
  }

  Color _routeColor(String route) {
    switch (route) {
      case 'FAST_TRACK':
        return Colors.green.shade700;
      case 'STANDARD':
        return Colors.blue.shade700;
      case 'DEEP_INVESTIGATION':
        return Colors.purple.shade700;
      case 'NEEDS_CLARIFICATION':
        return Colors.orange.shade800;
      default:
        return Colors.grey.shade700;
    }
  }

  String _complexityLabel(double score) {
    if (score < 0.25) return 'Low';
    if (score < 0.55) return 'Medium';
    if (score < 0.80) return 'High';
    return 'Critical';
  }

  Color _complexityColor(String level) {
    switch (level) {
      case 'Low':
        return Colors.green.shade700;
      case 'Medium':
        return Colors.blue.shade700;
      case 'High':
        return Colors.orange.shade800;
      case 'Critical':
        return Colors.red.shade700;
      default:
        return Colors.grey.shade700;
    }
  }

  Color _evidenceVerdictColor(String verdict) {
    switch (verdict) {
      case 'SUFFICIENT':
        return Colors.green.shade700;
      case 'WEAK':
        return Colors.orange.shade800;
      case 'INSUFFICIENT':
        return Colors.red.shade700;
      default:
        return Colors.grey.shade700;
    }
  }
}
