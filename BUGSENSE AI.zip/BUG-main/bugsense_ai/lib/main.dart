import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:app_links/app_links.dart';

import 'models/user_model.dart';
import 'screens/login_screen.dart';
import 'screens/repositories_screen.dart';
import 'screens/welcome_screen.dart';
import 'services/api_service.dart';

void main() {
  runApp(const BugSenseApp());
}

class BugSenseApp extends StatefulWidget {
  const BugSenseApp({super.key});

  @override
  State<BugSenseApp> createState() => _BugSenseAppState();
}

class _BugSenseAppState extends State<BugSenseApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  BugSenseUser? _currentBugSenseUser;
  GitHubUser? _currentGitHubUser;
  String? _currentToken;
  bool _isRestoringSession = true;
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  final ApiService _api = ApiService();

  // Deep-link handling at app root level so OAuth callbacks are never missed
  late AppLinks _appLinks;
  StreamSubscription<Uri>? _linkSubscription;
  String? _lastProcessedCode;

  @override
  void initState() {
    super.initState();
    _tryRestoreSession();
    _initDeepLinks();
  }

  @override
  void dispose() {
    _linkSubscription?.cancel();
    super.dispose();
  }

  // ──────────────────────────────────────────────
  // Session restoration
  // ──────────────────────────────────────────────

  Future<void> _tryRestoreSession() async {
    try {
      final sessionToken =
          await _secureStorage.read(key: 'bugsense_session_token');
      if (sessionToken == null || sessionToken.isEmpty) {
        if (mounted) setState(() => _isRestoringSession = false);
        return;
      }
      final sessionInfo = await _api.getSessionInfo(sessionToken: sessionToken);
      
      if (sessionInfo['type'] == 'bugsense') {
        _currentBugSenseUser = BugSenseUser.fromJson(sessionInfo);
        // If github is connected, fetch the github user
        if (_currentBugSenseUser!.githubUserId != null) {
          try {
            _currentGitHubUser = await _api.getAuthenticatedUser(token: sessionToken);
          } catch (_) {}
        }
      } else {
        // Legacy GitHub session
        _currentGitHubUser = await _api.getAuthenticatedUser(token: sessionToken);
      }

      if (mounted) {
        setState(() {
          _currentToken = sessionToken;
          _isRestoringSession = false;
        });
      }
    } catch (_) {
      await _secureStorage.delete(key: 'bugsense_session_token');
      if (mounted) setState(() => _isRestoringSession = false);
    }
  }

  // ──────────────────────────────────────────────
  // Deep-link handling (OAuth callback)
  // ──────────────────────────────────────────────

  Future<void> _initDeepLinks() async {
    _appLinks = AppLinks();

    // Check initial link if app was cold started via a deep link
    try {
      final initialUri = await _appLinks.getInitialLink();
      if (initialUri != null) {
        _handleDeepLink(initialUri);
      }
    } catch (_) {
      // Ignore initial link errors
    }

    // Listen to incoming deep links while app is running
    _linkSubscription = _appLinks.uriLinkStream.listen((uri) {
      _handleDeepLink(uri);
    }, onError: (_) {
      // Ignore stream errors
    });
  }

  Future<void> _handleDeepLink(Uri uri) async {
    debugPrint('OAUTH_04_CALLBACK');
    debugPrint('[DeepLink] Received: $uri (scheme=${uri.scheme}, host=${uri.host}, path=${uri.path})');
    final isCustomScheme = uri.scheme == 'bugsense' &&
        (uri.host == 'callback' || uri.path.contains('callback'));
    final isAppLink = uri.path.contains('/auth/callback') ||
        uri.path.contains('/callback');
    if (!isCustomScheme && !isAppLink) {
      debugPrint('[DeepLink] Ignored: not an OAuth callback');
      return;
    }
    debugPrint('OAUTH_05_CALLBACK_PARSED');

    final error = uri.queryParameters['error'];
    if (error != null) {
      debugPrint('[DeepLink] OAuth error in deep link: $error');
      return;
    }

    final code = uri.queryParameters['code'];
    if (code == null || code.isEmpty) {
      debugPrint('[DeepLink] No code parameter in deep link');
      return;
    }

    // Deduplication guard
    if (code == _lastProcessedCode) {
      debugPrint('[DeepLink] Duplicate code ignored: $code');
      return;
    }
    _lastProcessedCode = code;
    debugPrint('OAUTH_06_HANDOFF');

    try {
      debugPrint('OAUTH_07_EXCHANGE');
      final result = await _api.exchangeCallbackCode(code: code);
      final sessionToken = result['session_token'] as String?;
      if (sessionToken == null || sessionToken.isEmpty) {
        debugPrint('[DeepLink] Missing session_token in exchange result');
        return;
      }

      await _secureStorage.write(
        key: 'bugsense_session_token',
        value: sessionToken,
      );

      final userJson = result['user'] as Map<String, dynamic>?;
      GitHubUser? user;
      if (userJson != null) {
        user = GitHubUser.fromJson(userJson);
      } else {
        user = await _api.getAuthenticatedUser(token: sessionToken);
      }
      debugPrint('OAUTH_08_SESSION: user=${user.login}');

      if (mounted) {
        _handleLoginSuccess(user, sessionToken);
      }
    } catch (e, st) {
      debugPrint('[DeepLink] Exception during exchange: $e\n$st');
    }
  }

  // ──────────────────────────────────────────────
  // Auth lifecycle callbacks
  // ──────────────────────────────────────────────

  void _handleLoginSuccess(dynamic user, String? token) async {
    debugPrint('LOGIN_DEBUG_11_ON_LOGIN_SUCCESS');
    if (token != null && token.isNotEmpty) {
      debugPrint('LOGIN_DEBUG_09_SESSION_WRITE_START');
      await _secureStorage.write(
        key: 'bugsense_session_token',
        value: token,
      );
      debugPrint('LOGIN_DEBUG_10_SESSION_WRITE_COMPLETE');
    }
    setState(() {
      if (user is BugSenseUser) {
        _currentBugSenseUser = user;
      } else if (user is GitHubUser) {
        _currentGitHubUser = user;
      }
      if (token != null) {
        _currentToken = token;
      }
    });
    debugPrint('LOGIN_DEBUG_12_MAIN_AUTH_STATE_UPDATED');

    debugPrint('OAUTH_09_REPOSITORIES_REQUEST');
    if (_currentBugSenseUser != null) {
      if (_currentGitHubUser != null) {
        _navigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (_) => RepositoriesScreen(
              user: _currentGitHubUser!,
              token: _currentToken,
              onSignOut: _handleSignOut,
              onDeleteAccount: _handleDeleteAccount,
            ),
          ),
          (route) => false,
        );
      } else {
        _navigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (_) => WelcomeScreen(
              user: _currentBugSenseUser!,
              onLoginSuccess: _handleLoginSuccess,
              onSignOut: _handleSignOut,
            ),
          ),
          (route) => false,
        );
      }
    } else if (_currentGitHubUser != null) {
      _navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => RepositoriesScreen(
            user: _currentGitHubUser!,
            token: _currentToken,
            onSignOut: _handleSignOut,
            onDeleteAccount: _handleDeleteAccount,
          ),
        ),
        (route) => false,
      );
    }
    debugPrint('GITHUB_FLOW_12_NAVIGATION_TO_REPOS_COMPLETE');
  }

  Future<void> _handleSignOut() async {
    // Invalidate server-side session if we have a token
    if (_currentToken != null && _currentToken!.isNotEmpty) {
      try {
        await _api.logout(sessionToken: _currentToken!);
      } catch (_) {
        // Best-effort: proceed with local logout even if server call fails
      }
    }
    await _performLocalLogout();
  }

  Future<void> _handleDeleteAccount() async {
    if (_currentToken != null && _currentToken!.isNotEmpty) {
      try {
        await _api.deleteAccount(sessionToken: _currentToken!);
      } catch (e) {
        debugPrint('Account deletion failed: $e');
        // Do not perform local logout if account deletion failed, 
        // to not leave the user believing it was complete.
        rethrow;
      }
    }
    await _performLocalLogout();
  }

  Future<void> _performLocalLogout() async {
    // Clear secure storage
    await _secureStorage.delete(key: 'bugsense_session_token');
    _lastProcessedCode = null;

    setState(() {
      _currentBugSenseUser = null;
      _currentGitHubUser = null;
      _currentToken = null;
    });

    _navigatorKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => LoginScreen(onLoginSuccess: _handleLoginSuccess),
      ),
      (route) => false,
    );
  }

  // ──────────────────────────────────────────────
  // Build
  // ──────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigatorKey,
      title: 'BugSense AI',
      debugShowCheckedModeBanner: false,
      onUnknownRoute: (settings) {
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            backgroundColor: const Color(0xFF0D1117),
            body: const Center(
              child: CircularProgressIndicator(color: Color(0xFF7F56D9)),
            ),
          ),
        );
      },
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF53389E),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF9FAFB),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
          scrolledUnderElevation: 1,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.grey.shade200),
          ),
          color: Colors.white,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF53389E), width: 1.8),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          ),
        ),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7F56D9),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        scaffoldBackgroundColor:
            const Color(0xFF0D1117), // GitHub Deep Charcoal
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
          scrolledUnderElevation: 1,
          backgroundColor: Color(0xFF0D1117),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(
                color: Color(0xFF30363D)), // GitHub Subtle Border
          ),
          color: const Color(0xFF161B22), // GitHub Card Surface
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF161B22),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF30363D)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF30363D)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF7F56D9), width: 1.8),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          ),
        ),
      ),
      home: _buildHome(),
    );
  }

  Widget _buildHome() {
    // Show a branded splash while restoring session
    if (_isRestoringSession) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D1117),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.pest_control_rounded,
                  size: 64, color: Color(0xFF7F56D9)),
              SizedBox(height: 24),
              Text(
                'BugSense AI',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(height: 16),
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: Color(0xFF7F56D9),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_currentBugSenseUser != null) {
      if (_currentGitHubUser != null) {
        return RepositoriesScreen(
          user: _currentGitHubUser!,
          token: _currentToken,
          onSignOut: _handleSignOut,
          onDeleteAccount: _handleDeleteAccount,
        );
      } else {
        return WelcomeScreen(
          user: _currentBugSenseUser!,
          onLoginSuccess: _handleLoginSuccess,
          onSignOut: _handleSignOut,
        );
      }
    } else if (_currentGitHubUser != null) {
      // Legacy or GitHub only session
      return RepositoriesScreen(
        user: _currentGitHubUser!,
        token: _currentToken,
        onSignOut: _handleSignOut,
        onDeleteAccount: _handleDeleteAccount,
      );
    }

    return LoginScreen(onLoginSuccess: _handleLoginSuccess);
  }
}
