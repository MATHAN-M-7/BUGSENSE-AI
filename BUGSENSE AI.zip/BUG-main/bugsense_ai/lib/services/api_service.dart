import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/adaptive_models.dart';
import '../models/repo_model.dart';
import '../models/user_model.dart';

/// Centralized API client for the BugSense AI backend.
///
/// In release mode, connects to the production Render backend.
/// In debug mode, connects to localhost (with emulator fallback).
class ApiService {
  // Production: Render backend. Debug: local development server.
  static String _baseUrl = 'https://bugsense-backend-qiup.onrender.com';
  static const String _fallbackUrl = 'https://bugsense-backend-qiup.onrender.com';

  Map<String, String> _buildHeaders(String? token) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  /// Pings [GET /health] and returns the decoded JSON map,
  /// or throws on failure.
  Future<Map<String, dynamic>> healthCheck() async {
    try {
      final uri = Uri.parse('$_baseUrl/health');
      final response = await http
          .get(uri)
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        return jsonDecode(response.body) as Map<String, dynamic>;
      }
    } catch (_) {
      try {
        final fallbackUri = Uri.parse('$_fallbackUrl/health');
        final response = await http
            .get(fallbackUri)
            .timeout(const Duration(seconds: 4));
        if (response.statusCode == 200) {
          _baseUrl = _fallbackUrl;
          return jsonDecode(response.body) as Map<String, dynamic>;
        }
      } catch (_) {}
      rethrow;
    }
    throw Exception('Backend returned error');
  }

  /// Fetches the authenticated GitHub user profile via [GET /github/user].
  Future<GitHubUser> getAuthenticatedUser({String? token}) async {
    final uri = Uri.parse('$_baseUrl/github/user');
    final response = await http
        .get(uri, headers: _buildHeaders(token))
        .timeout(const Duration(seconds: 30));

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      return GitHubUser.fromJson(json);
    } else {
      throw Exception('SESSION_EXPIRED');
    }
  }

  /// Fetches repositories via [GET /github/repos].
  Future<List<GitHubRepo>> getRepositories({
    int perPage = 30,
    int page = 1,
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/github/repos?per_page=$perPage&page=$page');
    final response = await http
        .get(uri, headers: _buildHeaders(token))
        .timeout(const Duration(seconds: 12));

    if (response.statusCode == 200) {
      final list = jsonDecode(response.body) as List<dynamic>;
      return list
          .map((item) => GitHubRepo.fromJson(item as Map<String, dynamic>))
          .toList();
    } else {
      final body = jsonDecode(response.body);
      final detail = body is Map ? body['detail'] ?? response.body : response.body;
      throw Exception('Failed to get repositories ($detail)');
    }
  }

  /// Fetches details for a specific repository via [GET /github/repos/{owner}/{repo}].
  Future<GitHubRepo> getRepo(
    String owner,
    String repo, {
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/github/repos/$owner/$repo');
    final response = await http
        .get(uri, headers: _buildHeaders(token))
        .timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      return GitHubRepo.fromJson(json);
    } else {
      throw Exception('Failed to get repo details (${response.statusCode})');
    }
  }

  /// Fetches issues for a specific repository via [GET /github/repos/{owner}/{repo}/issues].
  Future<List<Map<String, dynamic>>> getRepoIssues(
    String owner,
    String repo, {
    String state = 'all',
    int perPage = 20,
    String? token,
  }) async {
    final uri = Uri.parse(
      '$_baseUrl/github/repos/$owner/$repo/issues?state=$state&per_page=$perPage',
    );
    final response = await http
        .get(uri, headers: _buildHeaders(token))
        .timeout(const Duration(seconds: 12));

    if (response.statusCode == 200) {
      final list = jsonDecode(response.body) as List<dynamic>;
      return list.cast<Map<String, dynamic>>();
    } else {
      throw Exception('Failed to get issues (${response.statusCode})');
    }
  }

  /// Fetches the GitHub OAuth authorization URL from [GET /auth/github/login].
  Future<Map<String, dynamic>> getOAuthLoginUrl() async {
    final uri = Uri.parse('$_baseUrl/auth/github/login');
    final response = await http
        .get(uri)
        .timeout(const Duration(seconds: 60));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      // Log technical detail in debug mode only; never expose to UI
      if (kDebugMode) {
        debugPrint('[ApiService] getOAuthLoginUrl error ${response.statusCode}: ${response.body}');
      }
      throw Exception('server_error');
    }
  }

  /// Exchanges an OAuth authorization code for a BugSense session token.
  /// The backend creates a server-side session and returns ONLY the session token.
  /// The GitHub access token NEVER reaches the client.
  Future<Map<String, dynamic>> exchangeOAuthCode({
    required String code,
    String? state,
  }) async {
    final uri = Uri.parse('$_baseUrl/auth/github/exchange');
    final payload = <String, dynamic>{
      'code': code,
    };
    if (state != null) {
      payload['state'] = state;
    }
    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
          body: jsonEncode(payload),
        )
        .timeout(const Duration(seconds: 60));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      if (kDebugMode) {
        debugPrint('[ApiService] exchangeOAuthCode error ${response.statusCode}: ${response.body}');
      }
      throw Exception('auth_failed');
    }
  }

  /// Exchanges a short-lived one-time callback handoff code for a BugSense session token.
  Future<Map<String, dynamic>> exchangeCallbackCode({
    required String code,
  }) async {
    final uri = Uri.parse('$_baseUrl/auth/github/exchange-callback-code');
    final payload = <String, dynamic>{
      'code': code,
    };
    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
          body: jsonEncode(payload),
        )
        .timeout(const Duration(seconds: 60));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      if (kDebugMode) {
        debugPrint('[ApiService] exchangeCallbackCode error ${response.statusCode}: ${response.body}');
      }
      throw Exception('auth_failed');
    }
  }

  /// Fetches session info for the current BugSense session token.
  Future<Map<String, dynamic>> getSessionInfo({required String sessionToken}) async {
    final uri = Uri.parse('$_baseUrl/auth/session');
    final response = await http
        .get(uri, headers: _buildHeaders(sessionToken))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      throw Exception('Session invalid or expired');
    }
  }

  /// Logs out: invalidates the server-side session.
  Future<void> logout({required String sessionToken}) async {
    final uri = Uri.parse('$_baseUrl/auth/session');
    await http
        .delete(uri, headers: _buildHeaders(sessionToken))
        .timeout(const Duration(seconds: 5));
  }

  Future<void> deleteAccount({required String sessionToken}) async {
    final uri = Uri.parse('$_baseUrl/auth/account');
    final response = await http
        .delete(uri, headers: _buildHeaders(sessionToken))
        .timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Failed to delete account: ${response.statusCode}');
    }
  }

  // ──────────────────────────────────────────────
  // BugSense Local Auth endpoints
  // ──────────────────────────────────────────────

  Future<Map<String, dynamic>> signup({
    required String fullName,
    required String username,
    required String email,
    required String password,
  }) async {
    final uri = Uri.parse('$_baseUrl/auth/signup');
    final payload = {
      'full_name': fullName,
      'username': username,
      'email': email,
      'password': password,
    };
    final response = await http
        .post(uri, headers: _buildHeaders(null), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      final msg = _extractDetail(response);
      throw Exception(msg);
    }
  }

  Future<Map<String, dynamic>> login({
    required String usernameOrEmail,
    required String password,
  }) async {
    final uri = Uri.parse('$_baseUrl/auth/login');
    final payload = {
      'username_or_email': usernameOrEmail,
      'password': password,
    };
    final response = await http
        .post(uri, headers: _buildHeaders(null), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 15));

    debugPrint('LOGIN_DEBUG_05_API_RESPONSE_RECEIVED');
    debugPrint('LOGIN_DEBUG_06_HTTP_STATUS_${response.statusCode}');

    if (response.statusCode == 200) {
      final parsed = jsonDecode(response.body) as Map<String, dynamic>;
      debugPrint('LOGIN_DEBUG_07_RESPONSE_PARSED');
      return parsed;
    } else {
      final msg = _extractDetail(response);
      throw Exception(msg);
    }
  }

  Future<Map<String, dynamic>> forgotPassword({
    required String email,
  }) async {
    final uri = Uri.parse('$_baseUrl/auth/forgot-password');
    final payload = {
      'email': email,
    };
    final response = await http
        .post(uri, headers: _buildHeaders(null), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      final msg = _extractDetail(response);
      throw Exception(msg);
    }
  }


  // ──────────────────────────────────────────────
  // AI Analysis endpoints
  // ──────────────────────────────────────────────

  /// Builds the common issue payload sent to all analysis endpoints.
  Map<String, dynamic> _issuePayload({
    required String owner,
    required String repo,
    required int? issueNumber,
    required String title,
    required String body,
    required String state,
    required List<String> labels,
  }) {
    return {
      'repo_owner': owner,
      'repo_name': repo,
      'issue_number': ?issueNumber,
      'title': title,
      'body': body,
      'state': state,
      'labels': labels,
    };
  }

  /// Classifies a GitHub issue via [POST /analysis/classify-rag].
  Future<ClassificationResult> classifyIssue({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    String? token,
  }) async {
    debugPrint('AI_01_START');
    final uri = Uri.parse('$_baseUrl/analysis/classify-rag');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    debugPrint('AI_02_RAG');
    debugPrint('AI_03_GEMINI_REQUEST');
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 90));

    debugPrint('AI_04_GEMINI_RESPONSE: ${response.statusCode}');
    if (response.statusCode == 200) {
      debugPrint('AI_05_PARSE');
      final result = ClassificationResult.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
      debugPrint('AI_06_CONFIDENCE: ${result.confidence}');
      debugPrint('AI_07_UI');
      return result;
    } else if (response.statusCode == 503) {
      final detail = _extractDetail(response);
      throw Exception('AI service unavailable: $detail');
    } else {
      final msg = _extractDetail(response);
      throw Exception('Classification failed ($msg)');
    }
  }

  /// Performs root cause analysis via [POST /analysis/root-cause].
  Future<RootCauseResult> analyzeRootCause({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    ClassificationResult? priorClassification,
    String? token,
  }) async {
    debugPrint('AI_01_START');
    final uri = Uri.parse('$_baseUrl/analysis/root-cause');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    if (priorClassification != null) {
      payload['classification'] = priorClassification.toPriorJson();
    }
    debugPrint('AI_02_RAG');
    debugPrint('AI_03_GEMINI_REQUEST');
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 90));

    debugPrint('AI_04_GEMINI_RESPONSE: ${response.statusCode}');
    if (response.statusCode == 200) {
      debugPrint('AI_05_PARSE');
      final result = RootCauseResult.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
      debugPrint('AI_06_CONFIDENCE: ${result.confidence}');
      debugPrint('AI_07_UI');
      return result;
    } else if (response.statusCode == 503) {
      final detail = _extractDetail(response);
      throw Exception('AI service unavailable: $detail');
    } else {
      final msg = _extractDetail(response);
      throw Exception('Root cause analysis failed ($msg)');
    }
  }

  /// Generates a fix / resolution via [POST /analysis/resolve].
  Future<ResolutionResult> resolveIssue({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    ClassificationResult? priorClassification,
    RootCauseResult? priorRootCause,
    String? token,
  }) async {
    debugPrint('AI_01_START');
    final uri = Uri.parse('$_baseUrl/analysis/resolve');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    if (priorClassification != null) {
      payload['classification'] = priorClassification.toPriorJson();
    }
    if (priorRootCause != null) {
      payload['root_cause'] = priorRootCause.toPriorJson();
    }
    debugPrint('AI_02_RAG');
    debugPrint('AI_03_GEMINI_REQUEST');
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 90));

    debugPrint('AI_04_GEMINI_RESPONSE: ${response.statusCode}');
    if (response.statusCode == 200) {
      debugPrint('AI_05_PARSE');
      final result = ResolutionResult.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
      debugPrint('AI_06_CONFIDENCE: ${result.confidence}');
      debugPrint('AI_07_UI');
      return result;
    } else if (response.statusCode == 503) {
      final detail = _extractDetail(response);
      throw Exception('AI service unavailable: $detail');
    } else {
      final msg = _extractDetail(response);
      throw Exception('Resolution failed ($msg)');
    }
  }

  // ──────────────────────────────────────────────
  // Phase 4 Adaptive Routing & Safe PR Gate
  // ──────────────────────────────────────────────

  /// Previews the zero-LLM complexity score & adaptive route plan via [POST /analysis/route/plan].
  Future<RoutePlan> planAdaptiveRoute({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/analysis/route/plan');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      return RoutePlan.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } else {
      final msg = _extractDetail(response);
      throw Exception('Route planning failed ($msg)');
    }
  }

  /// Evaluates full issue complexity signals via [POST /analysis/complexity].
  Future<ComplexityReport> analyzeComplexity({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/analysis/complexity');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      return ComplexityReport.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } else {
      final msg = _extractDetail(response);
      throw Exception('Complexity analysis failed ($msg)');
    }
  }

  /// Runs the full autonomous Phase 4 pipeline via [POST /analysis/route].
  Future<AdaptiveRoutingResult> runAdaptivePipeline({
    required String owner,
    required String repo,
    int? issueNumber,
    required String title,
    String body = '',
    String state = 'open',
    List<String> labels = const [],
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/analysis/route');
    final payload = _issuePayload(
      owner: owner,
      repo: repo,
      issueNumber: issueNumber,
      title: title,
      body: body,
      state: state,
      labels: labels,
    );
    final response = await http
        .post(uri, headers: _buildHeaders(token), body: jsonEncode(payload))
        .timeout(const Duration(seconds: 120));

    if (response.statusCode == 200) {
      return AdaptiveRoutingResult.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } else if (response.statusCode == 503) {
      final detail = _extractDetail(response);
      throw Exception('AI service unavailable: $detail');
    } else {
      final msg = _extractDetail(response);
      throw Exception('Adaptive pipeline failed ($msg)');
    }
  }

  /// Safe PR Gate: generates a GitHub PR via [POST /github/repos/{owner}/{repo}/issues/{issue_number}/generate-pr].
  Future<PullRequestResult> generatePullRequest({
    required String owner,
    required String repo,
    required int issueNumber,
    required Map<String, dynamic> routingResultJson,
    bool humanApproved = false,
    String? token,
  }) async {
    final uri = Uri.parse(
      '$_baseUrl/github/repos/$owner/$repo/issues/$issueNumber/generate-pr?human_approved=$humanApproved',
    );
    final response = await http
        .post(
          uri,
          headers: _buildHeaders(token),
          body: jsonEncode(routingResultJson),
        )
        .timeout(const Duration(seconds: 30));

    if (response.statusCode == 200) {
      return PullRequestResult.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } else if (response.statusCode == 403) {
      final body = jsonDecode(response.body);
      final detail = body is Map ? body['detail'] : null;
      if (detail is Map) {
        final message = detail['message'] ?? 'Confidence gate rejected PR.';
        final status = detail['system_status'] ?? '';
        final penalties = detail['penalties'] is List
            ? (detail['penalties'] as List).join(' ')
            : '';
        throw Exception('$message (Status: $status. $penalties)');
      }
      throw Exception('Confidence gate rejected PR creation (403)');
    } else {
      final msg = _extractDetail(response);
      throw Exception('PR creation failed ($msg)');
    }
  }

  /// Records a human-in-the-loop review verdict (APPROVE, EDIT, REJECT) via [POST /analysis/review/verdict].
  Future<ReviewVerdict> submitReviewVerdict({
    required String owner,
    required String repo,
    required int issueNumber,
    required String verdict, // APPROVED, EDITED, REJECTED
    String reviewer = 'mobile_reviewer',
    String? rejectionReason,
    Map<String, dynamic>? editedResolution,
    String notes = '',
    String? token,
  }) async {
    final uri = Uri.parse('$_baseUrl/analysis/review/verdict');
    final payload = {
      'repo_owner': owner,
      'repo_name': repo,
      'issue_number': issueNumber,
      'verdict': verdict,
      'reviewer': reviewer,
      'rejection_reason': ?rejectionReason,
      'edited_resolution': ?editedResolution,
      'notes': notes,
    };
    final response = await http
        .post(
          uri,
          headers: _buildHeaders(token),
          body: jsonEncode(payload),
        )
        .timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      return ReviewVerdict.fromJson(
        jsonDecode(response.body) as Map<String, dynamic>,
      );
    } else {
      final msg = _extractDetail(response);
      throw Exception('Failed to record review verdict ($msg)');
    }
  }

  String _extractDetail(http.Response response) {
    try {
      final body = jsonDecode(response.body);
      if (body is Map && body.containsKey('detail')) {
        final detail = body['detail'].toString();
        final lowerDetail = detail.toLowerCase();
        if (lowerDetail.contains('traceback') || 
            lowerDetail.contains('runtimeerror') || 
            lowerDetail.contains('api_key') ||
            lowerDetail.contains('token')) {
          return 'An unexpected system error occurred. Please try again later.';
        }
        return detail;
      }
    } catch (_) {}
    return 'Server error (${response.statusCode})';
  }
}
