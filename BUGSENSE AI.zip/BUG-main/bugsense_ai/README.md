# 🐞 BugSense AI — Mobile Client (Flutter)

The executive mobile client for **BugSense AI**, providing on-the-go triage, confidence telemetry, and the **Safe PR Gate** human-in-the-loop review interface.

---

## 📱 Features

- **GitHub OAuth 2.0 & PAT Sign-In**: Authenticate securely directly with your GitHub account.
- **Repository & Issue Browser**: Live synchronisation of user repositories and issue lists.
- **Three-Stage Issue Triage**:
  - **Classification**: Categorization (`Bug`, `Feature`, `Security`, `Performance`) and severity ratings.
  - **Root Cause Analysis**: Identifies root defects, affected modules, and reproduction steps.
  - **Resolution Synthesis**: Code suggestions with syntax highlighting and step-by-step implementation strategy.
- **Safe PR Gate & Executive Review Screen (`MobileReviewScreen`)**:
  - Visual confidence gauge computed from deterministic evidence and RAG similarity.
  - Automatic locking of direct PR deployment when confidence is below safety thresholds (< 50%).
  - Human review workflow: **Approve**, **Inline Code Editor** to adjust code snippets, or **Reject** with categorized reasons.
  - Comprehensive Audit and Evidence tabs.

---

## 🛠️ Getting Started

### Prerequisites
- Flutter SDK 3.13+ (`dart --version` >= 3.1)
- Android physical device or emulator
- Android Platform Tools (`adb`)
- Running BugSense AI backend (`http://localhost:8000`)

### Setup & Launch

1. Connect your Android device via USB with USB Debugging enabled.
2. Setup ADB reverse port forwarding to communicate with the local backend:
   ```bash
   adb reverse tcp:8000 tcp:8000
   ```
3. Fetch dependencies:
   ```bash
   flutter pub get
   ```
4. Run the application:
   ```bash
   flutter run
   ```

For full system architecture and backend setup, refer to the [Root README](../README.md).
