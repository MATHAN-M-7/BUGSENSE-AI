package com.bugsense.bugsense_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
