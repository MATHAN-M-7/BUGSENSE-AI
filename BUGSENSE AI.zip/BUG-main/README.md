# 🐞 BugSense AI

<p align="center">
  <strong>Autonomous, Confidence-Aware GitHub Issue Resolution Platform</strong><br>
  <em>Powered by Multi-Agent AI, Semantic RAG, and Human-in-the-Loop Safe PR Gates</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Flutter-3.13+-02569B?style=for-the-badge&logo=flutter&logoColor=white" alt="Flutter" />
  <img src="https://img.shields.io/badge/FastAPI-0.115+-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI" />
  <img src="https://img.shields.io/badge/Google%20Gemini-Flash-4285F4?style=for-the-badge&logo=google&logoColor=white" alt="Gemini" />
  <img src="https://img.shields.io/badge/ChromaDB-Vector%20Store-FF6F00?style=for-the-badge&logoColor=white" alt="ChromaDB" />
  <img src="https://img.shields.io/badge/Firebase-Firestore-FFA000?style=for-the-badge&logo=firebase&logoColor=white" alt="Firebase" />
  <img src="https://img.shields.io/badge/License-MIT-blue?style=for-the-badge" alt="License" />
</p>

---

## 📌 Overview

**BugSense AI** is an intelligent, developer-first autonomous issue triage and resolution platform designed to bridge repository issues and validated pull requests. It eliminates hallucinated, breaking code changes by combining **Adaptive Multi-Agent Routing**, **Retrieval-Augmented Generation (RAG)** over local codebases, **Deterministic Evidence Validation**, and a **Mobile Executive Safe PR Gate** with human sign-off.

### Why BugSense AI?
Traditional autonomous coding agents often suffer from:
- **Hallucinated fixes** applied to non-existent functions or outdated APIs.
- **Unchecked Pull Requests** automatically merging into main repositories.
- **Lack of transparency** regarding how confident the AI model was in proposing a fix.

**BugSense AI solves this** by computing a weighted, multi-signal confidence score for every issue. If confidence drops below threshold or penalties are applied, the **Safe PR Gate locks direct deployment**, alerting engineers via a mobile dashboard to review, edit, or reject the proposed code patch before any PR is created.

---

## ✨ Key Features

### 🧠 1. Adaptive Multi-Agent Pipeline
- **Issue Classification**: Accurately classifies incoming issues (`Bug`, `Feature`, `Security`, `Performance`, `Documentation`) with automated severity rating (`Low`, `Medium`, `High`, `Critical`).
- **Dynamic Route Selection**: Routes issues based on complexity analysis:
  - `DIRECT`: For simple, localized defects.
  - `STANDARD`: Balanced analysis with single-pass semantic RAG.
  - `DEEP_RAG`: Multi-file dependency tracing for complex architecture.
  - `MULTI_AGENT`: Coordinated triage and resolution synthesis for high-risk bugs.

### 🔍 2. Codebase Semantic Search (RAG)
- Indexes repository source trees into **ChromaDB** using vector embeddings.
- Retrieves high-relevance code snippets, class structures, and symbol definitions to ground LLM reasoning.

### 🛡️ 3. Deterministic Evidence Validator & Confidence Engine
- Cross-references LLM suggestions against ground-truth AST and repository index files.
- Computes a composite **System Confidence Score** based on:
  - **LLM Self-Confidence** (30%)
  - **Evidence Validator Score** (40%)
  - **RAG Semantic Similarity** (15%)
  - **Code Simplicity / Inverse Complexity** (15%)
- Applies multiplicative penalties for weak evidence, low similarity, or high complexity.

### 🚪 4. Safe PR Gate & Mobile Human Review
- **Automatic Gating**: Permanently locks direct PR deployment when system confidence is below 50% or safety penalties are active.
- **Full-Featured Mobile Review UI**:
  - **Fix & PR Tab**: View recommended fix, syntax-highlighted code suggestions, and implementation strategies.
  - **Evidence Tab**: Inspect validation breakdown, penalty reasons, and grounding files.
  - **Audit Tab**: Full chronological timeline of triage verdicts and review actions.
  - **Engineer Controls**: One-tap **Approve**, **Inline Code Editor** to refine snippets, or **Reject** with structured reason codes.

### 🔄 5. Seamless GitHub Integration & Webhooks
- Secure GitHub OAuth 2.0 and Personal Access Token (PAT) authentication.
- Real-time GitHub Webhook handling (`issues`, `issue_comment`, `pull_request`).
- Automated branch creation, commit staging, and PR opening with traceability markers.

---

## 🏗️ System Architecture

```mermaid
graph TD
    A[GitHub Issues / Webhooks] -->|Event Trigger| B[FastAPI Backend]
    M[Flutter Mobile App] <-->|REST API / Health| B

    subgraph "Backend Intelligence Engine"
        B --> C[OAuth / Auth Router]
        B --> D[GitHub Router]
        B --> E[Adaptive Pipeline Router]
        
        E --> F[Codebase Indexer]
        F --> G[(ChromaDB Vector Store)]
        G --> H[Semantic RAG Engine]
        
        E --> I[Multi-Agent LLM Coordinator]
        I <-->|Prompt & Schema| J[Google Gemini API]
        
        E --> K[Deterministic Evidence Validator]
        K --> L[Confidence Engine]
        
        L --> P{Safe PR Gate}
        P -->|Confidence >= 50% & Validated| Q[Automated PR Deployment]
        P -->|Confidence < 50% or Flagged| R[Require Human Sign-Off]
    end

    subgraph "Persistence & Audit"
        B <--> S[(Cloud Firestore)]
    end

    R -->|Push Alert / Live Review| M
    M -->|Approve / Refine / Reject| B
```

---

## 📁 Repository Structure

```text
BUG/
├── bugsense_ai/                # Mobile Client (Flutter Application)
│   ├── android/                # Native Android platform configurations
│   ├── lib/
│   │   ├── models/             # Data models (adaptive, review, repository)
│   │   ├── screens/            # UI Screens
│   │   │   ├── login_screen.dart           # GitHub OAuth & PAT sign-in
│   │   │   ├── repositories_screen.dart    # Repositories & indexing status
│   │   │   ├── issue_detail_screen.dart    # Issue triage & AI analysis
│   │   │   └── mobile_review_screen.dart   # Phase 4 Executive Safe PR Review
│   │   ├── services/           # HTTP API client & state management
│   │   └── main.dart           # Application entrypoint & theme
│   └── pubspec.yaml            # Flutter dependencies & metadata
│
├── bugsense_backend/           # Server API (FastAPI)
│   ├── chroma_data/            # Persistent ChromaDB vector storage
│   ├── routers/                # API Endpoints
│   │   ├── analysis.py         # AI triage, root-cause, resolution & pipeline
│   │   ├── auth.py             # GitHub OAuth 2.0 flow & token exchange
│   │   ├── firestore.py        # Cloud Firestore sync & review audit logs
│   │   ├── github.py           # GitHub REST API proxies (repos, issues, PRs)
│   │   ├── indexing.py         # Repository codebase parsing & vector indexing
│   │   ├── search.py           # ChromaDB semantic search endpoints
│   │   └── webhooks.py         # Real-time GitHub webhook verification
│   ├── services/               # Core intelligence & business logic
│   │   ├── adaptive_router.py  # Route planning & complexity scoring
│   │   ├── confidence_engine.py# Multi-signal confidence calculation
│   │   ├── evidence_validator.py# Deterministic symbol & ground-truth validation
│   │   ├── gemini_client.py    # Google Gemini GenAI SDK wrapper
│   │   ├── github_service.py   # GitHub branch, commit, and PR management
│   │   └── rag_service.py      # ChromaDB collection management & querying
│   ├── config.py               # Settings & environment configuration
│   ├── main.py                 # FastAPI application initialization & middleware
│   └── requirements.txt        # Python backend dependencies
│
├── .env.example                # Sample environment configuration template
└── README.md                   # Project documentation
```

---

## 🚀 Getting Started

### Prerequisites

Ensure you have the following installed on your development workstation:
- **Python**: 3.10+
- **Flutter SDK**: 3.13+ (`dart --version` >= 3.1)
- **Android SDK & Platform Tools**: `adb` available in your system `PATH`
- **Google Gemini API Key**: Obtain a key from [Google AI Studio](https://aistudio.google.com/)
- **GitHub Personal Access Token (PAT)**: With `repo` and `read:user` scopes
- **(Optional) Firebase Service Account**: For Cloud Firestore persistence

---

### 1. Backend Setup (FastAPI)

1. Navigate to the backend directory:
   ```bash
   cd bugsense_backend
   ```

2. Create and activate a Python virtual environment:
   ```bash
   # Windows (PowerShell)
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1

   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create your `.env` configuration file:
   ```bash
   cp .env.example .env
   ```

5. Edit `.env` with your credentials:
   ```env
   # Gemini AI Key
   GEMINI_API_KEY=your_gemini_api_key_here
   GEMINI_MODEL=gemini-3.1-flash-lite

   # GitHub Credentials
   GITHUB_TOKEN=ghp_your_github_pat_here
   GITHUB_CLIENT_ID=your_github_oauth_client_id
   GITHUB_CLIENT_SECRET=your_github_oauth_client_secret
   GITHUB_REDIRECT_URI=http://localhost:8000/auth/github/callback

   # ChromaDB Storage
   CHROMA_PERSIST_DIR=./chroma_data

   # Firebase Service Account (Optional)
   FIREBASE_CREDENTIALS_PATH=firebase-service-account.json
   ```

6. Start the FastAPI development server:
   ```bash
   python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

7. Verify health check:
   ```bash
   curl http://localhost:8000/health
   # Response: {"status":"ok","version":"0.18.0"}
   ```

---

### 2. Mobile App Setup (Flutter)

1. Connect your Android device via USB with **USB Debugging** enabled.

2. Enable reverse port forwarding so your phone can reach `localhost:8000`:
   ```bash
   adb reverse tcp:8000 tcp:8000
   ```

3. Verify connectivity from the device:
   ```bash
   adb shell curl -s http://127.0.0.1:8000/health
   ```

4. Navigate to the Flutter directory:
   ```bash
   cd ../bugsense_ai
   ```

5. Fetch Flutter dependencies:
   ```bash
   flutter pub get
   ```

6. Run the application on your connected Android phone:
   ```bash
   flutter run
   ```

---

## 📡 API Reference Overview

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Backend health check and version status |
| `GET` | `/auth/github/url` | Generates GitHub OAuth 2.0 authorization URL |
| `POST` | `/auth/github/token` | Exchanges authorization code for GitHub access token |
| `GET` | `/github/user` | Fetches authenticated GitHub user profile |
| `GET` | `/github/repos` | Lists repositories for the authenticated user |
| `GET` | `/github/repos/{owner}/{repo}/issues` | Fetches repository issues |
| `POST` | `/analysis/classify` | AI issue classification & severity estimation |
| `POST` | `/analysis/root-cause` | Root cause analysis & reproduction steps |
| `POST` | `/analysis/resolve` | Code patch synthesis & implementation strategy |
| `POST` | `/analysis/route` | Adaptive routing & complexity score calculation |
| `POST` | `/analysis/adaptive-pipeline/run` | Full end-to-end adaptive triage pipeline |
| `POST` | `/analysis/generate-pr` | Deploys validated PR (enforces Safe PR Gate) |
| `POST` | `/analysis/review/verdict` | Records human review verdicts (`APPROVED`, `EDITED`, `REJECTED`) |
| `POST` | `/indexing/index-repo` | Clones and indexes repository into ChromaDB |
| `POST` | `/search/query` | Semantic search over indexed code snippets |
| `POST` | `/webhooks/github` | Real-time webhook receiver for repository events |

---

## 🧪 Testing

### Backend Unit & Integration Tests
Run backend test suites covering all components (Router, RAG, Classifier, Validator, Safe PR Gate):
```bash
cd bugsense_backend
pytest
```

### Flutter Static Analysis & Tests
Verify code formatting and automated widget tests:
```bash
cd bugsense_ai
flutter analyze
flutter test
```

---

## 🔒 Security Guarantees

- **No Secret Leaks**: GitHub PATs, Gemini API keys, and Firebase service account credentials are kept strictly in `.env` or memory and never committed to version control.
- **Safe PR Gate**: The platform cannot open automated pull requests when confidence is below 50% without explicit human review and cryptographic validation.
- **Reversible Decisions**: Every rejection or refinement is logged with full engineer feedback and audit trails.

---

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!
1. Fork the project.
2. Create your feature branch (`git checkout -b feature/AmazingFeature`).
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`).
4. Push to the branch (`git push origin feature/AmazingFeature`).
5. Open a Pull Request.

---

## 📄 License

Distributed under the MIT License. See `LICENSE` for more details.
