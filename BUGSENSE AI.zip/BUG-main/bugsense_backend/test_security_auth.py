"""
Step 10 Security Tests — Verify authentication enforcement
and multi-tenant data isolation across all user-facing endpoints.

Tests:
1. No Authorization → 401 on all user-facing endpoints
2. Invalid session → 401
3. Valid session → user's GitHub token propagated
4. Review verdicts are user-scoped
5. Analysis history requires auth
6. PAT fallback is blocked on user-facing routes
7. Webhook callback still works without auth (server-to-server)
8. Webhook events listing requires auth
9. Firestore endpoints require auth
10. Search endpoints require auth
"""

import sys
import os

# Ensure the backend package is importable
sys.path.insert(0, os.path.dirname(__file__))

from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient

# Ensure optional external services do not prevent importing main in test runner
for mod in ["firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore"]:
    if mod not in sys.modules:
        try:
            __import__(mod)
        except ImportError:
            sys.modules[mod] = MagicMock()

from main import app
from services import session_store

# Set mock pool so unit tests don't block on TCP network connection to localhost:5432
mock_pool = MagicMock()
mock_pool.connection.side_effect = Exception("DB offline")
session_store.set_db_pool(mock_pool)

client = TestClient(app, raise_server_exceptions=False)


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

VALID_SESSION = "test_valid_session_token_abc123"
MOCK_GITHUB_TOKEN = "ghp_mock_user_token_xyz"
MOCK_USER_ID = 99999
MOCK_LOGIN = "test-user"


def _mock_get_session(session_id):
    """Return a mock session only for the valid test session ID."""
    if session_id == VALID_SESSION:
        return {
            "session_id": VALID_SESSION,
            "github_user_id": MOCK_USER_ID,
            "github_login": MOCK_LOGIN,
            "github_access_token": MOCK_GITHUB_TOKEN,
            "github_avatar_url": "",
            "github_name": "Test User",
            "created_at": "2026-01-01T00:00:00+00:00",
            "expires_at": "2026-12-31T23:59:59+00:00",
        }
    return None


# ──────────────────────────────────────────────
# Test 1: No Authorization → 401
# ──────────────────────────────────────────────

PROTECTED_ENDPOINTS = [
    ("GET", "/github/user"),
    ("GET", "/github/repos"),
    ("GET", "/github/repos/owner/repo"),
    ("GET", "/github/repos/owner/repo/issues"),
    ("GET", "/github/repos/owner/repo/issues/1"),
    ("GET", "/github/repos/owner/repo/issues/1/comments"),
    ("GET", "/github/repos/owner/repo/issues/1/pr"),
    ("GET", "/repos/owner/repo/index"),
    ("GET", "/repos/indexed"),
    ("GET", "/analysis/history"),
    ("GET", "/webhooks/github/events"),
    ("GET", "/search/stats/owner/repo"),
]


def test_no_auth_returns_401():
    """All user-facing endpoints should return 401 without Authorization header."""
    results = []
    for method, path in PROTECTED_ENDPOINTS:
        if method == "GET":
            resp = client.get(path)
        elif method == "POST":
            resp = client.post(path, json={})
        results.append((path, resp.status_code))

    failed = [(path, code) for path, code in results if code != 401]
    assert not failed, f"Expected 401 for all endpoints, but got: {failed}"


# ──────────────────────────────────────────────
# Test 2: Invalid session → 401
# ──────────────────────────────────────────────

def test_invalid_session_returns_401():
    """Endpoints should return 401 for invalid/expired session tokens."""
    headers = {"Authorization": "Bearer invalid_session_token_xyz"}
    results = []
    with patch.object(session_store, "get_session", side_effect=_mock_get_session):
        for method, path in PROTECTED_ENDPOINTS:
            if method == "GET":
                resp = client.get(path, headers=headers)
            elif method == "POST":
                resp = client.post(path, json={}, headers=headers)
            results.append((path, resp.status_code))

    failed = [(path, code) for path, code in results if code != 401]
    assert not failed, f"Expected 401 for all endpoints, but got: {failed}"


# ──────────────────────────────────────────────
# Test 3: Valid session → user's GitHub token
# ──────────────────────────────────────────────

def test_valid_session_resolves_user_token():
    """When a valid session is provided, require_auth should resolve to the user's token."""
    from services.auth_guard import require_auth

    with patch.object(session_store, "get_session", side_effect=_mock_get_session):
        user = require_auth(f"Bearer {VALID_SESSION}")
        assert user.github_token == MOCK_GITHUB_TOKEN
        assert user.github_user_id == MOCK_USER_ID
        assert user.github_login == MOCK_LOGIN


# ──────────────────────────────────────────────
# Test 4: POST endpoints require auth
# ──────────────────────────────────────────────

POST_PROTECTED = [
    ("/repos/index", {"owner": "x", "repo": "y"}),
    ("/analysis/classify", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/root-cause", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/resolve", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/complexity", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/route/plan", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/route", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
    ("/analysis/review/verdict", {"repo_owner": "x", "repo_name": "y", "issue_number": 1, "verdict": "APPROVED"}),
    ("/search/similar", {"query": "test", "repo_owner": "x", "repo_name": "y"}),
    ("/firestore/bug-reports", {"repo_owner": "x", "repo_name": "y", "title": "t"}),
]


def test_post_endpoints_require_auth():
    """All POST user-facing endpoints should return 401 without Authorization."""
    results = []
    for path, body in POST_PROTECTED:
        resp = client.post(path, json=body)
        results.append((path, resp.status_code))

    failed = [(path, code) for path, code in results if code != 401]
    assert not failed, f"Expected 401 for all POST endpoints, but got: {failed}"


# ──────────────────────────────────────────────
# Test 5: Review verdicts are user-scoped
# ──────────────────────────────────────────────

def test_review_verdicts_user_scoped():
    """Review verdicts should only be visible to the user who submitted them."""
    from services.auth_guard import require_auth

    with patch.object(session_store, "get_session", side_effect=_mock_get_session):
        headers = {"Authorization": f"Bearer {VALID_SESSION}"}

        # Submit a verdict
        resp = client.post("/analysis/review/verdict", json={
            "repo_owner": "owner",
            "repo_name": "repo",
            "issue_number": 1,
            "verdict": "APPROVED",
        }, headers=headers)
        assert resp.status_code == 200

        # Retrieve verdicts — should see our verdict
        resp = client.get("/analysis/review/verdicts", headers=headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] >= 1
        # All returned verdicts should belong to our user
        for v in data["verdicts"]:
            assert v["github_user_id"] == MOCK_USER_ID


# ──────────────────────────────────────────────
# Test 6: PAT fallback is blocked
# ──────────────────────────────────────────────

def test_pat_fallback_blocked():
    """Sending no Authorization header should NOT fall through to developer PAT."""
    from services.auth_guard import require_auth
    from fastapi import HTTPException

    # require_auth should raise 401, never fall back to PAT
    try:
        require_auth(None)
        assert False, "Should have raised HTTPException"
    except HTTPException as e:
        assert e.status_code == 401

    try:
        require_auth("Bearer ")
        assert False, "Should have raised HTTPException for empty bearer"
    except HTTPException as e:
        assert e.status_code == 401


# ──────────────────────────────────────────────
# Test 7: Webhook callback still works
# ──────────────────────────────────────────────

def test_webhook_callback_no_auth_needed():
    """POST /webhooks/github should still work without BugSense auth (server-to-server)."""
    resp = client.post("/webhooks/github", json={}, headers={
        "X-GitHub-Event": "ping",
        "X-GitHub-Delivery": "test-delivery-id",
    })
    # Should not be 401 (may be 200 or other error depending on payload)
    assert resp.status_code != 401, "Webhook callback should not require BugSense auth"


# ──────────────────────────────────────────────
# Test 8: Webhook events listing requires auth
# ──────────────────────────────────────────────

def test_webhook_events_requires_auth():
    """GET /webhooks/github/events should require authentication."""
    resp = client.get("/webhooks/github/events")
    assert resp.status_code == 401


# ──────────────────────────────────────────────
# Test 9: Firestore endpoints require auth
# ──────────────────────────────────────────────

def test_firestore_endpoints_require_auth():
    """Firestore CRUD endpoints should require authentication."""
    endpoints = [
        ("GET", "/firestore/bug-reports"),
        ("GET", "/firestore/bug-reports/some-id"),
        ("PATCH", "/firestore/bug-reports/some-id"),
        ("DELETE", "/firestore/bug-reports/some-id"),
        ("GET", "/firestore/users/test-user"),
    ]
    for method, path in endpoints:
        if method == "GET":
            resp = client.get(path)
        elif method == "PATCH":
            resp = client.patch(path, json={"title": "updated"})
        elif method == "DELETE":
            resp = client.delete(path)
        assert resp.status_code == 401, f"{method} {path} should return 401, got {resp.status_code}"


# ──────────────────────────────────────────────
# Test 10: User-scoped collection naming
# ──────────────────────────────────────────────

def test_user_scoped_collection_name():
    """user_scoped_collection_name should produce user-unique names."""
    from services.auth_guard import user_scoped_collection_name, AuthenticatedUser

    user_a = AuthenticatedUser(github_user_id=100, github_login="alice", github_token="tok_a", session_id="s_a")
    user_b = AuthenticatedUser(github_user_id=200, github_login="bob", github_token="tok_b", session_id="s_b")

    name_a = user_scoped_collection_name(user_a, "owner", "repo")
    name_b = user_scoped_collection_name(user_b, "owner", "repo")

    assert name_a != name_b, "Different users should have different collection names"
    assert "100" in name_a
    assert "200" in name_b
    assert name_a == "u100_owner_repo"
    assert name_b == "u200_owner_repo"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
