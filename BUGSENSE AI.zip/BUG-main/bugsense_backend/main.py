import logging
import os
import socket
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from config import get_cors_allowed_origins
from routers import analysis, auth, firestore, github, indexing, search, webhooks
from services import session_store

# Force IPv4 globally for all socket connections (including httpx inside google-genai and chromadb)
# This prevents 21s-127s TCP fallback delays caused by IPv6 blackholing on hosting platforms like Render.
_old_getaddrinfo = socket.getaddrinfo
def _new_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    return _old_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
socket.getaddrinfo = _new_getaddrinfo

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: preserve existing behavior and maintain lazy database pool initialization
    yield
    # Shutdown: safely close PostgreSQL connection pool
    session_store.close_pool()


app = FastAPI(
    title="BugSense AI API",
    description="Backend API for the BugSense autonomous issue resolution platform.",
    version="1.0.3",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles
import os

if os.path.isdir("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")


app.include_router(analysis.router)
app.include_router(auth.router)
app.include_router(firestore.router)
app.include_router(github.router)
app.include_router(indexing.router)
app.include_router(search.router)
app.include_router(webhooks.router)

@app.get("/health", tags=["system"])
async def health_check():
    return {"status": "ok", "version": app.version}


# ──────────────────────────────────────────────
# Android App Links verification
# ──────────────────────────────────────────────

@app.get("/.well-known/assetlinks.json", tags=["system"])
async def assetlinks():
    """Serve Android Digital Asset Links for App Links domain verification."""
    fingerprints = os.getenv(
        "APP_SIGNING_FINGERPRINTS",
        "B6:52:F8:A3:58:07:4D:13:CE:AB:1D:87:02:92:E8:AE:3E:3F:F0:4F:1D:E0:4C:5B:39:B5:FB:8F:50:D7:2E:A3,21:EE:A9:79:50:3D:E9:28:FC:CA:01:01:2A:8B:4D:06:91:2E:4E:D6:04:83:FA:D3:D4:67:CB:D1:31:E8:88:C7",
    )
    statements = []
    for fp in fingerprints.split(","):
        fp = fp.strip()
        if fp:
            statements.append({
                "relation": ["delegate_permission/common.handle_all_urls"],
                "target": {
                    "namespace": "android_app",
                    "package_name": "com.bugsense.bugsense_ai",
                    "sha256_cert_fingerprints": [fp],
                },
            })
    return JSONResponse(content=statements)


# ──────────────────────────────────────────────
# OAuth App Link fallback (browser landing page)
# ──────────────────────────────────────────────

@app.get("/auth/callback", tags=["auth"])
async def oauth_app_callback():
    """
    Fallback page when Android App Links don't intercept the OAuth redirect.
    In normal operation, Android intercepts this URL and opens the Flutter app.
    """
    return HTMLResponse(content="""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BugSense AI — Redirecting</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               display: flex; justify-content: center; align-items: center;
               min-height: 100vh; margin: 0; background: #101828; color: #f9fafb; }
        .card { text-align: center; padding: 2rem; max-width: 400px; }
        h1 { color: #7f56d9; font-size: 1.5rem; }
        p { color: #98a2b3; line-height: 1.6; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🐛 BugSense AI</h1>
        <p>Authentication successful!</p>
        <p>If the app didn't open automatically, please open BugSense AI on your device.</p>
    </div>
</body>
</html>""")

