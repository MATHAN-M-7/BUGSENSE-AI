"""
Automated tests for RAG-enhanced classification in BugSense Backend.

Tests:
1. Health check regression (v0.9.0).
2. Index a repo (populate ChromaDB with embeddings).
3. POST /analysis/classify-rag with RAG context.
4. Response includes rag_context and rag_used fields.
5. Fallback: RAG on non-indexed repo falls back gracefully.
6. Regression: standard /analysis/classify still works.

Requires: FastAPI server running on localhost:8000 with GEMINI_API_KEY set.
"""

import sys
import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"

VALID_CATEGORIES = {"Bug", "Feature", "Enhancement", "Documentation", "Other"}
VALID_SEVERITIES = {"Critical", "High", "Medium", "Low"}


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense RAG Classification")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    results.append(test(f"GET /health returns version {version}", r.status_code == 200))

    # --- 1. Check if ChromaDB already has data, index only if needed ---
    print("\n-- Populate ChromaDB (index repo) --")
    try:
        stats_r = httpx.get(f"{BASE}/search/stats/octocat/Hello-World", timeout=60.0)
        existing_count = stats_r.json().get("count", 0) if stats_r.status_code == 200 else 0
    except Exception:
        existing_count = 0

    if existing_count > 0:
        results.append(test(
            f"ChromaDB already has {existing_count} embeddings — skipping re-index",
            True,
        ))
    else:
        r = httpx.post(f"{BASE}/repos/index", json={
            "owner": "octocat",
            "repo": "Hello-World",
            "max_issues": 3,
        }, timeout=300.0)

        if r.status_code == 503:
            detail = r.json().get("detail", "")
            results.append(test(
                "Indexing returns 503 (no API key)",
                "GEMINI_API_KEY" in detail,
                f"Detail: {detail[:80]}...",
            ))
            results.append(test("RAG tests skipped (no API key)", True, "Expected"))
            _summary(results)
            return

        results.append(test("POST /repos/index returns 200", r.status_code == 200))
        classified = r.json().get("summary", {}).get("classified", 0)
        results.append(test(f"Indexed {classified} issues with embeddings", classified > 0))

    # --- 2. RAG classification (bug-like issue) ---
    print("\n-- RAG Classification (Bug) --")
    rag_payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "title": "Application crashes with NullPointerException on login",
        "body": "When I try to login with my credentials, the app crashes immediately. "
                "Stack trace shows a NullPointerException in AuthManager.java line 42. "
                "This is blocking all users from accessing the app.",
        "state": "open",
    }
    r = httpx.post(f"{BASE}/analysis/classify-rag", json=rag_payload, timeout=60.0)

    if r.status_code == 500 and "429" in r.text:
        results.append(test(
            "RAG classification skipped (Gemini rate limit)", True,
            "Rate-limited by free tier — not a code bug. Rerun after 60s.",
        ))
    elif r.status_code == 200:
        results.append(test("POST /analysis/classify-rag returns 200", True))
        data = r.json()

        # Classification fields
        results.append(test(
            "RAG: category is valid",
            data.get("category") in VALID_CATEGORIES,
            f"category={data.get('category')}",
        ))
        results.append(test(
            "RAG: severity is valid",
            data.get("severity") in VALID_SEVERITIES,
            f"severity={data.get('severity')}",
        ))
        results.append(test(
            "RAG: category_confidence in [0, 1]",
            0 <= data.get("category_confidence", -1) <= 1,
            f"category_confidence={data.get('category_confidence')}",
        ))
        results.append(test(
            "RAG: evidence_summary is non-empty",
            bool(data.get("evidence_summary")),
            f"evidence_summary={data.get('evidence_summary', '')[:80]}...",
        ))
        results.append(test(
            "RAG: model field present",
            bool(data.get("model")),
            f"model={data.get('model')}",
        ))

        # RAG-specific fields
        results.append(test(
            "RAG: rag_used field present",
            "rag_used" in data,
            f"rag_used={data.get('rag_used')}",
        ))
        results.append(test(
            "RAG: rag_context field present",
            "rag_context" in data and isinstance(data["rag_context"], list),
            f"rag_context_count={len(data.get('rag_context', []))}",
        ))
        results.append(test(
            "RAG: analyzed_by is classifier_agent_v1_rag",
            data.get("analyzed_by") == "classifier_agent_v1_rag",
            f"analyzed_by={data.get('analyzed_by')}",
        ))

        # Validate rag_context structure
        rag_ctx = data.get("rag_context", [])
        if rag_ctx:
            first = rag_ctx[0]
            results.append(test(
                "RAG context has issue_id",
                "issue_id" in first,
                f"issue_id={first.get('issue_id')}",
            ))
            results.append(test(
                "RAG context has similarity score",
                "similarity" in first and isinstance(first["similarity"], (int, float)),
                f"similarity={first.get('similarity')}",
            ))
            results.append(test(
                "RAG context has category",
                "category" in first,
                f"category={first.get('category')}",
            ))
        else:
            results.append(test("RAG context populated", False, "Empty rag_context"))
    else:
        results.append(test(
            "POST /analysis/classify-rag returns 200", False,
            f"status={r.status_code} body={r.text[:200]}",
        ))

    # --- 3. Fallback: RAG on non-indexed repo ---
    print("\n-- RAG Fallback (no ChromaDB data) --")
    fallback_payload = {
        "repo_owner": "nonexistent",
        "repo_name": "repo",
        "title": "Something is broken",
        "body": "The feature does not work.",
    }
    r = httpx.post(f"{BASE}/analysis/classify-rag", json=fallback_payload, timeout=60.0)
    if r.status_code == 500 and "429" in r.text:
        results.append(test(
            "RAG fallback skipped (Gemini rate limit)", True,
            "Rate-limited by free tier — not a code bug",
        ))
    else:
        results.append(test("RAG fallback returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test(
                "Fallback: rag_used is False (no context available)",
                data.get("rag_used") is False,
                f"rag_used={data.get('rag_used')}",
            ))
            results.append(test(
                "Fallback: rag_context is empty",
                data.get("rag_context") == [],
                f"rag_context={data.get('rag_context')}",
            ))
            results.append(test(
                "Fallback: classification still valid",
                data.get("category") in VALID_CATEGORIES,
                f"category={data.get('category')}",
            ))

    # --- 4. Standard classify still works ---
    print("\n-- Regression: Standard classify --")
    std_payload = {
        "repo_owner": "test",
        "repo_name": "test",
        "title": "Add dark mode support",
        "body": "Please add a dark mode option to the settings.",
    }
    r = httpx.post(f"{BASE}/analysis/classify", json=std_payload, timeout=60.0)
    if r.status_code == 500 and "429" in r.text:
        results.append(test(
            "Standard classify skipped (Gemini rate limit)", True,
            "Rate-limited by free tier — not a code bug",
        ))
    else:
        results.append(test("Standard /analysis/classify returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test(
                "Standard: no rag_used field (not RAG)",
                "rag_used" not in data,
            ))
            results.append(test(
                "Standard: analyzed_by is classifier_agent_v1",
                data.get("analyzed_by") == "classifier_agent_v1",
                f"analyzed_by={data.get('analyzed_by')}",
            ))

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("RAG TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All RAG tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
