"""
Automated tests for Firebase Firestore integration in BugSense Backend.

Tests:
1. Health check still works (regression).
2. Firestore CRUD for bug reports (create, get, list, update, delete).
3. Firestore user profile (upsert, get).
4. Graceful error handling when Firebase credentials are missing.

Requires: FastAPI server running on localhost:8000.
"""

import sys
import httpx
import time

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Firebase Firestore")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check regression ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    health_ok = r.status_code == 200 and bool(version)
    results.append(test(f"GET /health returns version {version}", health_ok))

    # --- 1. Create bug report ---
    print("\n-- Bug Reports CRUD --")
    payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 42,
        "title": "Test bug from Firestore test suite",
        "body": "This is a test bug report created by test_firestore.py",
        "state": "open",
        "labels": ["bug", "test"],
        "created_by": "surya6246",
        "status": "new",
    }
    r = httpx.post(f"{BASE}/firestore/bug-reports", json=payload)

    if r.status_code == 503:
        # Firebase credentials are not configured — test graceful degradation
        detail = r.json().get("detail", "")
        firebase_missing = "Firebase" in detail or "service account" in detail.lower()
        results.append(
            test(
                "POST /firestore/bug-reports returns 503 when Firebase is unconfigured",
                firebase_missing,
                f"Detail: {detail[:80]}...",
            )
        )
        # Skip remaining Firestore CRUD tests
        results.append(test("Firestore CRUD tests skipped (no credentials)", True, "Expected"))
        _summary(results)
        return

    create_ok = r.status_code == 201 and "id" in r.json()
    doc_id = r.json().get("id", "")
    results.append(test("POST /firestore/bug-reports creates document", create_ok, f"doc_id={doc_id}"))

    if not create_ok:
        print(f"    Response: {r.status_code} {r.text[:200]}")
        _summary(results)
        return

    # --- 2. Get bug report ---
    r = httpx.get(f"{BASE}/firestore/bug-reports/{doc_id}")
    get_ok = r.status_code == 200
    if get_ok:
        data = r.json()
        fields_ok = (
            data.get("title") == payload["title"]
            and data.get("repo_owner") == "octocat"
            and data.get("status") == "new"
            and data.get("id") == doc_id
        )
        results.append(test("GET /firestore/bug-reports/{id} returns correct fields", fields_ok))
    else:
        results.append(test("GET /firestore/bug-reports/{id} returns 200", False, f"Got {r.status_code}"))

    # --- 3. List bug reports ---
    r = httpx.get(f"{BASE}/firestore/bug-reports", params={"repo_owner": "octocat"})
    list_ok = r.status_code == 200 and isinstance(r.json(), list) and len(r.json()) >= 1
    results.append(test("GET /firestore/bug-reports?repo_owner=octocat lists documents", list_ok))

    # --- 4. Update bug report ---
    r = httpx.patch(
        f"{BASE}/firestore/bug-reports/{doc_id}",
        json={"status": "analyzing", "title": "Updated test bug"},
    )
    update_ok = r.status_code == 200 and r.json().get("status") == "updated"
    results.append(test("PATCH /firestore/bug-reports/{id} updates fields", update_ok))

    # Verify the update
    r = httpx.get(f"{BASE}/firestore/bug-reports/{doc_id}")
    verify_ok = (
        r.status_code == 200
        and r.json().get("status") == "analyzing"
        and r.json().get("title") == "Updated test bug"
    )
    results.append(test("GET after PATCH reflects updated values", verify_ok))

    # --- 5. Delete bug report ---
    r = httpx.delete(f"{BASE}/firestore/bug-reports/{doc_id}")
    delete_ok = r.status_code == 200 and r.json().get("status") == "deleted"
    results.append(test("DELETE /firestore/bug-reports/{id} removes document", delete_ok))

    # Verify deletion
    r = httpx.get(f"{BASE}/firestore/bug-reports/{doc_id}")
    gone_ok = r.status_code == 404
    results.append(test("GET after DELETE returns 404", gone_ok))

    # --- 6. User profile ---
    print("\n-- User Profiles --")
    user_payload = {
        "login": "test_firestore_user",
        "name": "Firestore Test User",
        "avatar_url": "https://example.com/avatar.png",
        "bio": "Test user for Firestore integration",
        "public_repos": 5,
        "followers": 10,
        "html_url": "https://github.com/test_firestore_user",
    }
    r = httpx.post(f"{BASE}/firestore/users", json=user_payload)
    upsert_ok = r.status_code == 201 and r.json().get("id") == "test_firestore_user"
    results.append(test("POST /firestore/users upserts user profile", upsert_ok))

    r = httpx.get(f"{BASE}/firestore/users/test_firestore_user")
    user_get_ok = r.status_code == 200 and r.json().get("login") == "test_firestore_user"
    results.append(test("GET /firestore/users/{login} returns user profile", user_get_ok))

    # Cleanup test user
    try:
        from services import firestore_service as fs
        fs.get_db().collection("users").document("test_firestore_user").delete()
    except Exception:
        pass  # cleanup is best-effort

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("FIRESTORE TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    for i, ok in enumerate(results):
        # Not printing labels here since they were already printed inline
        pass
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All Firestore tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
