"""
Application configuration — reads secrets from environment / .env file.
"""

import os
from dotenv import load_dotenv

load_dotenv()  # loads .env in the project root


def get_github_token() -> str:
    """Return the GitHub PAT, or raise if not configured."""
    token = os.getenv("GITHUB_TOKEN", "")
    if not token or token.startswith("ghp_YOUR"):
        raise RuntimeError(
            "GITHUB_TOKEN is not set. "
            "Copy .env.example → .env and paste a valid GitHub PAT."
        )
    return token


def get_github_client_id() -> str:
    """Return the GitHub OAuth App client ID, or raise if not configured."""
    client_id = os.getenv("GITHUB_CLIENT_ID", "")
    if not client_id or client_id.startswith("your_oauth"):
        raise RuntimeError(
            "GITHUB_CLIENT_ID is not set in .env. "
            "Register an OAuth App in GitHub Developer Settings and configure GITHUB_CLIENT_ID."
        )
    return client_id


def get_github_client_secret() -> str:
    """Return the GitHub OAuth App client secret, or raise if not configured."""
    secret = os.getenv("GITHUB_CLIENT_SECRET", "")
    if not secret or secret.startswith("your_oauth"):
        raise RuntimeError(
            "GITHUB_CLIENT_SECRET is not set in .env. "
            "Configure GITHUB_CLIENT_SECRET from your GitHub OAuth App."
        )
    return secret


def get_github_redirect_uri() -> str:
    """Return the configured GitHub OAuth callback URL."""
    uri = os.getenv("GITHUB_REDIRECT_URI", "").strip()
    if uri:
        return uri
    # Automatic fallback for Render deployments where RENDER_EXTERNAL_URL is available
    render_url = os.getenv("RENDER_EXTERNAL_URL", "").strip().rstrip("/")
    if render_url:
        return f"{render_url}/auth/github/callback"
    return "http://localhost:8000/auth/github/callback"


def get_mobile_oauth_redirect_uri() -> str:
    """
    Return the deep link URL for redirecting to the mobile app after OAuth.
    Defaults to custom scheme bugsense://callback to guarantee the app opens.
    """
    return os.getenv("MOBILE_OAUTH_REDIRECT_URI", "bugsense://callback")


# ──────────────────────────────────────────────
# Redis (distributed ephemeral state)
# ──────────────────────────────────────────────

def get_redis_url() -> str:
    """Return the Redis connection URL."""
    return os.getenv("REDIS_URL", "redis://localhost:6379/0")


# ──────────────────────────────────────────────
# PostgreSQL & Token Encryption (durable sessions)
# ──────────────────────────────────────────────

def get_database_url() -> str:
    """Return the PostgreSQL connection URL."""
    return os.getenv(
        "DATABASE_URL",
        "postgresql://postgres:postgres@localhost:5432/bugsense",
    )


def get_session_encryption_key() -> str:
    """Return the Fernet key used for application-level token encryption."""
    key = os.getenv("SESSION_ENCRYPTION_KEY", "")
    if not key:
        raise RuntimeError(
            "SESSION_ENCRYPTION_KEY is not set. "
            "Generate one with: python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())' "
            "and add SESSION_ENCRYPTION_KEY=<key> to .env"
        )
    return key


# ──────────────────────────────────────────────
# Firebase
# ──────────────────────────────────────────────

def get_firebase_credentials_path() -> str:
    """Return the path to the Firebase service account JSON file."""
    default = os.path.join(os.path.dirname(__file__), "firebase-service-account.json")
    return os.getenv("FIREBASE_CREDENTIALS_PATH", default)


def get_firebase_project_id() -> str | None:
    """Return an optional Firebase project ID override (auto-detected from creds if unset)."""
    return os.getenv("FIREBASE_PROJECT_ID") or None


# ──────────────────────────────────────────────
# GitHub Webhooks
# ──────────────────────────────────────────────

def get_github_webhook_secret() -> str | None:
    """Return the GitHub webhook secret for HMAC verification, or None if unset."""
    secret = os.getenv("GITHUB_WEBHOOK_SECRET", "")
    return secret if secret else None


# ──────────────────────────────────────────────
# Gemini AI
# ──────────────────────────────────────────────

def get_gemini_api_key() -> str:
    """Return the Gemini API key, or raise if not configured."""
    key = os.getenv("GEMINI_API_KEY", "")
    if not key:
        raise RuntimeError(
            "GEMINI_API_KEY is not set. "
            "Get a free API key at https://aistudio.google.com/app/apikey "
            "and add GEMINI_API_KEY=your_key to .env"
        )
    return key


def get_gemini_model() -> str:
    """Return the Gemini model name (default: gemini-3.6-flash)."""
    return os.getenv("GEMINI_MODEL", "gemini-3.6-flash")


# ──────────────────────────────────────────────
# Environment & Production Hardening
# ──────────────────────────────────────────────

def get_environment() -> str:
    """Return current execution environment ('development', 'test', 'production')."""
    return os.getenv("ENVIRONMENT", os.getenv("APP_ENV", "development")).lower().strip()


def is_production() -> bool:
    """Return True if executing under a production environment."""
    return get_environment() in ("production", "prod")


def get_cors_allowed_origins() -> list[str]:
    """
    Return allowed CORS origins list.
    Supports comma-separated CORS_ALLOWED_ORIGINS environment variable.
    In production, strictly requires explicit HTTPS origins and rejects wildcard '*'.
    In development, allows local development origins.
    """
    # Canonical variable: CORS_ALLOWED_ORIGINS (supports CORS_ORIGINS as alias)
    origins_env = os.getenv("CORS_ALLOWED_ORIGINS", "").strip() or os.getenv("CORS_ORIGINS", "").strip()
    if origins_env:
        parsed = [o.strip() for o in origins_env.split(",") if o.strip()]
        if is_production():
            # Strictly filter out wildcard and non-HTTPS origins in production
            https_origins = [o for o in parsed if o != "*" and o.startswith("https://")]
            return https_origins if https_origins else [
                "https://bugsense.ai",
                "https://app.bugsense.ai",
            ]
        return parsed

    if is_production():
        return [
            "https://bugsense.ai",
            "https://app.bugsense.ai",
        ]
    return [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
        "http://127.0.0.1:5173",
    ]


def get_vector_store_backend() -> str:
    """
    Return the configured vector store backend.
    - 'chroma_local': local Chroma PersistentClient (default in development)
    - 'chroma_remote': remote Chroma HttpClient (default in production)
    """
    # Canonical variable: VECTOR_STORE_BACKEND (supports CHROMA_BACKEND as alias)
    backend = os.getenv("VECTOR_STORE_BACKEND", "").strip().lower() or os.getenv("CHROMA_BACKEND", "").strip().lower()
    if backend:
        return backend
    if is_production():
        return "chroma_remote"
    return "chroma_local"


def get_chroma_persist_dir() -> str:
    """Return persistent directory for local ChromaDB vector embeddings."""
    return os.getenv("CHROMA_PERSIST_DIR", "./chroma_data")


def get_chroma_host() -> str:
    """Return hostname or IP for remote Chroma server."""
    return os.getenv("CHROMA_HOST", "localhost").strip()


def get_chroma_port() -> int:
    """Return port for remote Chroma server."""
    port_str = os.getenv("CHROMA_PORT", "").strip()
    if port_str.isdigit():
        return int(port_str)
    return 443 if get_chroma_ssl() else 8000


def get_chroma_ssl() -> bool:
    """Return True if remote Chroma server requires TLS/HTTPS."""
    ssl_str = os.getenv("CHROMA_SSL", "").strip().lower()
    return ssl_str in ("true", "1", "yes")


def get_chroma_api_key() -> str | None:
    """Return API token for remote Chroma server authentication, or None if unset."""
    # Canonical variable: CHROMA_API_KEY (supports CHROMA_AUTH_TOKEN as alias)
    key = os.getenv("CHROMA_API_KEY", "").strip() or os.getenv("CHROMA_AUTH_TOKEN", "").strip()
    return key if key else None


def get_chroma_tenant() -> str:
    """Return Chroma tenant (default: 'default_tenant')."""
    return os.getenv("CHROMA_TENANT", "default_tenant").strip() or "default_tenant"


def get_chroma_database() -> str:
    """Return Chroma database (default: 'default_database')."""
    return os.getenv("CHROMA_DATABASE", "default_database").strip() or "default_database"



