"""
Automated tests for Adaptive Agent Router in BugSense Backend.

Tests:
1. Route planning for Low complexity issues -> FAST_TRACK.
2. Route planning for High complexity issues with stack trace -> DEEP_INVESTIGATION.
3. Route planning for Ambiguous / Vague issues -> NEEDS_CLARIFICATION.
4. Route planning for Moderate issues -> STANDARD.
5. POST /analysis/route/plan endpoint returns 200 with valid RoutePlan schema.
"""

import sys
import httpx
from services.adaptive_router import plan_route, RouteType

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Adaptive Agent Router")
    print(f"{'='*60}")

    results = []

    # ─── 1. Unit: FAST_TRACK route ───
    print("\n-- 1. Unit: Low Complexity Route Planning --")
    low_issue = {
        "title": "Fix typo",
        "body": "Small typo in docs",
        "labels": ["documentation"],
    }
    plan_low = plan_route(low_issue)
    results.append(test(
        "Low complexity issue routes to FAST_TRACK or STANDARD",
        plan_low["route_type"] in (RouteType.FAST_TRACK.value, RouteType.STANDARD.value),
        f"route_type={plan_low['route_type']}",
    ))
    results.append(test(
        "Plan contains recommended_agents list",
        isinstance(plan_low.get("recommended_agents"), list) and len(plan_low["recommended_agents"]) > 0,
        f"agents={plan_low.get('recommended_agents')}",
    ))
    results.append(test(
        "Plan contains routing_reason",
        isinstance(plan_low.get("routing_reason"), str) and len(plan_low["routing_reason"]) > 0,
    ))

    # ─── 2. Unit: DEEP_INVESTIGATION route ───
    print("\n-- 2. Unit: High Complexity Route Planning --")
    deep_issue = {
        "title": "Crash in AuthManager and MemoryLeak in DatabasePool",
        "body": (
            "Traceback (most recent call last):\n"
            "  File \"auth/manager.py\", line 142, in login\n"
            "    user = db.query(User).filter_by(email=email).one()\n"
            "NullPointerException: user is null\n"
            "Also affects services/auth_service.py, db/pool.py, and models/user.py.\n"
            "Memory usage increases monotonically until OutOfMemoryError kills process."
        ),
        "labels": ["bug", "crash", "performance"],
    }
    plan_deep = plan_route(deep_issue)
    results.append(test(
        "High complexity issue with stack trace routes to DEEP_INVESTIGATION",
        plan_deep["route_type"] == RouteType.DEEP_INVESTIGATION.value,
        f"route_type={plan_deep['route_type']}",
    ))
    results.append(test(
        "DEEP_INVESTIGATION recommends all 3 pipeline agents",
        len(plan_deep.get("recommended_agents", [])) == 3,
        f"agents={plan_deep.get('recommended_agents')}",
    ))

    # ─── 3. Unit: NEEDS_CLARIFICATION route ───
    print("\n-- 3. Unit: Ambiguous/Vague Route Planning --")
    vague_issue = {
        "title": "error",
        "body": "not working",
        "labels": [],
    }
    plan_vague = plan_route(vague_issue)
    results.append(test(
        "Vague issue routes to NEEDS_CLARIFICATION or FAST_TRACK",
        plan_vague["route_type"] in (RouteType.NEEDS_CLARIFICATION.value, RouteType.FAST_TRACK.value),
        f"route_type={plan_vague['route_type']}",
    ))

    # ─── 4. API Endpoint: POST /analysis/route/plan ───
    print("\n-- 4. API Endpoint: POST /analysis/route/plan --")
    try:
        payload = {
            "repo_owner": "octocat",
            "repo_name": "Hello-World",
            "title": "Severe memory leak and OOM crash",
            "body": "Crash with OutOfMemoryError in ImageLoader.java:88",
        }
        r = httpx.post(f"{BASE}/analysis/route/plan", json=payload, timeout=10.0)
        results.append(test("POST /analysis/route/plan returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test("API returns route_type", "route_type" in data))
            results.append(test("API returns recommended_agents", isinstance(data.get("recommended_agents"), list)))
            results.append(test("API returns routing_reason", isinstance(data.get("routing_reason"), str)))
            results.append(test("API returns rag_strategy", isinstance(data.get("rag_strategy"), dict)))
    except Exception as e:
        results.append(test("API endpoint check failed", False, str(e)))

    # ─── Summary ───
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'='*60}")
    print(f"ADAPTIVE ROUTER TEST SUMMARY: {passed}/{total} passed")
    print(f"{'='*60}")
    if passed < total:
        sys.exit(1)


if __name__ == "__main__":
    main()
