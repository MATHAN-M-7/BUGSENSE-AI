with open('../bugsense_ai/lib/services/api_service.dart', 'r') as f:
    text = f.read()

text = text.replace(
    "throw Exception('AI service unavailable — GEMINI_API_KEY may not be set.');",
    "final detail = _extractDetail(response); throw Exception('AI service unavailable: $detail');"
)

with open('../bugsense_ai/lib/services/api_service.dart', 'w') as f:
    f.write(text)
