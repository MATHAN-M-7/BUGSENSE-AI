"""
Automated tests for Evidence Validator in BugSense Backend.

Tests:
1. Unit: Validate claims matching issue text -> STRONG / MODERATE verdict.
2. Unit: Validate unsubstantiated claims -> WEAK / INSUFFICIENT verdict.
3. Unit: ClaimCheck score calculation.
4. API: POST /analysis/validate-evidence endpoint verification.
"""

import sys
import httpx
from services.evidence_validator import (
    EvidenceValidator,
    get_evidence_validator,
    EvidenceVerdict,
    ClaimVerdict,
)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Evidence Validator")
    print(f"{'='*60}")

    results = []

    validator = get_evidence_validator()

    # ─── 1. Unit: Strongly Supported Claims ───
    print("\n-- 1. Unit: Strongly Supported Claims --")
    issue_data = {
        "title": "NullPointerException in AuthManager line 42",
        "body": "User database returned null during login causing NullPointerException in AuthManager.java:42",
        "labels": ["bug", "crash"],
    }
    classification = {
        "category": "Bug",
        "severity": "Critical",
        "evidence_summary": "NullPointerException in AuthManager.java:42 crashes application",
    }
    root_cause = {
        "probable_cause": "Null user object from database causing NullPointerException in AuthManager",
        "affected_components": ["AuthManager.java"],
        "investigation_areas": ["AuthManager.java line 42"],
    }
    resolution = {
        "fix_description": "Add null check in AuthManager for user object",
        "code_suggestions": [
            {"file_or_component": "AuthManager.java", "change_description": "Add null check", "code_snippet": "if (user == null) return;"}
        ],
    }

    res_strong = validator.validate(
        issue_data=issue_data,
        classification=classification,
        root_cause=root_cause,
        resolution=resolution,
    )
    results.append(test(
        "Strong claims yield evidence_score >= 0.45",
        res_strong.evidence_score >= 0.45,
        f"score={res_strong.evidence_score}",
    ))
    results.append(test(
        "Strong claims yield STRONG or MODERATE verdict",
        res_strong.verdict in (EvidenceVerdict.STRONG.value, EvidenceVerdict.MODERATE.value),
        f"verdict={res_strong.verdict}",
    ))
    results.append(test(
        "Claim checks populated for each stage",
        len(res_strong.claim_checks) >= 3,
        f"count={len(res_strong.claim_checks)}",
    ))

    # ─── 2. Unit: Unsupported / Hallucinated Claims ───
    print("\n-- 2. Unit: Unsupported Claims --")
    hallucinated_rca = {
        "probable_cause": "Quantum entanglement collapse in CSS grid rendering engine",
        "affected_components": ["QuantumEngine.swift"],
        "investigation_areas": ["SubatomicRegistry"],
    }
    res_weak = validator.validate(
        issue_data=issue_data,
        root_cause=hallucinated_rca,
    )
    results.append(test(
        "Hallucinated claims yield low evidence_score",
        res_weak.evidence_score < 0.45,
        f"score={res_weak.evidence_score}",
    ))
    results.append(test(
        "Hallucinated claims yield WEAK or INSUFFICIENT verdict",
        res_weak.verdict in (EvidenceVerdict.WEAK.value, EvidenceVerdict.INSUFFICIENT.value),
        f"verdict={res_weak.verdict}",
    ))

    # ─── 3. API Endpoint: POST /analysis/validate-evidence ───
    print("\n-- 3. API Endpoint: POST /analysis/validate-evidence --")
    try:
        payload = {
            "title": issue_data["title"],
            "body": issue_data["body"],
            "labels": issue_data["labels"],
            "classification": classification,
            "root_cause": root_cause,
            "resolution": resolution,
        }
        r = httpx.post(f"{BASE}/analysis/validate-evidence", json=payload, timeout=10.0)
        results.append(test("POST /analysis/validate-evidence returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test("API response contains evidence_score", "evidence_score" in data))
            results.append(test("API response contains verdict", "verdict" in data))
            results.append(test("API response contains claim_checks list", isinstance(data.get("claim_checks"), list)))
    except Exception as e:
        results.append(test("API endpoint check failed", False, str(e)))

    # ─── Summary ───
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'='*60}")
    print(f"EVIDENCE VALIDATOR TEST SUMMARY: {passed}/{total} passed")
    print(f"{'='*60}")
    if passed < total:
        sys.exit(1)


if __name__ == "__main__":
    main()
