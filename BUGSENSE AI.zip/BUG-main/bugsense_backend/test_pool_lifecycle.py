"""
Focused test suite for PostgreSQL connection pool lifecycle in BugSense AI.

Covers:
1. pool exists -> close_pool() closes it and clears the module-level reference.
2. pool does not exist -> close_pool() is safe and does nothing.
3. calling close_pool() twice is safe and does not crash (idempotent).
4. FastAPI lifespan context manager executes close_pool() on application shutdown.
"""

import asyncio
import sys
from unittest.mock import MagicMock, patch

# Ensure optional external services do not prevent importing main in test runner
for mod in ["firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore"]:
    if mod not in sys.modules:
        try:
            __import__(mod)
        except ImportError:
            sys.modules[mod] = MagicMock()

from services import session_store
import main


def test_close_pool_when_pool_exists():
    """Verify that close_pool() closes the pool and resets _pool to None when pool exists."""
    mock_pool = MagicMock()
    session_store.set_db_pool(mock_pool)
    assert session_store._pool is mock_pool

    session_store.close_pool()

    mock_pool.close.assert_called_once()
    assert session_store._pool is None
    print("  [PASS] pool exists -> close_pool() safely closed it and reset reference")


def test_close_pool_when_pool_does_not_exist():
    """Verify that close_pool() is completely safe when pool was never initialized."""
    session_store.set_db_pool(None)
    assert session_store._pool is None

    # Should execute cleanly without error
    session_store.close_pool()
    assert session_store._pool is None
    print("  [PASS] pool does not exist -> close_pool() is safe and returns without error")


def test_close_pool_idempotent():
    """Verify that calling close_pool() twice does not crash and pool.close() is called only once."""
    mock_pool = MagicMock()
    session_store.set_db_pool(mock_pool)

    # First call
    session_store.close_pool()
    assert session_store._pool is None
    mock_pool.close.assert_called_once()

    # Second call (must be safe)
    session_store.close_pool()
    assert session_store._pool is None
    # close should still have been called exactly once
    assert mock_pool.close.call_count == 1
    print("  [PASS] calling close_pool() twice does not crash (idempotent)")


def test_fastapi_lifespan_shutdown():
    """Verify that FastAPI lifespan triggers session_store.close_pool() on shutdown."""
    async def _run_lifespan_test():
        with patch.object(session_store, "close_pool") as mock_close:
            async with main.lifespan(main.app):
                # Startup phase: close_pool should not have been called yet
                mock_close.assert_not_called()
            # Shutdown phase: close_pool must be called upon exiting the lifespan context
            mock_close.assert_called_once()

    asyncio.run(_run_lifespan_test())
    print("  [PASS] FastAPI lifespan triggers session_store.close_pool() on shutdown")


def run_all_tests():
    print("==================================================")
    print("STEP 23 — POSTGRES CONNECTION POOL LIFECYCLE TESTS")
    print("==================================================")

    test_close_pool_when_pool_exists()
    test_close_pool_when_pool_does_not_exist()
    test_close_pool_idempotent()
    test_fastapi_lifespan_shutdown()

    # Final cleanup
    session_store.set_db_pool(None)

    print("\n==================================================")
    print("ALL POOL LIFECYCLE TESTS PASSED SUCCESSFULLY!")
    print("==================================================")


if __name__ == "__main__":
    run_all_tests()
