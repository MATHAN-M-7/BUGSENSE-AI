"""
Search router — semantic search over indexed GitHub issues.

All endpoints require a valid BugSense session. Searches are
scoped to the authenticated user's indexed data.
"""

from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from services.auth_guard import require_auth, verify_repo_access

router = APIRouter(prefix="/search", tags=["search"])


# ──────────────────────────────────────────────
# Request models
# ──────────────────────────────────────────────

class SimilarSearchRequest(BaseModel):
    """Request body for semantic similarity search."""
    query: str
    repo_owner: str
    repo_name: str
    n_results: int = 5


# ──────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────

@router.post("/similar")
async def search_similar(body: SimilarSearchRequest, authorization: str | None = Header(None)):
    """
    Find GitHub issues semantically similar to a natural language query.

    Requires authentication. Verifies the user has access to the
    target repository before querying. Searches only the user's
    own indexed data.
    """
    user = require_auth(authorization)
    # Verify the user has access to the repository BEFORE querying ChromaDB
    await verify_repo_access(body.repo_owner, body.repo_name, user)
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        results = store.search_similar(
            repo_owner=body.repo_owner,
            repo_name=body.repo_name,
            query=body.query,
            n_results=body.n_results,
            github_user_id=user.github_user_id,
        )
        return {
            "query": body.query,
            "repo": f"{body.repo_owner}/{body.repo_name}",
            "count": len(results),
            "results": results,
        }
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if "remote Chroma server" in str(e) or "VectorStore" in str(e):
            raise HTTPException(status_code=503, detail="Vector search service is currently unavailable.")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if "Chroma" in str(e) or "connect" in str(e).lower():
            raise HTTPException(status_code=503, detail="Vector search service is currently unavailable.")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@router.get("/stats/{owner}/{repo}")
async def get_search_stats(owner: str, repo: str, authorization: str | None = Header(None)):
    """Get vector store statistics for a repository (user-scoped)."""
    user = require_auth(authorization)
    await verify_repo_access(owner, repo, user)
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        stats = store.get_collection_stats(owner, repo, github_user_id=user.github_user_id)
        return stats
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if "remote Chroma server" in str(e) or "VectorStore" in str(e):
            raise HTTPException(status_code=503, detail="Vector search service is currently unavailable.")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if "Chroma" in str(e) or "connect" in str(e).lower():
            raise HTTPException(status_code=503, detail="Vector search service is currently unavailable.")
        raise HTTPException(status_code=500, detail=f"Stats failed: {str(e)}")


@router.get("/health")
async def get_vector_health():
    """Lightweight vector storage availability check."""
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        return store.health_check()
    except Exception:
        raise HTTPException(status_code=503, detail="Vector search service is currently unavailable.")

