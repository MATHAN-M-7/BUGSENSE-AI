"""
Indexing router — repository issue indexing and analytics endpoints.

All endpoints require a valid BugSense session. Repository index data
is scoped to the authenticated user's GitHub identity.
"""

from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from services import repo_indexer
from services.auth_guard import require_auth, verify_repo_access

router = APIRouter(prefix="/repos", tags=["indexing"])


# ──────────────────────────────────────────────
# Request models
# ──────────────────────────────────────────────

class IndexRequest(BaseModel):
    """Request body for triggering repository indexing."""
    owner: str
    repo: str
    max_issues: int = 10


# ──────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────

@router.post("/index", status_code=200)
async def trigger_indexing(body: IndexRequest, authorization: str | None = Header(None)):
    """
    Trigger indexing of a GitHub repository.

    Fetches issues and classifies each one using the AI Classifier Agent.
    Returns a summary with category/severity breakdowns.
    Requires authentication; uses the user's GitHub token.
    """
    user = require_auth(authorization)
    # Verify the user has access to the repository
    await verify_repo_access(body.owner, body.repo, user)
    try:
        result = await repo_indexer.index_repository(
            owner=body.owner,
            repo=body.repo,
            max_issues=body.max_issues,
            token=user.github_token,
            github_user_id=user.github_user_id,
        )
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Indexing failed: {str(e)}")


@router.get("/{owner}/{repo}/index")
async def get_repo_index(owner: str, repo: str, authorization: str | None = Header(None)):
    """Get the stored index summary for a repository (user-scoped)."""
    user = require_auth(authorization)
    await verify_repo_access(owner, repo, user)
    result = repo_indexer.get_repo_index(owner, repo, github_user_id=user.github_user_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"No index found for {owner}/{repo}. "
                   "POST /repos/index to trigger indexing, or Firestore may not be configured.",
        )
    return result


@router.get("/{owner}/{repo}/index/issues")
async def get_repo_issues(
    owner: str,
    repo: str,
    limit: int = Query(50, ge=1, le=200),
    authorization: str | None = Header(None),
):
    """List classified issues for a specific repository (user-scoped)."""
    user = require_auth(authorization)
    await verify_repo_access(owner, repo, user)
    results = repo_indexer.get_repo_analyses(owner, repo, limit=limit, github_user_id=user.github_user_id)
    return {"count": len(results), "issues": results}


@router.get("/indexed")
async def list_indexed_repos(
    limit: int = Query(20, ge=1, le=100),
    authorization: str | None = Header(None),
):
    """List all repositories that have been indexed by the authenticated user."""
    user = require_auth(authorization)
    results = repo_indexer.list_indexed_repos(limit=limit, github_user_id=user.github_user_id)
    return {"count": len(results), "repositories": results}
