"""
Authentication router — GitHub OAuth 2.0 endpoints + session management.

Security: GitHub access tokens are NEVER returned to clients.
Clients receive only opaque BugSense session tokens.
"""

import logging
import urllib.parse

from fastapi import APIRouter, Header, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel

import httpx

from services import auth_service
from services import session_store

router = APIRouter(prefix="/auth", tags=["auth"])
logger = logging.getLogger("bugsense.auth")


class ExchangeRequest(BaseModel):
    code: str
    state: str | None = None


class SignupRequest(BaseModel):
    full_name: str
    username: str
    email: str
    password: str

class LoginRequest(BaseModel):
    username_or_email: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

# ──────────────────────────────────────────────
# BugSense Local Auth Endpoints
# ──────────────────────────────────────────────

@router.post("/signup")
async def signup(body: SignupRequest):
    try:
        hashed_password = auth_service.get_password_hash(body.password)
        user_id = session_store.create_bugsense_user(
            full_name=body.full_name,
            username=body.username,
            email=body.email,
            password_hash=hashed_password,
        )
        # Automatically log them in upon successful signup
        session_token = session_store.create_bugsense_session(user_id)
        return {
            "status": "success",
            "session_token": session_token,
            "user": {
                "id": user_id,
                "full_name": body.full_name,
                "username": body.username,
                "email": body.email
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Signup error: %s", str(e))
        raise HTTPException(status_code=500, detail="Internal server error")

@router.post("/login")
async def login(body: LoginRequest):
    user = session_store.get_bugsense_user_by_email_or_username(body.username_or_email)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
        
    if not auth_service.verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid username or password")
        
    session_token = session_store.create_bugsense_session(user["id"])
    return {
        "status": "success",
        "session_token": session_token,
        "user": {
            "id": user["id"],
            "full_name": user["full_name"],
            "username": user["username"],
            "email": user["email"],
            "github_user_id": user.get("github_user_id")
        }
    }

@router.post("/forgot-password")
async def forgot_password(body: ForgotPasswordRequest):
    user = session_store.get_bugsense_user_by_email_or_username(body.email)
    if user:
        # In a real system, send email here. We return success even if user not found to prevent enumeration.
        logger.info(f"Forgot password requested for {body.email}")
    return {"status": "success", "message": "If that email is registered, you will receive a reset link."}

@router.post("/reset-password")
async def reset_password(body: ResetPasswordRequest):
    # Mock implementation
    return {"status": "success", "message": "Password updated successfully"}


# ──────────────────────────────────────────────
# CSRF state store (Redis-backed, distributed)
# ──────────────────────────────────────────────
import redis
from services.redis_client import get_redis_client

_STATE_TTL = 600  # 10 minutes


def _store_state(state: str) -> None:
    """Store a CSRF state token in Redis with a 600-second TTL."""
    if not state:
        raise ValueError("State parameter cannot be empty.")
    try:
        client = get_redis_client()
        client.set(f"oauth_state:{state}", "1", ex=_STATE_TTL)
        logger.info("OAuth state stored in Redis: success=True, key_stored=True, ttl=%ds", _STATE_TTL)
    except redis.RedisError as e:
        logger.error("OAuth state storage in Redis failed: success=False, error=%s", type(e).__name__)
        raise HTTPException(
            status_code=503,
            detail="Authentication service temporarily unavailable (state store error)."
        ) from e


def _validate_state(state: str | None) -> bool:
    """Validate and atomically consume a CSRF state token from Redis via GETDEL."""
    if not state:
        logger.warning("OAuth state validation skipped: state_present=False")
        return False
    try:
        client = get_redis_client()
        val = client.getdel(f"oauth_state:{state}")
        found = val is not None
        logger.info("OAuth state GETDEL check: success=True, key_found=%s", found)
        return found
    except redis.RedisError as e:
        logger.error("OAuth state GETDEL in Redis failed: success=False, error=%s", type(e).__name__)
        raise HTTPException(
            status_code=503,
            detail="Authentication service temporarily unavailable (state store error)."
        ) from e


# ──────────────────────────────────────────────
# OAuth Endpoints
# ──────────────────────────────────────────────

@router.get("/github/login")
async def github_login(redirect: bool = Query(False, description="If true, redirects directly to GitHub")):
    """
    Initiate GitHub OAuth login.
    Returns the authorization URL and CSRF state token, or redirects directly if requested.
    """
    try:
        logger.info("Initiating GitHub OAuth login: redirect=%s", redirect)
        auth_url, state = auth_service.create_authorization_url()
        _store_state(state)
        if redirect:
            return RedirectResponse(url=auth_url)
        return {
            "auth_url": auth_url,
            "state": state,
        }
    except HTTPException:
        raise
    except RuntimeError as e:
        logger.error("GitHub login config error: %s", str(e))
        raise HTTPException(status_code=500, detail="AUTH_FAILED")


@router.get("/github/callback")
async def github_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    """
    GitHub OAuth callback endpoint.
    Exchanges code for access token, creates a server-side session,
    and returns ONLY the BugSense session token (never the GitHub token).
    """
    logger.info(
        "Received GitHub OAuth callback: code_present=%s, state_present=%s, error_present=%s",
        bool(code),
        bool(state),
        bool(error),
    )
    if error:
        logger.warning(
            "GitHub OAuth denied: error=%s, description=%s",
            error, error_description,
        )
        return _redirect_error("access_denied", "access_denied")

    if not code:
        logger.warning("OAuth callback missing 'code' parameter")
        return _redirect_error("missing_code", "auth_failed")

    # Validate CSRF state
    try:
        if not _validate_state(state):
            logger.warning("OAuth state validation failed: state=[REDACTED]")
            return _redirect_error("invalid_state", "invalid_state")
    except HTTPException as e:
        logger.error("OAuth state validation service error: detail=%s", e.detail)
        return _redirect_error("service_unavailable", "service_unavailable")

    try:
        # 1. Exchange code for GitHub access token
        token_data = await auth_service.exchange_code_for_token(code=code, state=state)
        github_access_token = token_data.get("access_token")
        if not github_access_token:
            raise ValueError("No access_token received from GitHub.")

        # 2. Fetch the GitHub user profile with the new token
        async with httpx.AsyncClient() as client:
            user_resp = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {github_access_token}",
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "BugSense-AI",
                },
            )
            user_resp.raise_for_status()
            github_user = user_resp.json()

        logger.info("OAuth callback success: github_login=%s", github_user.get("login", "unknown"))

        # 3. Create a server-side session
        session_token = session_store.create_session(
            github_user_id=github_user.get("id", 0),
            github_login=github_user.get("login", ""),
            github_access_token=github_access_token,
            github_avatar_url=github_user.get("avatar_url", ""),
            github_name=github_user.get("name", ""),
        )

        # 4. Redirect browser to Android App Link with a one-time handoff code
        # SECURITY: The session token and github_access_token are NEVER included in this URL
        from config import get_mobile_oauth_redirect_uri
        base_url = get_mobile_oauth_redirect_uri()
        handoff_code = session_store.create_handoff_code(session_token)
        params = urllib.parse.urlencode({
            "code": handoff_code,
            "status": "authenticated",
        })
        return RedirectResponse(url=f"{base_url}?{params}")
    except HTTPException as e:
        logger.error("OAuth callback HTTPException: status=%s, detail=%s", e.status_code, e.detail)
        return _redirect_error("service_unavailable", "service_unavailable")
    except RuntimeError as e:
        logger.error("OAuth callback RuntimeError: %s", str(e))
        return _redirect_error("server_error", "auth_failed")
    except ValueError as e:
        logger.error("OAuth callback ValueError: %s", str(e))
        return _redirect_error("invalid_request", "auth_failed")
    except httpx.HTTPStatusError as e:
        logger.error("OAuth callback GitHub API error: status=%s", e.response.status_code)
        return _redirect_error("github_api_error", "auth_failed")
    except Exception as e:
        logger.error("OAuth callback unexpected error: error_type=%s, error=%s", type(e).__name__, str(e))
        return _redirect_error("internal_error", "auth_failed")


def _redirect_error(error_code: str, error_description: str) -> RedirectResponse:
    from config import get_mobile_oauth_redirect_uri
    base_url = get_mobile_oauth_redirect_uri()
    params = urllib.parse.urlencode({"error": error_code, "error_description": error_description})
    return RedirectResponse(url=f"{base_url}?{params}")


@router.post("/github/exchange")
async def github_exchange(body: ExchangeRequest):
    """
    Programmatic token exchange endpoint for mobile apps.
    Accepts authorization code, exchanges for GitHub token,
    creates session, and returns ONLY the BugSense session token.
    """
    # Validate CSRF state if provided
    if body.state and not _validate_state(body.state):
        raise HTTPException(
            status_code=400,
            detail="Invalid or expired OAuth state parameter.",
        )

    try:
        # 1. Exchange code for GitHub access token
        token_data = await auth_service.exchange_code_for_token(
            code=body.code,
            state=body.state,
        )
        github_access_token = token_data.get("access_token")
        if not github_access_token:
            raise ValueError("No access_token received from GitHub.")

        # 2. Fetch the GitHub user profile
        async with httpx.AsyncClient() as client:
            user_resp = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {github_access_token}",
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "BugSense-AI",
                },
            )
            user_resp.raise_for_status()
            github_user = user_resp.json()

        # 3. Create session (GitHub session)
        github_session_token = session_store.create_session(
            github_user_id=github_user.get("id", 0),
            github_login=github_user.get("login", ""),
            github_access_token=github_access_token,
            github_avatar_url=github_user.get("avatar_url", ""),
            github_name=github_user.get("name", ""),
        )

        # 4. Link to BugSense User if bugsense_session is provided
        from fastapi import Request
        # (Wait, Request is not injected, we'll try pulling from headers)
        # Note: If the request doesn't provide authorization here, we just return the github session token.

        # 4. Return session token + public user info only
        return {
            "status": "authenticated",
            "session_token": github_session_token,
            "user": {
                "login": github_user.get("login"),
                "name": github_user.get("name"),
                "avatar_url": github_user.get("avatar_url"),
                "id": github_user.get("id"),
            },
        }
    except RuntimeError as e:
        logger.error("Exchange RuntimeError: %s", str(e))
        raise HTTPException(status_code=500, detail="AUTH_FAILED")
    except ValueError as e:
        logger.error("Exchange ValueError: %s", str(e))
        raise HTTPException(status_code=400, detail="AUTH_FAILED")
    except httpx.HTTPStatusError as e:
        logger.error("Exchange GitHub API error: status=%s", e.response.status_code)
        raise HTTPException(status_code=502, detail="AUTH_FAILED")
    except Exception as e:
        logger.error("Exchange unexpected error: %s", str(e))
        raise HTTPException(status_code=502, detail="AUTH_FAILED")


class CallbackExchangeRequest(BaseModel):
    code: str

@router.post("/github/exchange-callback-code")
async def exchange_callback_code(body: CallbackExchangeRequest):
    """
    Exchanges a one-time callback handoff code for the actual BugSense session token.
    """
    session_token = session_store.exchange_handoff_code(body.code)
    if not session_token:
        logger.warning("Handoff code exchange failed: code=[REDACTED], reason=invalid_expired_or_reused")
        raise HTTPException(
            status_code=400, 
            detail="auth_failed"
        )
        
    session = session_store.get_session(session_token)
    if not session:
        logger.warning("Session not found after handoff exchange: session_token=[REDACTED]")
        raise HTTPException(status_code=401, detail="auth_failed")

    logger.info("Handoff code exchanged successfully: github_login=%s", session["github_login"])
    return {
        "status": "authenticated",
        "session_token": session_token,
        "user": {
            "login": session["github_login"],
            "name": session.get("github_name", ""),
            "avatar_url": session.get("github_avatar_url", ""),
            "id": session["github_user_id"],
        },
    }


# ──────────────────────────────────────────────
# Session Management
# ──────────────────────────────────────────────

@router.get("/session")
async def get_session_info(authorization: str | None = Header(None)):
    """
    Returns session info for the current session token.
    Supports both BugSense local sessions and GitHub sessions.
    Does NOT return the GitHub access token.
    """
    token = _extract_session_token(authorization)
    if not token:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")

    # Try BugSense session first
    bs_session = session_store.get_bugsense_session(token)
    if bs_session:
        return {
            "status": "active",
            "type": "bugsense",
            "user_id": bs_session["user_id"],
            "full_name": bs_session["full_name"],
            "username": bs_session["username"],
            "email": bs_session["email"],
            "github_user_id": bs_session.get("github_user_id"),
            "created_at": bs_session["created_at"],
            "expires_at": bs_session["expires_at"],
        }

    # Fall back to GitHub session
    session = session_store.get_session(token)
    if not session:
        raise HTTPException(status_code=401, detail="Invalid or expired session.")

    return {
        "status": "active",
        "type": "github",
        "github_login": session["github_login"],
        "github_user_id": session["github_user_id"],
        "github_name": session.get("github_name", ""),
        "github_avatar_url": session.get("github_avatar_url", ""),
        "created_at": session["created_at"],
        "expires_at": session["expires_at"],
    }


@router.delete("/session")
async def logout(authorization: str | None = Header(None)):
    """
    Logout: invalidate the current BugSense or GitHub session.
    """
    token = _extract_session_token(authorization)
    if not token:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")

    deleted = session_store.delete_bugsense_session(token)
    if not deleted:
        deleted = session_store.delete_session(token)
        
    if deleted:
        return {"status": "logged_out"}
    else:
        raise HTTPException(status_code=401, detail="Invalid or expired session.")


@router.delete("/account")
async def delete_account(authorization: str | None = Header(None)):
    """
    Delete the authenticated user's account and all associated data permanently.
    """
    token = _extract_session_token(authorization)
    if not token:
        raise HTTPException(status_code=401, detail="Missing Authorization header.")

    bs_session = session_store.get_bugsense_session(token)
    github_user_id = None
    github_login = None
    
    if bs_session:
        github_user_id = bs_session.get("github_user_id")
        github_login = bs_session.get("username")
    else:
        session = session_store.get_session(token)
        if not session:
            raise HTTPException(status_code=401, detail="Invalid or expired session.")
        github_user_id = session.get("github_user_id")
        github_login = session.get("github_login")

    if not github_user_id or not github_login:
        raise HTTPException(status_code=400, detail="Account deletion requires a valid GitHub link.")

    # 1. Delete Firestore user profile and bug reports
    from services.firestore_service import delete_user_data as fs_delete_user_data
    try:
        fs_delete_user_data(github_login, github_user_id)
    except Exception as e:
        logger.error("Error deleting Firestore data: %s", e)

    # 2. Delete ChromaDB collections
    try:
        from services.vector_store import get_vector_store
        vs = get_vector_store()
        if vs:
            vs.delete_user_data(github_user_id)
    except Exception as e:
        logger.error("Error deleting ChromaDB collections: %s", e)

    # 3. Delete PostgreSQL records (users, sessions, webhook events, verdicts)
    # This also invalidates the current session token since the session row is deleted.
    session_store.delete_user_data(github_user_id)

    return {"status": "account_deleted"}



def _extract_session_token(authorization: str | None) -> str | None:
    """Extract Bearer token from Authorization header."""
    if authorization and authorization.startswith("Bearer "):
        return authorization.split("Bearer ", 1)[1].strip()
    return None
