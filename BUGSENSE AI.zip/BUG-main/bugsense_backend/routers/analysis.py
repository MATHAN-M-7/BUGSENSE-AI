"""
Analysis router — AI-powered issue classification and root cause endpoints.

All user-facing endpoints require a valid BugSense session.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from services import classifier_agent, root_cause_agent, resolution_agent, adaptive_router, session_store
from services.complexity_analyzer import analyze_complexity, _try_persist
from services.evidence_validator import get_evidence_validator
from services.confidence_engine import get_confidence_engine
from services.auth_guard import require_auth

router = APIRouter(prefix="/analysis", tags=["analysis"])


# ──────────────────────────────────────────────
# Request models
# ──────────────────────────────────────────────

class ReviewVerdictRequest(BaseModel):
    """Request body for human review verdict (Approve, Edit, Reject)."""
    repo_owner: str
    repo_name: str
    issue_number: int
    verdict: str  # APPROVED, EDITED, REJECTED
    reviewer: str = "human_reviewer"
    rejection_reason: str | None = None
    edited_resolution: dict[str, Any] | None = None
    notes: str = ""


class ClassifyRequest(BaseModel):
    """Request body for issue classification."""
    repo_owner: str
    repo_name: str
    issue_number: int | None = None
    title: str
    body: str = ""
    state: str = "open"
    labels: list[str] = []
    comments_text: list[str] = []


class RouteExecuteRequest(ClassifyRequest):
    """Request body for adaptive routing and execution."""
    max_stages: int | None = None


class PriorClassification(BaseModel):
    """Optional prior classification result."""
    category: str = ""
    severity: str = ""
    evidence_summary: str = ""


class RootCauseRequest(BaseModel):
    """Request body for root cause analysis."""
    repo_owner: str
    repo_name: str
    issue_number: int | None = None
    title: str
    body: str = ""
    state: str = "open"
    labels: list[str] = []
    comments_text: list[str] = []
    classification: PriorClassification | None = None


class PriorRootCause(BaseModel):
    """Optional prior root cause analysis result."""
    probable_cause: str = ""
    affected_components: list[str] = []
    investigation_areas: list[str] = []
    analysis_summary: str = ""


class ResolveRequest(BaseModel):
    """Request body for resolution/fix generation."""
    repo_owner: str
    repo_name: str
    issue_number: int | None = None
    title: str
    body: str = ""
    state: str = "open"
    labels: list[str] = []
    comments_text: list[str] = []
    classification: PriorClassification | None = None
    root_cause: PriorRootCause | None = None


# ──────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────

@router.post("/classify", status_code=200)
async def classify_issue(body: ClassifyRequest, authorization: str | None = Header(None)):
    """
    Classify a GitHub issue using the AI Classifier Agent.

    Returns structured classification with category, severity,
    confidence scores, and evidence summary.
    """
    user = require_auth(authorization)
    try:
        issue_data = body.model_dump()
        issue_data["_github_token"] = user.github_token
        issue_data["_github_user_id"] = user.github_user_id
        result = await classifier_agent.classify_issue(issue_data)
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=f"Rate limit exceeded: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")


@router.post("/classify-rag", status_code=200)
async def classify_issue_rag(body: ClassifyRequest, authorization: str | None = Header(None)):
    """
    Classify a GitHub issue using RAG (Retrieval-Augmented Generation).

    Retrieves similar past issues from ChromaDB and uses them as
    context for improved classification accuracy. Falls back to
    standard classification if no similar issues exist.
    """
    user = require_auth(authorization)
    try:
        issue_data = body.model_dump()
        issue_data["_github_token"] = user.github_token
        issue_data["_github_user_id"] = user.github_user_id
        result = await classifier_agent.classify_issue_with_rag(issue_data)
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=f"Rate limit exceeded: {str(e)}")
        raise HTTPException(status_code=500, detail=f"RAG classification failed: {str(e)}")


@router.post("/root-cause", status_code=200)
async def root_cause_analysis(body: RootCauseRequest, authorization: str | None = Header(None)):
    """
    Perform root cause analysis on a GitHub issue.

    Returns probable cause, affected components, reproduction steps,
    investigation areas, and confidence score. Uses RAG context from
    ChromaDB if available.
    """
    user = require_auth(authorization)
    try:
        classification = body.classification.model_dump() if body.classification else None
        issue_data = body.model_dump(exclude={"classification"})
        issue_data["_github_token"] = user.github_token
        issue_data["_github_user_id"] = user.github_user_id
        result = await root_cause_agent.analyze_root_cause(
            issue_data,
            classification=classification,
        )
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=f"Rate limit exceeded: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Root cause analysis failed: {str(e)}")


@router.post("/resolve", status_code=200)
async def resolve_issue(body: ResolveRequest, authorization: str | None = Header(None)):
    """
    Generate fix suggestions for a GitHub issue.

    Returns code-level fix recommendations, implementation strategy,
    testing approach, risk assessment, estimated effort, and confidence.
    Accepts optional prior classification and root cause analysis.
    """
    user = require_auth(authorization)
    try:
        classification = body.classification.model_dump() if body.classification else None
        root_cause = body.root_cause.model_dump() if body.root_cause else None
        issue_data = body.model_dump(exclude={"classification", "root_cause"})
        issue_data["_github_token"] = user.github_token
        issue_data["_github_user_id"] = user.github_user_id
        result = await resolution_agent.generate_resolution(
            issue_data,
            classification=classification,
            root_cause=root_cause,
        )
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        if any(k in str(e).lower() for k in ("429", "quota", "too_many_requests")):
            raise HTTPException(status_code=429, detail=f"Rate limit exceeded: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Resolution generation failed: {str(e)}")


@router.post("/complexity")
async def analyze_issue_complexity(req: ClassifyRequest, authorization: str | None = Header(None)):
    """Compute deterministic complexity score for a GitHub issue.

    No LLM calls — pure signal extraction. Optionally uses ChromaDB
    context for the retrieval_ambiguity signal.
    """
    user = require_auth(authorization)
    issue_data = req.model_dump()
    issue_data["_github_token"] = user.github_token
    issue_data["_github_user_id"] = user.github_user_id

    # Attempt to retrieve similar issues for retrieval_ambiguity
    similar_issues: list | None = None
    try:
        from services.vector_store import VectorStore
        import asyncio

        vs = VectorStore()
        similar_issues = await asyncio.wait_for(
            asyncio.to_thread(
                vs.search_similar,
                repo_owner=req.repo_owner,
                repo_name=req.repo_name,
                query=f"{req.title}\n{req.body}",
                n_results=5,
                github_user_id=user.github_user_id,
            ),
            timeout=75.0
        )
        if not similar_issues:
            similar_issues = None
    except Exception:
        similar_issues = None  # graceful degradation

    result = analyze_complexity(issue_data, similar_issues)

    # Best-effort Firestore persistence
    doc_id = _try_persist(result)
    if doc_id:
        result["firestore_id"] = doc_id

    return result


@router.post("/route/plan", status_code=200)
async def plan_adaptive_route(req: ClassifyRequest, authorization: str | None = Header(None)):
    """
    Plan the optimal execution path for an issue using the Adaptive Agent Router.

    Zero LLM calls — instant, deterministic evaluation using complexity signals
    and configurable routing policy.
    """
    user = require_auth(authorization)
    issue_data = req.model_dump()
    issue_data["_github_token"] = user.github_token
    issue_data["_github_user_id"] = user.github_user_id
    similar_issues: list | None = None
    try:
        from services.vector_store import VectorStore
        import asyncio
        vs = VectorStore()
        similar_issues = await asyncio.wait_for(
            asyncio.to_thread(
                vs.search_similar,
                repo_owner=req.repo_owner,
                repo_name=req.repo_name,
                query=f"{req.title}\n{req.body}",
                n_results=5,
                github_user_id=user.github_user_id,
            ),
            timeout=75.0
        )
        if not similar_issues:
            similar_issues = None
    except Exception:
        similar_issues = None

    plan = adaptive_router.plan_route(issue_data, similar_issues=similar_issues)
    return plan


@router.post("/route", status_code=200)
async def execute_adaptive_route(req: RouteExecuteRequest, authorization: str | None = Header(None)):
    """
    Execute confidence-aware adaptive agent routing on a GitHub issue.

    Plans the route based on issue complexity signals, then orchestrates
    agents with runtime confidence gating and dynamic adaptations.
    """
    user = require_auth(authorization)
    issue_data = req.model_dump(exclude={"max_stages"})
    issue_data["_github_token"] = user.github_token
    issue_data["_github_user_id"] = user.github_user_id
    similar_issues: list | None = None
    try:
        from services.vector_store import VectorStore

        import asyncio
        vs = VectorStore()
        
        # Wrapped in to_thread and wait_for to prevent blocking the async loop and to enforce a timeout
        similar_issues = await asyncio.wait_for(
            asyncio.to_thread(
                vs.search_similar,
                repo_owner=req.repo_owner,
                repo_name=req.repo_name,
                query=f"{req.title}\n{req.body}",
                n_results=5,
                github_user_id=user.github_user_id,
            ),
            timeout=75.0
        )
        if not similar_issues:
            similar_issues = None
    except Exception:
        similar_issues = None

    try:
        result = await adaptive_router.route_and_execute(
            issue_data,
            max_stages=req.max_stages,
            similar_issues=similar_issues,
        )
        return result
    except RuntimeError as e:
        if "GEMINI_API_KEY" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Adaptive routing execution failed: {str(e)}")


# ──────────────────────────────────────────────
# Evidence-Based Validation
# ──────────────────────────────────────────────

class ValidateEvidenceRequest(BaseModel):
    """Request body for standalone evidence validation."""
    title: str
    body: str = ""
    labels: list[str] = []
    comments_text: list[str] = []
    classification: dict | None = None
    root_cause: dict | None = None
    resolution: dict | None = None
    rag_context: list[dict] | None = None


@router.post("/validate-evidence")
async def validate_evidence(req: ValidateEvidenceRequest, authorization: str | None = Header(None)):
    """Validate pipeline outputs against source evidence.

    Cross-references agent claims (classification, root cause, resolution)
    against the original issue text and optional RAG context.
    Returns per-claim evidence checks, an aggregate evidence_score,
    and a validation verdict (STRONG / MODERATE / WEAK / INSUFFICIENT).

    Zero LLM calls — deterministic textual analysis.
    """
    require_auth(authorization)
    issue_data = {
        "title": req.title,
        "body": req.body,
        "labels": req.labels,
        "comments_text": req.comments_text,
    }
    validator = get_evidence_validator()
    result = validator.validate(
        issue_data=issue_data,
        classification=req.classification,
        root_cause=req.root_cause,
        resolution=req.resolution,
        rag_context=req.rag_context,
    )
    return result.to_dict()

# ──────────────────────────────────────────────
# Confidence Engine
# ──────────────────────────────────────────────

@router.post("/evaluate-confidence")
async def evaluate_confidence(routing_result: dict, authorization: str | None = Header(None)):
    """Evaluate a completed routing payload to compute system confidence.
    
    Synthesizes LLM self-confidence, evidence validation scores, RAG similarity,
    and issue complexity to compute a single 0.0-1.0 System Confidence score
    and an overall pipeline status (READY_FOR_PR, etc.).
    """
    require_auth(authorization)
    try:
        engine = get_confidence_engine()
        report = engine.evaluate(routing_result)
        return report.to_dict()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Confidence evaluation failed: {str(e)}")


@router.get("/history")
async def list_analyses(limit: int = Query(20, ge=1, le=100), authorization: str | None = Header(None)):
    """List recent analysis results from Firestore for the authenticated user."""
    user = require_auth(authorization)
    results = classifier_agent.list_analyses(limit=limit, github_user_id=user.github_user_id)
    return {"count": len(results), "analyses": results}


@router.get("/{analysis_id}")
async def get_analysis(analysis_id: str, authorization: str | None = Header(None)):
    """Retrieve a specific analysis result by ID (must belong to authenticated user)."""
    user = require_auth(authorization)
    result = classifier_agent.get_analysis(analysis_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Analysis '{analysis_id}' not found (Firestore may not be configured).",
        )
    # Verify ownership: the analysis must belong to the authenticated user
    stored_user_id = result.get("github_user_id")
    if stored_user_id is not None and stored_user_id != user.github_user_id:
        raise HTTPException(
            status_code=403,
            detail="You do not have access to this analysis.",
        )
    return result


# ──────────────────────────────────────────────
# Human-in-the-Loop Review Verdicts (PostgreSQL Persistence)
# ──────────────────────────────────────────────

@router.post("/review/verdict")
async def submit_review_verdict(req: ReviewVerdictRequest, authorization: str | None = Header(None)):
    """Record human review decision (APPROVE, EDIT, REJECT) on AI resolution."""
    user = require_auth(authorization)
    normalized_verdict = req.verdict.upper().strip()
    if normalized_verdict not in ("APPROVED", "EDITED", "REJECTED"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid verdict '{req.verdict}'. Expected one of: APPROVED, EDITED, REJECTED",
        )

    if normalized_verdict == "REJECTED" and not req.rejection_reason:
        req.rejection_reason = "Unspecified rejection reason"

    record = session_store.save_review_verdict(
        github_user_id=user.github_user_id,
        github_login=user.github_login,
        repo_owner=req.repo_owner,
        repo_name=req.repo_name,
        issue_number=req.issue_number,
        verdict=normalized_verdict,
        reviewer=req.reviewer,
        rejection_reason=req.rejection_reason,
        notes=req.notes,
        has_edited_resolution=req.edited_resolution is not None,
        edited_resolution=req.edited_resolution,
    )

    return {
        "status": "recorded",
        "verdict": normalized_verdict,
        "repo_owner": req.repo_owner,
        "repo_name": req.repo_name,
        "issue_number": req.issue_number,
        "rejection_reason": req.rejection_reason,
        "recorded_at": record["recorded_at"],
    }


@router.get("/review/verdicts")
async def get_review_verdicts(
    repo_owner: str | None = None,
    repo_name: str | None = None,
    issue_number: int | None = None,
    authorization: str | None = Header(None),
):
    """Retrieve audit history of human review verdicts strictly scoped to authenticated user."""
    user = require_auth(authorization)
    verdicts = session_store.get_review_verdicts(
        github_user_id=user.github_user_id,
        repo_owner=repo_owner,
        repo_name=repo_name,
        issue_number=issue_number,
    )
    return {"count": len(verdicts), "verdicts": verdicts}


def get_latest_verdict(
    repo_owner: str,
    repo_name: str,
    issue_number: int,
    github_user_id: int | None = None,
) -> dict[str, Any] | None:
    """Helper to query the latest human review decision for an issue."""
    return session_store.get_latest_review_verdict(
        repo_owner=repo_owner,
        repo_name=repo_name,
        issue_number=issue_number,
        github_user_id=github_user_id,
    )
