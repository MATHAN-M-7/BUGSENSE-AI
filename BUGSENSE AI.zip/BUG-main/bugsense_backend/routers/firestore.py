"""
Firestore router — CRUD endpoints for bug reports and user profiles.

All endpoints require a valid BugSense session. Bug reports are
associated with the authenticated user's GitHub identity and
ownership is enforced on reads, updates, and deletes.
"""

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from services import firestore_service as fs
from services.auth_guard import require_auth

router = APIRouter(prefix="/firestore", tags=["firestore"])


# ──────────────────────────────────────────────
# Request / response models
# ──────────────────────────────────────────────

class BugReportCreate(BaseModel):
    repo_owner: str
    repo_name: str
    issue_number: int | None = None
    title: str
    body: str = ""
    state: str = "open"
    labels: list[str] = []
    created_by: str = ""
    status: str = "new"


class BugReportUpdate(BaseModel):
    title: str | None = None
    body: str | None = None
    state: str | None = None
    labels: list[str] | None = None
    status: str | None = None


class UserUpsert(BaseModel):
    login: str
    name: str | None = None
    avatar_url: str | None = None
    bio: str | None = None
    public_repos: int = 0
    followers: int = 0
    html_url: str | None = None


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _firestore_guard(func):
    """Decorator that converts Firebase init errors into 503 responses."""
    from functools import wraps

    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except RuntimeError as e:
            if "Firebase" in str(e) or "service account" in str(e).lower():
                raise HTTPException(status_code=503, detail=str(e))
            raise

    return wrapper


# ──────────────────────────────────────────────
# Bug Reports
# ──────────────────────────────────────────────

@router.post("/bug-reports", status_code=201)
@_firestore_guard
async def create_bug_report(body: BugReportCreate, authorization: str | None = Header(None)):
    """Create a new bug report in Firestore, associated with the authenticated user."""
    user = require_auth(authorization)
    data = body.model_dump()
    # Associate with the authenticated user
    data["github_user_id"] = user.github_user_id
    data["created_by"] = data.get("created_by") or user.github_login
    doc_id = fs.create_bug_report(data)
    return {"id": doc_id, "status": "created"}


@router.get("/bug-reports")
@_firestore_guard
async def list_bug_reports(
    repo_owner: str | None = Query(None),
    repo_name: str | None = Query(None),
    status: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    authorization: str | None = Header(None),
):
    """List bug reports belonging to the authenticated user."""
    user = require_auth(authorization)
    reports = fs.list_bug_reports(
        repo_owner=repo_owner,
        repo_name=repo_name,
        status=status,
        limit=limit,
        github_user_id=user.github_user_id,
    )
    return reports


@router.get("/bug-reports/{doc_id}")
@_firestore_guard
async def get_bug_report(doc_id: str, authorization: str | None = Header(None)):
    """Retrieve a specific bug report by document ID (ownership verified)."""
    user = require_auth(authorization)
    report = fs.get_bug_report(doc_id)
    if report is None:
        raise HTTPException(status_code=404, detail=f"Bug report '{doc_id}' not found.")
    # Verify ownership
    if report.get("github_user_id") is not None and report["github_user_id"] != user.github_user_id:
        raise HTTPException(status_code=403, detail="You do not have access to this bug report.")
    return report


@router.patch("/bug-reports/{doc_id}")
@_firestore_guard
async def update_bug_report(doc_id: str, body: BugReportUpdate, authorization: str | None = Header(None)):
    """Update fields on an existing bug report (ownership verified)."""
    user = require_auth(authorization)
    # Verify ownership first
    report = fs.get_bug_report(doc_id)
    if report is None:
        raise HTTPException(status_code=404, detail=f"Bug report '{doc_id}' not found.")
    if report.get("github_user_id") is not None and report["github_user_id"] != user.github_user_id:
        raise HTTPException(status_code=403, detail="You do not have permission to update this bug report.")

    update_data = body.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update.")

    updated = fs.update_bug_report(doc_id, update_data)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bug report '{doc_id}' not found.")
    return {"id": doc_id, "status": "updated"}


@router.delete("/bug-reports/{doc_id}")
@_firestore_guard
async def delete_bug_report(doc_id: str, authorization: str | None = Header(None)):
    """Delete a bug report (ownership verified)."""
    user = require_auth(authorization)
    # Verify ownership first
    report = fs.get_bug_report(doc_id)
    if report is None:
        raise HTTPException(status_code=404, detail=f"Bug report '{doc_id}' not found.")
    if report.get("github_user_id") is not None and report["github_user_id"] != user.github_user_id:
        raise HTTPException(status_code=403, detail="You do not have permission to delete this bug report.")

    deleted = fs.delete_bug_report(doc_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Bug report '{doc_id}' not found.")
    return {"id": doc_id, "status": "deleted"}


# ──────────────────────────────────────────────
# Users
# ──────────────────────────────────────────────

@router.post("/users", status_code=201)
@_firestore_guard
async def upsert_user(body: UserUpsert, authorization: str | None = Header(None)):
    """Create or update a user profile (must be the authenticated user's own profile)."""
    user = require_auth(authorization)
    # Only allow updating your own profile
    if body.login.lower() != user.github_login.lower():
        raise HTTPException(
            status_code=403,
            detail="You can only create or update your own user profile.",
        )
    doc_id = fs.upsert_user(body.login, body.model_dump())
    return {"id": doc_id, "status": "upserted"}


@router.get("/users/{login}")
@_firestore_guard
async def get_user(login: str, authorization: str | None = Header(None)):
    """Retrieve a stored user profile (public GitHub data)."""
    require_auth(authorization)
    user_data = fs.get_user(login)
    if user_data is None:
        raise HTTPException(status_code=404, detail=f"User '{login}' not found.")
    return user_data
