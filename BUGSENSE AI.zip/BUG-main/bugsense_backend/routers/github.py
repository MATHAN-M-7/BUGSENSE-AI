"""
GitHub API router — exposes the GitHub service as REST endpoints.
Requires a valid BugSense session (Authorization: Bearer <session_token>).
"""

from fastapi import APIRouter, Header, HTTPException, Query
import httpx

from services import github_service as gh
from services.auth_guard import require_auth

router = APIRouter(prefix="/github", tags=["github"])


@router.get("/user")
async def github_user(authorization: str | None = Header(None)):
    """Return the authenticated GitHub user profile."""
    user = require_auth(authorization)
    try:
        return await gh.get_authenticated_user(token=user.github_token)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.get("/repos")
async def github_repos(
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    authorization: str | None = Header(None),
):
    """List repositories for the authenticated user."""
    user = require_auth(authorization)
    try:
        return await gh.list_repos(per_page=per_page, page=page, token=user.github_token)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.get("/repos/{owner}/{repo}")
async def github_repo_detail(
    owner: str,
    repo: str,
    authorization: str | None = Header(None),
):
    """Get details for a specific repository."""
    user = require_auth(authorization)
    try:
        return await gh.get_repo(owner, repo, token=user.github_token)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.get("/repos/{owner}/{repo}/issues")
async def github_issues(
    owner: str,
    repo: str,
    state: str = Query("open", pattern="^(open|closed|all)$"),
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    authorization: str | None = Header(None),
):
    """List issues for a repository (excludes pull requests)."""
    user = require_auth(authorization)
    try:
        return await gh.list_issues(
            owner, repo, state=state, per_page=per_page, page=page, token=user.github_token
        )
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.get("/repos/{owner}/{repo}/issues/{issue_number}")
async def github_issue_detail(
    owner: str,
    repo: str,
    issue_number: int,
    authorization: str | None = Header(None),
):
    """Get a single issue by number."""
    user = require_auth(authorization)
    try:
        return await gh.get_issue(owner, repo, issue_number, token=user.github_token)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.get("/repos/{owner}/{repo}/issues/{issue_number}/comments")
async def github_issue_comments(
    owner: str,
    repo: str,
    issue_number: int,
    per_page: int = Query(30, ge=1, le=100),
    page: int = Query(1, ge=1),
    authorization: str | None = Header(None),
):
    """List comments on an issue."""
    user = require_auth(authorization)
    try:
        return await gh.list_issue_comments(
            owner, repo, issue_number, per_page=per_page, page=page, token=user.github_token
        )
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))


@router.post("/repos/{owner}/{repo}/issues/{issue_number}/generate-pr")
async def generate_pr(
    owner: str,
    repo: str,
    issue_number: int,
    routing_result: dict,
    human_approved: bool = Query(False, description="Explicit human approval for REQUIRES_HUMAN_REVIEW status"),
    authorization: str | None = Header(None),
):
    """Safe PR Gate: Automates PR creation or update with deterministic branching and confidence gating."""
    user = require_auth(authorization)
    token = user.github_token
    
    # 0. Check Human Review Rejection
    from routers.analysis import get_latest_verdict
    latest_verdict = get_latest_verdict(owner, repo, issue_number, github_user_id=user.github_user_id)
    if (latest_verdict and latest_verdict.get("verdict") == "REJECTED") or routing_result.get("is_rejected"):
        reason = (latest_verdict.get("rejection_reason") if latest_verdict else None) or routing_result.get("rejection_reason", "Rejected by engineer")
        raise HTTPException(
            status_code=403,
            detail={
                "message": f"PR Gate Locked: Resolution has been rejected by human review ({reason}).",
                "system_status": "REJECTED",
                "rejection_reason": reason,
            }
        )

    # 1. Gate Check
    conf_report = routing_result.get("system_confidence_report", {})
    status = conf_report.get("system_status")
    
    if status != "READY_FOR_PR":
        if status == "REQUIRES_HUMAN_REVIEW" and human_approved:
            pass  # Authorized by human review on mobile / dashboard
        else:
            raise HTTPException(
                status_code=403,
                detail={
                    "message": "Pipeline execution does not meet confidence threshold for automated PR creation.",
                    "system_status": status,
                    "confidence_score": conf_report.get("system_confidence"),
                    "penalties": conf_report.get("penalties_applied", []),
                    "human_approval_required": status == "REQUIRES_HUMAN_REVIEW",
                }
            )
    
    # Propagate human approval and refinement into routing_result for PR markdown
    routing_result["human_approved"] = human_approved or (status == "READY_FOR_PR")
    if "is_human_edited" not in routing_result and latest_verdict and latest_verdict.get("verdict") == "EDITED":
        routing_result["is_human_edited"] = True

    # 2. Extract resolution data
    resolution = routing_result.get("resolution", {})
    fix_description = resolution.get("fix_description", "BugSense automated fix")
    code_suggestions = resolution.get("code_suggestions", [])
    
    if not code_suggestions:
        raise HTTPException(status_code=400, detail="No code suggestions found in resolution.")
        
    try:
        # 3. Default branch and target branch name
        default_branch = await gh.get_default_branch(owner, repo, token=token)
        branch_name = f"bugsense/issue-{issue_number}-fix"

        # 4. Ensure branch exists (idempotent)
        branch_info = await gh.ensure_branch(owner, repo, branch_name, base_branch=default_branch, token=token)
        
        # 5. Build structured patch content and commit to branch
        patch_file = f".bugsense/patches/issue_{issue_number}_patch.md"
        patch_content = f"# BugSense Automated Fix for Issue #{issue_number}\n\n"
        patch_content += f"## Description\n{fix_description}\n\n"
        for idx, cs in enumerate(code_suggestions):
            patch_content += f"### Change {idx+1}: {cs.get('file_or_component')}\n"
            patch_content += f"{cs.get('change_description') or cs.get('explanation', '')}\n\n"
            patch_content += "```\n" + cs.get('code_snippet', '') + "\n```\n\n"
            
        commit_msg = f"BugSense AI: Automated resolution for issue #{issue_number}"
        await gh.create_or_update_file(
            owner, repo, patch_file, commit_msg, patch_content, branch_name, token=token
        )
        
        # 6. Build Publication-Grade PR Markdown Body
        issue_title = routing_result.get("issue_title") or f"Issue #{issue_number}"
        pr_title = f"[BugSense] Fix #{issue_number}: {issue_title}"
        pr_body = gh.build_pr_markdown(owner, repo, issue_number, issue_title, routing_result)
        
        # 7. Check if a PR already exists for this branch (idempotent PR lifecycle)
        existing_pr = await gh.find_pull_request(owner, repo, branch_name, state="open", token=token)
        
        if existing_pr:
            # Update existing PR
            pr_number = existing_pr["number"]
            updated_pr = await gh.update_pull_request(
                owner, repo, pr_number, title=pr_title, body=pr_body, token=token
            )
            # Add update note to PR thread
            await gh.add_issue_comment(
                owner,
                repo,
                pr_number,
                f"🔄 **BugSense AI Update**: Refreshed pull request with latest verified resolution. System confidence: `{conf_report.get('system_confidence')}`.",
                token=token,
            )
            return {
                "status": "updated",
                "is_updated": True,
                "pr_url": updated_pr.get("html_url") or existing_pr.get("html_url"),
                "pr_number": pr_number,
                "branch": branch_name,
                "is_new_branch": branch_info.get("is_new", False),
            }
        else:
            # Create new PR
            pr_res = await gh.create_pull_request(
                owner, repo, pr_title, pr_body, branch_name, default_branch, token=token
            )
            pr_number = pr_res.get("number")
            if pr_number:
                # Attach labels
                await gh.add_labels_to_issue(
                    owner, repo, pr_number, ["bugsense-ai", "automated-fix"], token=token
                )
            
            return {
                "status": "created",
                "is_updated": False,
                "pr_url": pr_res.get("html_url"),
                "pr_number": pr_number,
                "branch": branch_name,
                "is_new_branch": branch_info.get("is_new", False),
            }
        
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"GitHub API error: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/repos/{owner}/{repo}/issues/{issue_number}/pr")
async def get_issue_pr(
    owner: str,
    repo: str,
    issue_number: int,
    authorization: str | None = Header(None),
):
    """Inquire if BugSense AI has created a Pull Request for a given issue."""
    user = require_auth(authorization)
    token = user.github_token
    branch_name = f"bugsense/issue-{issue_number}-fix"

    try:
        pr = await gh.find_pull_request(owner, repo, branch_name, state="open", token=token)
        if not pr:
            # Check closed PRs
            pr = await gh.find_pull_request(owner, repo, branch_name, state="closed", token=token)

        if pr:
            return {
                "has_pr": True,
                "pr_number": pr.get("number"),
                "pr_url": pr.get("html_url"),
                "state": pr.get("state"),
                "title": pr.get("title"),
                "branch": branch_name,
                "merged_at": pr.get("merged_at"),
                "created_at": pr.get("created_at"),
            }
        else:
            return {
                "has_pr": False,
                "pr_number": None,
                "pr_url": None,
                "state": None,
                "branch": branch_name,
            }
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

