"""
GitHub Webhook router — receives and verifies webhook deliveries.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Header, Request
from pydantic import BaseModel

from config import get_github_webhook_secret, is_production
from services import webhook_service as ws
from services import session_store
from services.auth_guard import require_auth, verify_repo_access

logger = logging.getLogger("bugsense.webhooks")

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


# ──────────────────────────────────────────────
# Models
# ──────────────────────────────────────────────

class TestWebhookPayload(BaseModel):
    """Body for the dev-only test endpoint."""
    event_type: str = "issues"
    payload: dict = {}


# ──────────────────────────────────────────────
# Main webhook receiver
# ──────────────────────────────────────────────

@router.post("/github", status_code=200)
async def receive_github_webhook(
    request: Request,
    x_github_event: str = Header(None, alias="X-GitHub-Event"),
    x_hub_signature_256: str = Header(None, alias="X-Hub-Signature-256"),
    x_github_delivery: str = Header(None, alias="X-GitHub-Delivery"),
):
    """
    Receive a GitHub webhook delivery.

    - Reads raw body for HMAC verification.
    - Strictly enforces GITHUB_WEBHOOK_SECRET in production.
    - Validates X-Hub-Signature-256.
    - Persists tenant-scoped event metadata.
    """
    # Read raw body (needed for signature verification)
    raw_body = await request.body()

    secret = get_github_webhook_secret()
    if is_production() and not secret:
        raise HTTPException(
            status_code=500,
            detail="GITHUB_WEBHOOK_SECRET must be configured in production environment.",
        )

    # Verify signature if a secret is configured or in production
    if secret or is_production():
        if not x_hub_signature_256:
            raise HTTPException(
                status_code=403,
                detail="Missing X-Hub-Signature-256 header.",
            )
        if not ws.verify_signature(raw_body, x_hub_signature_256, secret or ""):
            raise HTTPException(
                status_code=403,
                detail="Invalid webhook signature.",
            )
    else:
        logger.warning(
            "GITHUB_WEBHOOK_SECRET is not set — webhook signature verification is DISABLED. "
            "This is acceptable for development but NOT for production."
        )

    # Parse event
    if not x_github_event:
        raise HTTPException(
            status_code=400,
            detail="Missing X-GitHub-Event header.",
        )

    payload = await request.json()
    result = ws.process_event(x_github_event, payload)

    # Persist webhook event metadata scoped by sender and repository
    repo_full_name = payload.get("repository", {}).get("full_name", "unknown/unknown")
    sender_id = payload.get("sender", {}).get("id")
    sender_login = payload.get("sender", {}).get("login")
    session_store.save_webhook_event(
        event_type=x_github_event,
        action=payload.get("action", "received"),
        delivery_id=x_github_delivery,
        repo_full_name=repo_full_name,
        sender_id=sender_id,
        sender_login=sender_login,
        summary=result,
    )

    return {
        "status": "received",
        "event": x_github_event,
        "delivery": x_github_delivery,
        "result": result,
    }


# ──────────────────────────────────────────────
# Recent events listing (Tenant-Scoped)
# ──────────────────────────────────────────────

@router.get("/github/events")
async def list_recent_events(
    repo: str | None = None,
    limit: int = 20,
    authorization: str | None = Header(None),
):
    """
    Return recent webhook events scoped to the authenticated user.
    If repo ('owner/repo') is provided, verifies caller repository access.
    Otherwise, returns events initiated by the authenticated user.
    """
    user = require_auth(authorization)

    if repo:
        if "/" not in repo:
            raise HTTPException(status_code=400, detail="Repository must be specified as 'owner/repo'.")
        owner, repo_name = repo.split("/", 1)
        await verify_repo_access(owner, repo_name, user)
        events = session_store.get_webhook_events(
            github_user_id=user.github_user_id,
            repo_full_name=repo,
            limit=min(limit, 100),
        )
    else:
        events = session_store.get_webhook_events(
            github_user_id=user.github_user_id,
            limit=min(limit, 100),
        )

    return {"count": len(events), "events": events}


# ──────────────────────────────────────────────
# Dev-only test endpoint (Strictly disabled in prod)
# ──────────────────────────────────────────────

@router.post("/github/test", status_code=200)
async def simulate_webhook(body: TestWebhookPayload):
    """
    Simulate a webhook event for local development only.
    Strictly disabled in production.
    """
    if is_production():
        raise HTTPException(
            status_code=403,
            detail="Test webhook endpoint is disabled in production.",
        )

    secret = get_github_webhook_secret()
    if secret:
        raise HTTPException(
            status_code=403,
            detail="Test endpoint is disabled when GITHUB_WEBHOOK_SECRET is configured. "
                   "Use a real webhook or remove the secret for dev testing.",
        )

    result = ws.process_event(body.event_type, body.payload)
    return {
        "status": "simulated",
        "event": body.event_type,
        "result": result,
    }
