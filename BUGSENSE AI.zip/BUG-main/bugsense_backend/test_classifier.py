"""
Automated tests for AI Classifier Agent in BugSense Backend.

Tests:
1. Health check regression.
2. POST /analysis/classify with a real-style GitHub issue.
3. Response schema validation (all fields, correct types).
4. Category and severity enum validation.
5. Confidence score range validation.
6. Evidence summary is non-empty.
7. Multiple issue types (bug, feature, documentation).
8. Graceful failure when GEMINI_API_KEY is not set → 503.
9. GET /analysis/history returns list.

Requires: FastAPI server running on localhost:8000 and GEMINI_API_KEY set in .env.
"""

import sys
import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"

VALID_CATEGORIES = {"Bug", "Feature", "Enhancement", "Documentation", "Other"}
VALID_SEVERITIES = {"Critical", "High", "Medium", "Low"}


def check(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def validate_classification(data: dict, label: str, results: list):
    """Validate a classification response has all required fields with correct types."""
    # Category
    cat = data.get("category", "")
    results.append(check(
        f"{label}: category is valid enum",
        cat in VALID_CATEGORIES,
        f"category={cat}",
    ))

    # Severity
    sev = data.get("severity", "")
    results.append(check(
        f"{label}: severity is valid enum",
        sev in VALID_SEVERITIES,
        f"severity={sev}",
    ))

    # Category confidence
    cat_conf = data.get("category_confidence")
    results.append(check(
        f"{label}: category_confidence in [0, 1]",
        isinstance(cat_conf, (int, float)) and 0.0 <= cat_conf <= 1.0,
        f"category_confidence={cat_conf}",
    ))

    # Severity confidence
    sev_conf = data.get("severity_confidence")
    results.append(check(
        f"{label}: severity_confidence in [0, 1]",
        isinstance(sev_conf, (int, float)) and 0.0 <= sev_conf <= 1.0,
        f"severity_confidence={sev_conf}",
    ))

    # Evidence summary
    evidence = data.get("evidence_summary", "")
    results.append(check(
        f"{label}: evidence_summary is non-empty",
        isinstance(evidence, str) and len(evidence) > 10,
        f"evidence_summary={evidence[:80]}...",
    ))

    # Model
    model = data.get("model", "")
    results.append(check(
        f"{label}: model field present",
        isinstance(model, str) and len(model) > 0,
        f"model={model}",
    ))


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense AI Classifier Agent")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    health_ok = r.status_code == 200 and bool(version)
    results.append(check(f"GET /health returns version {version}", health_ok))

    # --- 1. Classify a bug issue ---
    print("\n-- Bug Issue Classification --")
    bug_payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 42,
        "title": "App crashes when clicking submit button on login form",
        "body": (
            "When I click the submit button on the login form, the app crashes "
            "with a NullPointerException. This happens every time on Android 14. "
            "Stack trace:\n"
            "java.lang.NullPointerException: Attempt to invoke virtual method "
            "'void android.widget.Button.setOnClickListener' on a null object reference\n"
            "at com.example.app.LoginActivity.onCreate(LoginActivity.java:42)\n\n"
            "Steps to reproduce:\n"
            "1. Open the app\n"
            "2. Enter any email and password\n"
            "3. Click Submit\n"
            "4. App crashes immediately"
        ),
        "state": "open",
        "labels": ["bug", "crash"],
    }
    r = httpx.post(f"{BASE}/analysis/classify", json=bug_payload, timeout=60.0)

    if r.status_code == 503:
        detail = r.json().get("detail", "")
        gemini_missing = "GEMINI_API_KEY" in detail
        results.append(check(
            "POST /analysis/classify returns 503 when Gemini is unconfigured",
            gemini_missing,
            f"Detail: {detail[:80]}...",
        ))
        results.append(check("Classifier tests skipped (no API key)", True, "Expected"))
        _summary(results)
        return

    bug_ok = r.status_code == 200
    results.append(check("POST /analysis/classify returns 200", bug_ok, f"status={r.status_code}"))

    if not bug_ok:
        print(f"    Response: {r.status_code} {r.text[:300]}")
        _summary(results)
        return

    bug_data = r.json()
    validate_classification(bug_data, "Bug", results)

    # Check that this was classified as a Bug (high likelihood given the obvious crash report)
    results.append(check(
        "Bug issue classified as Bug category",
        bug_data.get("category") == "Bug",
        f"Got: {bug_data.get('category')}",
    ))

    # --- 2. Classify a feature request ---
    print("\n-- Feature Request Classification --")
    feature_payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 43,
        "title": "Add dark mode support",
        "body": (
            "It would be great if the application supported a dark mode theme. "
            "Many modern apps provide this feature for users who prefer darker "
            "backgrounds, especially when using the app at night. "
            "This could include:\n"
            "- Dark background with light text\n"
            "- Toggle in settings\n"
            "- Follow system theme automatically"
        ),
        "state": "open",
        "labels": ["enhancement"],
    }
    r = httpx.post(f"{BASE}/analysis/classify", json=feature_payload, timeout=60.0)
    feat_ok = r.status_code == 200
    results.append(check("Feature request classification returns 200", feat_ok))

    if feat_ok:
        feat_data = r.json()
        validate_classification(feat_data, "Feature", results)
        # Should be Feature or Enhancement
        results.append(check(
            "Feature request classified as Feature/Enhancement",
            feat_data.get("category") in ("Feature", "Enhancement"),
            f"Got: {feat_data.get('category')}",
        ))

    # --- 3. Classify a documentation issue ---
    print("\n-- Documentation Issue Classification --")
    doc_payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 44,
        "title": "README is missing installation instructions",
        "body": (
            "The README.md file does not include any installation instructions. "
            "New users have no idea how to set up the project. "
            "Please add a Getting Started section with:\n"
            "- Prerequisites\n"
            "- Installation steps\n"
            "- How to run locally"
        ),
        "state": "open",
        "labels": ["documentation"],
    }
    r = httpx.post(f"{BASE}/analysis/classify", json=doc_payload, timeout=60.0)
    doc_ok = r.status_code == 200
    results.append(check("Documentation issue classification returns 200", doc_ok))

    if doc_ok:
        doc_data = r.json()
        validate_classification(doc_data, "Documentation", results)
        results.append(check(
            "Documentation issue classified as Documentation",
            doc_data.get("category") == "Documentation",
            f"Got: {doc_data.get('category')}",
        ))

    # --- 4. Analysis history ---
    print("\n-- Analysis History --")
    r = httpx.get(f"{BASE}/analysis/history", params={"limit": 10})
    history_ok = r.status_code == 200
    results.append(check("GET /analysis/history returns 200", history_ok))

    # --- 5. Analysis by ID (if we got one from the bug classification) ---
    analysis_id = bug_data.get("analysis_id")
    if analysis_id:
        r = httpx.get(f"{BASE}/analysis/{analysis_id}")
        get_ok = r.status_code == 200 and r.json().get("category") == bug_data["category"]
        results.append(check(f"GET /analysis/{analysis_id[:8]}... retrieves stored result", get_ok))
    else:
        results.append(check("Analysis persistence to Firestore", True, "Skipped (no Firestore)"))

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("CLASSIFIER TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All classifier tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
