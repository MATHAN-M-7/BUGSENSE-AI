"""
Automated end-to-end tests for the complete BugSense AI Pipeline.

Validates the full chain:
1. Pre-flight health and OpenAPI schema checks.
2. ChromaDB Knowledge Base verification & semantic search.
3. Stage 1: RAG-enhanced classification (POST /analysis/classify-rag).
4. Stage 2: Root cause analysis chaining with prior classification (POST /analysis/root-cause).
5. Stage 3: Resolution / fix generation chaining with prior classification + root cause (POST /analysis/resolve).
6. Cross-stage pipeline coherence and data integrity.
7. Pipeline robustness: standalone agent calls & non-indexed repo fallback.
8. Regression: standard classification & search endpoints.

Requires: FastAPI server running on localhost:8000.
"""

import sys
import os
import httpx
from dotenv import load_dotenv

load_dotenv()
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from services.session_store import create_session

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"

try:
    TEST_TOKEN = create_session(github_user_id=1234, github_login="testuser", github_access_token="fake_token")
    AUTH_HEADER = {"Authorization": f"Bearer {TEST_TOKEN}"}
except Exception as e:
    print(f"Failed to generate test token: {e}")
    TEST_TOKEN = ""
    AUTH_HEADER = {}


VALID_CATEGORIES = {"Bug", "Feature", "Enhancement", "Documentation", "Other"}
VALID_SEVERITIES = {"Critical", "High", "Medium", "Low"}
VALID_EFFORTS = {"Trivial", "Small", "Medium", "Large", "Unknown"}


def check(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Complete AI Pipeline (End-to-End)")
    print(f"{'='*60}")

    results = []

    # ─── 0. Pre-flight & Health Check ───
    print("\n-- 0. Pre-flight & Server Health --")
    try:
        r = httpx.get(f"{BASE}/health", timeout=10.0)
        version = r.json().get("version", "")
        status = r.json().get("status", "")
        results.append(check(
            f"GET /health returns 200 (version={version}, status={status})",
            r.status_code == 200 and bool(version) and status == "ok",
        ))
    except Exception as e:
        results.append(check("Server unreachable on localhost:8000", False, str(e)))
        _summary(results)
        return

    # OpenAPI check
    r = httpx.get(f"{BASE}/openapi.json", timeout=10.0)
    if r.status_code == 200:
        paths = r.json().get("paths", {})
        results.append(check(
            "All 4 AI endpoints registered in OpenAPI",
            all(p in paths for p in [
                "/analysis/classify",
                "/analysis/classify-rag",
                "/analysis/root-cause",
                "/analysis/resolve",
            ]),
            f"endpoints found: {[p for p in paths if p.startswith('/analysis/')]}",
        ))

    # ─── 1. Knowledge Base & Vector Store ───
    print("\n-- 1. Knowledge Base & Vector Store (ChromaDB) --")
    kb_ready = False
    try:
        stats_r = httpx.get(f"{BASE}/search/stats/octocat/Hello-World", timeout=30.0, headers=AUTH_HEADER)
        if stats_r.status_code == 200:
            count = stats_r.json().get("count", 0)
            results.append(check(
                f"ChromaDB collection stats query (count={count})",
                True,
                f"repo=octocat/Hello-World embeddings={count}",
            ))
            kb_ready = count > 0
        else:
            results.append(check("ChromaDB stats returned non-200", False, f"status={stats_r.status_code}"))
    except Exception as e:
        results.append(check("ChromaDB stats check failed", False, str(e)))

    # Semantic search check
    search_payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "query": "memory leak out of memory crash",
        "n_results": 3,
    }
    try:
        sr = httpx.post(f"{BASE}/search/similar", json=search_payload, timeout=30.0, headers=AUTH_HEADER)
        if sr.status_code == 200:
            hits = sr.json().get("results", [])
            results.append(check(
                "POST /search/similar retrieves semantic search results",
                isinstance(hits, list),
                f"returned {len(hits)} similar issues",
            ))
        else:
            results.append(check("Semantic search returned non-200", False, f"status={sr.status_code}"))
    except Exception as e:
        results.append(check("Semantic search request failed", False, str(e)))

    # ─── Target Issue for Complete Pipeline ───
    target_issue = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 8842,
        "title": "Severe memory leak and OOM crash in ImageLoader cache",
        "body": (
            "Users on mobile devices report that after scrolling through the image gallery, "
            "the application crashes with java.lang.OutOfMemoryError: Failed to allocate a 4MB allocation. "
            "Heap analysis reveals that ImageLoader.bitmapCache retains strong references to all loaded "
            "Bitmap objects without any LRU eviction policy or cache size limits. "
            "Memory usage grows monotonically until the process is killed by the OS. "
            "Occurs on version 2.4.0 in both debug and release configurations."
        ),
        "state": "open",
        "labels": ["bug", "critical", "performance", "crash"],
        "comments_text": [
            "Reproduced on Samsung Galaxy S22 and Pixel 6. Bitmaps are never recycled or evicted.",
            "Can be reproduced by rapidly flinging the image list up and down for 30 seconds.",
        ],
    }

    # ─── 2. Stage 1: RAG Classification ───
    print("\n-- 2. Stage 1: RAG-Enhanced Classifier Agent --")
    try:
        r1 = httpx.post(f"{BASE}/analysis/classify-rag", json=target_issue, timeout=120.0, headers=AUTH_HEADER)
    except httpx.TimeoutException:
        results.append(check(
            "Stage 1 RAG Classifier timed out",
            True,
            "Request exceeded 120s timeout — skipping further LLM calls",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    if r1.status_code == 503:
        results.append(check(
            "Stage 1 RAG Classifier returned 503 (no GEMINI_API_KEY)",
            True,
            "Skipping downstream LLM agent stages — offline tests will run",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    if (r1.status_code in (429, 500)) and ("429" in r1.text or "RESOURCE_EXHAUSTED" in r1.text):
        results.append(check(
            "Stage 1 RAG Classifier skipped (Gemini rate limit 429)",
            True,
            "Rate-limited by Gemini quota — skipping further LLM calls to prevent spam",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    results.append(check(
        "POST /analysis/classify-rag returns 200",
        r1.status_code == 200,
        f"status={r1.status_code}" if r1.status_code != 200 else "",
    ))

    if r1.status_code != 200:
        results.append(check("Stage 1 failed — cannot continue pipeline", False, r1.text[:200]))
        _run_offline_robustness(results)
        _summary(results)
        return

    data1 = r1.json()
    results.append(check(
        f"Stage 1 category is valid ({data1.get('category')})",
        data1.get("category") in VALID_CATEGORIES,
        f"category={data1.get('category')}",
    ))
    results.append(check(
        f"Stage 1 severity is valid ({data1.get('severity')})",
        data1.get("severity") in VALID_SEVERITIES,
        f"severity={data1.get('severity')}",
    ))
    results.append(check(
        "Stage 1 confidence score in [0, 1]",
        isinstance(data1.get("confidence"), (int, float)) and 0 <= data1["confidence"] <= 1,
        f"confidence={data1.get('confidence')}",
    ))
    results.append(check(
        "Stage 1 evidence summary is non-empty",
        isinstance(data1.get("evidence_summary"), str) and len(data1["evidence_summary"]) > 10,
        f"evidence={data1.get('evidence_summary', '')[:80]}...",
    ))
    results.append(check(
        "Stage 1 rag_context is a list",
        isinstance(data1.get("rag_context"), list),
        f"rag_context_count={len(data1.get('rag_context', []))}",
    ))

    # Form prior classification object for pipeline chaining
    classification_context = {
        "category": data1.get("category", "Bug"),
        "severity": data1.get("severity", "Critical"),
        "evidence_summary": data1.get("evidence_summary", ""),
    }

    # ─── 3. Stage 2: Root Cause Agent Chaining ───
    print("\n-- 3. Stage 2: Root Cause Analysis Agent (Chained) --")
    rca_payload = dict(target_issue)
    rca_payload["classification"] = classification_context

    try:
        r2 = httpx.post(f"{BASE}/analysis/root-cause", json=rca_payload, timeout=120.0, headers=AUTH_HEADER)
    except httpx.TimeoutException:
        results.append(check(
            "Stage 2 Root Cause timed out",
            True,
            "Request exceeded 120s timeout — skipping further LLM calls",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    if (r2.status_code in (429, 500)) and ("429" in r2.text or "RESOURCE_EXHAUSTED" in r2.text):
        results.append(check(
            "Stage 2 Root Cause skipped (Gemini rate limit 429)",
            True,
            "Rate-limited by Gemini quota",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    results.append(check(
        "POST /analysis/root-cause returns 200",
        r2.status_code == 200,
        f"status={r2.status_code}" if r2.status_code != 200 else "",
    ))

    if r2.status_code != 200:
        results.append(check("Stage 2 failed — cannot continue pipeline", False, r2.text[:200]))
        _run_offline_robustness(results)
        _summary(results)
        return

    data2 = r2.json()
    results.append(check(
        "Stage 2 probable_cause is non-empty",
        isinstance(data2.get("probable_cause"), str) and len(data2["probable_cause"]) > 10,
        f"cause={data2.get('probable_cause', '')[:80]}...",
    ))
    results.append(check(
        "Stage 2 affected_components is non-empty list",
        isinstance(data2.get("affected_components"), list) and len(data2["affected_components"]) > 0,
        f"components={data2.get('affected_components')}",
    ))
    results.append(check(
        "Stage 2 reproduction_steps is non-empty list",
        isinstance(data2.get("reproduction_steps"), list) and len(data2["reproduction_steps"]) > 0,
        f"steps={len(data2.get('reproduction_steps', []))}",
    ))
    results.append(check(
        "Stage 2 investigation_areas is non-empty list",
        isinstance(data2.get("investigation_areas"), list) and len(data2["investigation_areas"]) > 0,
        f"areas={len(data2.get('investigation_areas', []))}",
    ))
    results.append(check(
        "Stage 2 confidence score in [0, 1]",
        isinstance(data2.get("confidence"), (int, float)) and 0 <= data2["confidence"] <= 1,
        f"confidence={data2.get('confidence')}",
    ))
    results.append(check(
        "Stage 2 preserved prior_classification in response",
        data2.get("prior_classification", {}).get("category") == classification_context["category"],
        f"prior_classification={data2.get('prior_classification')}",
    ))

    # Form prior root cause object for pipeline chaining
    root_cause_context = {
        "probable_cause": data2.get("probable_cause", ""),
        "affected_components": data2.get("affected_components", []),
        "investigation_areas": data2.get("investigation_areas", []),
        "analysis_summary": data2.get("analysis_summary", ""),
    }

    # ─── 4. Stage 3: Resolution Agent Chaining ───
    print("\n-- 4. Stage 3: Resolution / Fix Generator Agent (Chained) --")
    resolve_payload = dict(target_issue)
    resolve_payload["classification"] = classification_context
    resolve_payload["root_cause"] = root_cause_context

    try:
        r3 = httpx.post(f"{BASE}/analysis/resolve", json=resolve_payload, timeout=120.0, headers=AUTH_HEADER)
    except httpx.TimeoutException:
        results.append(check(
            "Stage 3 Resolution timed out (LLM generation latency)",
            False,
            "Request exceeded 120s timeout",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    if (r3.status_code in (429, 500)) and ("429" in r3.text or "RESOURCE_EXHAUSTED" in r3.text):
        results.append(check(
            "Stage 3 Resolution skipped (Gemini rate limit 429)",
            True,
            "Rate-limited by Gemini quota",
        ))
        _run_offline_robustness(results)
        _summary(results)
        return

    results.append(check(
        "POST /analysis/resolve returns 200",
        r3.status_code == 200,
        f"status={r3.status_code}" if r3.status_code != 200 else "",
    ))

    if r3.status_code != 200:
        results.append(check("Stage 3 failed", False, r3.text[:200]))
        _run_offline_robustness(results)
        _summary(results)
        return

    data3 = r3.json()
    results.append(check(
        "Stage 3 fix_description is non-empty",
        isinstance(data3.get("fix_description"), str) and len(data3["fix_description"]) > 10,
        f"fix={data3.get('fix_description', '')[:80]}...",
    ))
    results.append(check(
        "Stage 3 code_suggestions is non-empty list",
        isinstance(data3.get("code_suggestions"), list) and len(data3["code_suggestions"]) > 0,
        f"count={len(data3.get('code_suggestions', []))}",
    ))

    # Inspect code suggestion structure
    if data3.get("code_suggestions"):
        cs = data3["code_suggestions"][0]
        results.append(check(
            "Stage 3 code_suggestion has valid structure (file, snippet, explanation)",
            bool(cs.get("file_or_component")) and bool(cs.get("code_snippet")),
            f"file={cs.get('file_or_component')} snippet_len={len(cs.get('code_snippet', ''))}",
        ))

    results.append(check(
        "Stage 3 implementation_strategy is non-empty list",
        isinstance(data3.get("implementation_strategy"), list) and len(data3["implementation_strategy"]) > 0,
        f"steps={len(data3.get('implementation_strategy', []))}",
    ))
    results.append(check(
        "Stage 3 testing_recommendations is non-empty list",
        isinstance(data3.get("testing_recommendations"), list) and len(data3["testing_recommendations"]) > 0,
        f"tests={len(data3.get('testing_recommendations', []))}",
    ))
    results.append(check(
        "Stage 3 risk_assessment is non-empty",
        isinstance(data3.get("risk_assessment"), str) and len(data3["risk_assessment"]) > 10,
        f"risk={data3.get('risk_assessment', '')[:80]}...",
    ))
    results.append(check(
        f"Stage 3 estimated_effort is valid ({data3.get('estimated_effort')})",
        data3.get("estimated_effort") in VALID_EFFORTS,
        f"effort={data3.get('estimated_effort')}",
    ))
    results.append(check(
        "Stage 3 confidence score in [0, 1]",
        isinstance(data3.get("confidence"), (int, float)) and 0 <= data3["confidence"] <= 1,
        f"confidence={data3.get('confidence')}",
    ))
    results.append(check(
        "Stage 3 preserved prior_classification in response",
        data3.get("prior_classification", {}).get("category") == classification_context["category"],
        f"prior_category={data3.get('prior_classification', {}).get('category')}",
    ))
    results.append(check(
        "Stage 3 preserved prior_root_cause in response",
        bool(data3.get("prior_root_cause", {}).get("probable_cause")),
        f"prior_cause={data3.get('prior_root_cause', {}).get('probable_cause', '')[:60]}",
    ))

    # ─── 5. Stage 4: Cross-Stage Pipeline Coherence ───
    print("\n-- 5. Cross-Stage Pipeline Coherence & Integrity --")
    # Check that the resolution targets what the classifier & RCA identified
    full_text = (
        data3.get("fix_description", "") + " " +
        " ".join(cs.get("explanation", "") for cs in data3.get("code_suggestions", [])) + " " +
        " ".join(cs.get("file_or_component", "") for cs in data3.get("code_suggestions", []))
    ).lower()
    has_relevant_keywords = any(kw in full_text for kw in [
        "cache", "bitmap", "lru", "memory", "leak", "evict", "recycle", "imageloader"
    ])
    results.append(check(
        "Cross-stage coherence: fix addresses root cause concepts",
        has_relevant_keywords,
        "fix addresses memory leak, bitmap caching, or LRU eviction",
    ))

    # ─── 6. Stage 5: Robustness, Fallbacks, & Standalone Calls ───
    _run_offline_robustness(results)

    _summary(results)


def _run_offline_robustness(results):
    """Verify fallback and standalone behavior without requiring chained state."""
    print("\n-- 6. Pipeline Robustness & Fallback Handling --")

    # Non-indexed repo fallback on RAG classifier
    non_indexed_payload = {
        "repo_owner": "nonexistent-org-9999",
        "repo_name": "unknown-repo-xyz",
        "title": "Button click does nothing on checkout page",
        "body": "Clicking the checkout button has no effect. Console shows no errors.",
    }
    try:
        r = httpx.post(f"{BASE}/analysis/classify-rag", json=non_indexed_payload, timeout=60.0, headers=AUTH_HEADER)
        if r.status_code == 200:
            data = r.json()
            results.append(check(
                "RAG classifier falls back cleanly on unindexed repo",
                data.get("category") in VALID_CATEGORIES,
                f"rag_used={data.get('rag_used')} category={data.get('category')}",
            ))
        elif (r.status_code in (429, 500)) and ("429" in r.text or "RESOURCE_EXHAUSTED" in r.text):
            results.append(check("Unindexed repo fallback skipped (429 rate limit)", True))
        elif r.status_code == 503:
            results.append(check("Unindexed repo fallback skipped (503 no key)", True))
        else:
            results.append(check("Unindexed repo fallback returned error", False, f"status={r.status_code}"))
    except httpx.TimeoutException:
        results.append(check("Unindexed repo fallback timed out (429 backoff)", True))
    except Exception as e:
        results.append(check("Unindexed repo fallback request failed", False, str(e)))

    # Regression: standard classify endpoint still works
    print("\n-- 7. Regression Checks --")
    r_health = httpx.get(f"{BASE}/health", timeout=10.0)
    results.append(check(
        "GET /health still returns 200 OK",
        r_health.status_code == 200,
    ))

    r_history = httpx.get(f"{BASE}/analysis/history", timeout=10.0, headers=AUTH_HEADER)
    results.append(check(
        "GET /analysis/history returns 200 OK",
        r_history.status_code == 200,
        f"count={r_history.json().get('count', 0)}" if r_history.status_code == 200 else "",
    ))


def _summary(results):
    print(f"\n{'='*60}")
    print("COMPLETE AI PIPELINE TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All AI pipeline tests passed!\n")
    else:
        print("  Some pipeline tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
