"""
Automated tests for ChromaDB Semantic Search in BugSense Backend.

Tests:
1. Health check regression (v0.8.0).
2. Index a repo (populates both classifications and vectors).
3. POST /search/similar finds semantically relevant issues.
4. GET /search/stats returns collection statistics.
5. Similarity results contain expected fields.
6. Regression: existing endpoints still work.

Requires: FastAPI server running on localhost:8000 with GEMINI_API_KEY set.
"""

import sys
import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense ChromaDB Semantic Search")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    results.append(test(f"GET /health returns version {version}", r.status_code == 200))

    # --- 1. Index a repo to populate vectors ---
    print("\n-- Index Repository (populate vectors) --")
    index_payload = {
        "owner": "octocat",
        "repo": "Hello-World",
        "max_issues": 3,
    }
    print("  Indexing octocat/Hello-World (max_issues=3)...")
    r = httpx.post(f"{BASE}/repos/index", json=index_payload, timeout=120.0)

    if r.status_code == 503:
        detail = r.json().get("detail", "")
        results.append(test(
            "Indexing returns 503 (no API key)",
            "GEMINI_API_KEY" in detail,
            f"Detail: {detail[:80]}...",
        ))
        results.append(test("Search tests skipped (no API key)", True, "Expected"))
        _summary(results)
        return

    results.append(test("POST /repos/index returns 200", r.status_code == 200))

    if r.status_code != 200:
        print(f"    Unexpected: {r.status_code} {r.text[:300]}")
        _summary(results)
        return

    data = r.json()
    classified = data.get("summary", {}).get("classified", 0)
    results.append(test(
        f"Indexing classified {classified} issues",
        classified > 0,
    ))

    # --- 2. Vector store stats ---
    print("\n-- Vector Store Stats --")
    r = httpx.get(f"{BASE}/search/stats/octocat/Hello-World")
    results.append(test(
        "GET /search/stats/octocat/Hello-World returns 200",
        r.status_code == 200,
    ))

    if r.status_code == 200:
        stats = r.json()
        count = stats.get("count", 0)
        results.append(test(
            f"Vector collection has {count} embeddings",
            count > 0,
            f"collection={stats.get('collection_name')}, model={stats.get('embedding_model')}",
        ))
    else:
        results.append(test("Stats unavailable", False, f"status={r.status_code}"))

    # --- 3. Semantic search ---
    print("\n-- Semantic Search --")
    search_payload = {
        "query": "test issue",
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "n_results": 3,
    }
    r = httpx.post(f"{BASE}/search/similar", json=search_payload, timeout=30.0)
    results.append(test(
        "POST /search/similar returns 200",
        r.status_code == 200,
    ))

    if r.status_code == 200:
        search_data = r.json()
        search_results = search_data.get("results", [])
        results.append(test(
            f"Search returned {len(search_results)} results",
            len(search_results) > 0,
        ))

        if search_results:
            first = search_results[0]
            results.append(test(
                "Result has 'id' field",
                "id" in first,
                f"id={first.get('id', '')}",
            ))
            results.append(test(
                "Result has 'similarity' score",
                "similarity" in first and isinstance(first["similarity"], (int, float)),
                f"similarity={first.get('similarity')}",
            ))
            results.append(test(
                "Result has 'metadata' with repo info",
                isinstance(first.get("metadata"), dict)
                and first["metadata"].get("repo_owner") == "octocat",
                f"metadata={first.get('metadata', {})}",
            ))
            results.append(test(
                "Result has 'document' text",
                isinstance(first.get("document"), str) and len(first["document"]) > 0,
                f"document={first.get('document', '')[:60]}...",
            ))
    else:
        results.append(test("Search results unavailable", False))

    # --- 4. Different query ---
    print("\n-- Distinct Query --")
    search_payload2 = {
        "query": "crash bug error",
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "n_results": 2,
    }
    r = httpx.post(f"{BASE}/search/similar", json=search_payload2, timeout=30.0)
    results.append(test(
        "Search with 'crash bug error' returns 200",
        r.status_code == 200,
    ))

    # --- 5. Search on non-indexed repo ---
    print("\n-- Edge Cases --")
    search_empty = {
        "query": "test",
        "repo_owner": "nonexistent",
        "repo_name": "repo",
        "n_results": 3,
    }
    r = httpx.post(f"{BASE}/search/similar", json=search_empty, timeout=30.0)
    results.append(test(
        "Search on non-indexed repo returns 200 with 0 results",
        r.status_code == 200 and r.json().get("count", -1) == 0,
    ))

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("SEARCH TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All search tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
