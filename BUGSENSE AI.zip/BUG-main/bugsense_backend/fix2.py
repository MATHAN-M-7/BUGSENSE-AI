import re
with open('../bugsense_ai/lib/services/api_service.dart', 'r', encoding='utf-8') as f:
    text = f.read()

text = re.sub(
    r"throw Exception\('AI service unavailable [^']+GEMINI_API_KEY may not be set\.'\);",
    "final detail = _extractDetail(response);\n      throw Exception('AI service unavailable: $detail');",
    text
)

with open('../bugsense_ai/lib/services/api_service.dart', 'w', encoding='utf-8') as f:
    f.write(text)
