"""
Test Suite for Production Backend Hardening Phase 1

Covers:
A. Review verdict persistence
B. Review verdict tenant isolation
C. Webhook secret required in production
D. Webhook test endpoint unavailable in production
E. Webhook events tenant isolation
F. CORS production configuration
G. Protected GitHub routes cannot fall back to developer PAT
"""

import hashlib
import hmac
import json
import os
import sys
import threading
import time
from typing import Any
from unittest.mock import patch, MagicMock

from cryptography.fernet import Fernet
from fastapi import HTTPException
from fastapi.testclient import TestClient

# Ensure test session encryption key
TEST_KEY = Fernet.generate_key().decode()
os.environ["SESSION_ENCRYPTION_KEY"] = TEST_KEY
os.environ["ENVIRONMENT"] = "development"

# Ensure optional external services do not prevent importing main in test runner
for mod in ["firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore"]:
    if mod not in sys.modules:
        try:
            __import__(mod)
        except ImportError:
            sys.modules[mod] = MagicMock()

from config import (
    get_environment,
    is_production,
    get_cors_allowed_origins,
    get_github_webhook_secret,
)
from services import session_store
from services.auth_guard import require_auth, verify_repo_access, AuthenticatedUser
from services import github_service
from services.redis_client import set_redis_client, reset_redis_client
import main
from routers import analysis, webhooks, github


class MockRedis:
    def __init__(self):
        self.store = {}

    def set(self, name: str, value: str, ex: int | None = None):
        self.store[name] = (value, time.time() + (ex or 0))
        return True

    def getdel(self, name: str):
        if name not in self.store:
            return None
        val, exp = self.store.pop(name)
        if exp and time.time() > exp:
            return None
        return val

    def get(self, name: str):
        if name not in self.store:
            return None
        val, exp = self.store.get(name)
        if exp and time.time() > exp:
            return None
        return val


class MockPostgresCursor:
    def __init__(self, db: dict, lock: threading.Lock):
        self.db = db
        self.lock = lock
        self.rowcount = 0
        self._last_result = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def execute(self, query: str, params: tuple = ()):
        query_upper = query.strip().upper()
        with self.lock:
            if query_upper.startswith("CREATE TABLE") or query_upper.startswith("CREATE INDEX"):
                self.rowcount = 0
                return

            if query_upper.startswith("INSERT INTO SESSIONS"):
                session_id = params[0]
                self.db["sessions"][session_id] = {
                    "session_id": params[0],
                    "github_user_id": params[1],
                    "github_login": params[2],
                    "github_avatar_url": params[3],
                    "github_name": params[4],
                    "github_access_token": params[5],
                    "created_at": params[6],
                    "expires_at": params[7],
                }
                self.rowcount = 1

            elif query_upper.startswith("SELECT") and "FROM SESSIONS" in query_upper:
                session_id = params[0]
                row = self.db["sessions"].get(session_id)
                self._last_result = row

            elif query_upper.startswith("DELETE FROM SESSIONS WHERE SESSION_ID"):
                session_id = params[0]
                if session_id in self.db["sessions"]:
                    del self.db["sessions"][session_id]
                    self.rowcount = 1
                else:
                    self.rowcount = 0

            elif query_upper.startswith("INSERT INTO REVIEW_VERDICTS"):
                rec = {
                    "github_user_id": params[0],
                    "github_login": params[1],
                    "repo_owner": params[2],
                    "repo_name": params[3],
                    "issue_number": params[4],
                    "verdict": params[5],
                    "reviewer": params[6],
                    "rejection_reason": params[7],
                    "notes": params[8],
                    "has_edited_resolution": params[9],
                    "edited_resolution": params[10],
                    "recorded_at": params[11],
                }
                self.db["review_verdicts"].append(rec)
                self.rowcount = 1

            elif query_upper.startswith("SELECT") and "FROM REVIEW_VERDICTS" in query_upper:
                uid = params[0]
                results = [
                    dict(r) for r in self.db["review_verdicts"]
                    if r["github_user_id"] == uid
                ]
                # Filter optional params
                p_idx = 1
                if "LOWER(REPO_OWNER) =" in query_upper:
                    owner = params[p_idx].lower()
                    results = [r for r in results if r["repo_owner"].lower() == owner]
                    p_idx += 1
                if "LOWER(REPO_NAME) =" in query_upper:
                    name = params[p_idx].lower()
                    results = [r for r in results if r["repo_name"].lower() == name]
                    p_idx += 1
                if "ISSUE_NUMBER =" in query_upper:
                    num = params[p_idx]
                    results = [r for r in results if r["issue_number"] == num]
                    p_idx += 1
                self._last_result = results

            elif query_upper.startswith("INSERT INTO WEBHOOK_EVENTS"):
                rec = {
                    "event_type": params[0],
                    "action": params[1],
                    "delivery_id": params[2],
                    "repo_full_name": params[3],
                    "sender_id": params[4],
                    "sender_login": params[5],
                    "summary": params[6],
                    "received_at": params[7],
                }
                self.db["webhook_events"].append(rec)
                self.rowcount = 1

            elif query_upper.startswith("SELECT") and "FROM WEBHOOK_EVENTS" in query_upper:
                if "LOWER(REPO_FULL_NAME) =" in query_upper:
                    repo_full = params[0].lower()
                    limit = params[1]
                    res = [r for r in self.db["webhook_events"] if r["repo_full_name"].lower() == repo_full]
                else:
                    sender = params[0]
                    limit = params[1]
                    res = [r for r in self.db["webhook_events"] if r["sender_id"] == sender]
                res.reverse()
                self._last_result = res[:limit]

            else:
                self.rowcount = 0
                self._last_result = None

    def fetchone(self):
        if isinstance(self._last_result, list):
            return self._last_result[0] if self._last_result else None
        return self._last_result

    def fetchall(self):
        if isinstance(self._last_result, list):
            return self._last_result
        return [self._last_result] if self._last_result else []


class MockPostgresConn:
    def __init__(self, db: dict, lock: threading.Lock):
        self.db = db
        self.lock = lock

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def cursor(self):
        return MockPostgresCursor(self.db, self.lock)


class MockPostgresPool:
    def __init__(self):
        self.db = {
            "sessions": {},
            "review_verdicts": [],
            "webhook_events": [],
        }
        self.lock = threading.Lock()
        self.closed = False

    def connection(self):
        if self.closed:
            raise RuntimeError("Pool is closed")
        return MockPostgresConn(self.db, self.lock)

    def close(self):
        self.closed = True


def setup_test_environment():
    """Setup shared in-memory mock pool and redis client."""
    mock_pool = MockPostgresPool()
    session_store.set_db_pool(mock_pool)
    mock_redis = MockRedis()
    set_redis_client(mock_redis)
    return mock_pool, mock_redis


def test_section_a_review_verdict_persistence(mock_pool):
    print("\n--- Test A: Review verdict persistence ---")
    user_id = 9001
    login = "testdev_a"

    # 1. Save verdict directly via session_store
    verdict_record = session_store.save_review_verdict(
        github_user_id=user_id,
        github_login=login,
        repo_owner="octocat",
        repo_name="hello-world",
        issue_number=101,
        verdict="accept",
        reviewer="human_lead",
        notes="Resolution approved for PR generation.",
    )
    assert verdict_record["verdict"] == "accept"
    assert verdict_record["github_user_id"] == user_id
    assert verdict_record["issue_number"] == 101

    # 2. Retrieve verdicts via get_review_verdicts
    verdicts = session_store.get_review_verdicts(
        github_user_id=user_id,
        repo_owner="octocat",
        repo_name="hello-world",
        issue_number=101,
    )
    assert len(verdicts) >= 1
    assert verdicts[-1]["verdict"] == "accept"
    assert verdicts[-1]["reviewer"] == "human_lead"

    # 3. Retrieve latest verdict
    latest = session_store.get_latest_review_verdict(
        repo_owner="octocat",
        repo_name="hello-world",
        issue_number=101,
        github_user_id=user_id,
    )
    assert latest is not None
    assert latest["verdict"] == "accept"
    print("  [PASS] Human review verdict successfully persisted and retrieved via PostgreSQL store")


def test_section_b_review_verdict_tenant_isolation(mock_pool):
    print("\n--- Test B: Review verdict tenant isolation ---")
    user1_id = 1001
    user2_id = 2002

    # User 1 accepts issue 50
    session_store.save_review_verdict(
        github_user_id=user1_id,
        github_login="alice",
        repo_owner="facebook",
        repo_name="react",
        issue_number=50,
        verdict="accept",
        notes="Alice approved",
    )

    # User 2 rejects issue 50
    session_store.save_review_verdict(
        github_user_id=user2_id,
        github_login="bob",
        repo_owner="facebook",
        repo_name="react",
        issue_number=50,
        verdict="reject",
        rejection_reason="Needs rework",
        notes="Bob rejected",
    )

    # User 1 query: must only see Alice's verdict
    u1_verdicts = session_store.get_review_verdicts(github_user_id=user1_id)
    assert all(v["github_user_id"] == user1_id for v in u1_verdicts)
    assert any(v["verdict"] == "accept" for v in u1_verdicts)
    assert not any(v["verdict"] == "reject" for v in u1_verdicts)

    # User 2 query: must only see Bob's verdict
    u2_verdicts = session_store.get_review_verdicts(github_user_id=user2_id)
    assert all(v["github_user_id"] == user2_id for v in u2_verdicts)
    assert any(v["verdict"] == "reject" for v in u2_verdicts)
    assert not any(v["verdict"] == "accept" for v in u2_verdicts)

    # Latest verdict scoped per user
    latest_u1 = session_store.get_latest_review_verdict(
        repo_owner="facebook",
        repo_name="react",
        issue_number=50,
        github_user_id=user1_id,
    )
    latest_u2 = session_store.get_latest_review_verdict(
        repo_owner="facebook",
        repo_name="react",
        issue_number=50,
        github_user_id=user2_id,
    )
    assert latest_u1["verdict"] == "accept"
    assert latest_u2["verdict"] == "reject"
    print("  [PASS] Review verdicts strictly isolated across tenants: user 1 cannot view user 2 verdicts")


def test_section_c_webhook_secret_production():
    print("\n--- Test C: Webhook secret required in production ---")
    client = TestClient(main.app)

    # 1. In production without GITHUB_WEBHOOK_SECRET -> raises HTTP 500
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_WEBHOOK_SECRET": ""}):
        res = client.post(
            "/webhooks/github",
            content=json.dumps({"action": "opened"}),
            headers={"X-GitHub-Event": "issues"},
        )
        assert res.status_code == 500
        assert "GITHUB_WEBHOOK_SECRET must be configured in production" in res.json()["detail"]
        print("  [PASS] Missing GITHUB_WEBHOOK_SECRET in production returns HTTP 500")

    # 2. In production with secret but missing X-Hub-Signature-256 header -> raises HTTP 403
    test_secret = "prod_super_secret_webhook_key_12345"
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_WEBHOOK_SECRET": test_secret}):
        payload_bytes = json.dumps({"action": "opened", "repository": {"full_name": "acme/repo"}}).encode()
        res = client.post(
            "/webhooks/github",
            content=payload_bytes,
            headers={"X-GitHub-Event": "issues"},
        )
        assert res.status_code == 403
        assert "Missing X-Hub-Signature-256 header" in res.json()["detail"]
        print("  [PASS] Missing signature header in production returns HTTP 403")

    # 3. In production with secret and invalid signature -> raises HTTP 403
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_WEBHOOK_SECRET": test_secret}):
        res = client.post(
            "/webhooks/github",
            content=payload_bytes,
            headers={
                "X-GitHub-Event": "issues",
                "X-Hub-Signature-256": "sha256=0000000000000000000000000000000000000000000000000000000000000000",
            },
        )
        assert res.status_code == 403
        assert "Invalid webhook signature" in res.json()["detail"]
        print("  [PASS] Invalid signature in production returns HTTP 403")

    # 4. In production with valid signature -> returns HTTP 200
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_WEBHOOK_SECRET": test_secret}):
        valid_hmac = hmac.new(test_secret.encode(), payload_bytes, hashlib.sha256).hexdigest()
        res = client.post(
            "/webhooks/github",
            content=payload_bytes,
            headers={
                "X-GitHub-Event": "issues",
                "X-Hub-Signature-256": f"sha256={valid_hmac}",
                "X-GitHub-Delivery": "test-delivery-id-001",
            },
        )
        assert res.status_code == 200
        assert res.json()["status"] == "received"
        print("  [PASS] Valid HMAC-SHA256 signature in production accepted with HTTP 200")


def test_section_d_webhook_test_endpoint_production():
    print("\n--- Test D: Webhook test endpoint unavailable in production ---")
    client = TestClient(main.app)

    # 1. In production -> strictly disabled (HTTP 403)
    with patch.dict(os.environ, {"ENVIRONMENT": "production"}):
        res = client.post("/webhooks/github/test", json={"event": "issues", "payload": {}})
        assert res.status_code == 403
        assert "disabled in production" in res.json()["detail"]
        print("  [PASS] /webhooks/github/test returns HTTP 403 in production")

    # 2. In development without secret -> enabled (HTTP 200)
    with patch.dict(os.environ, {"ENVIRONMENT": "development", "GITHUB_WEBHOOK_SECRET": ""}):
        res = client.post("/webhooks/github/test", json={"event": "ping", "payload": {}})
        assert res.status_code == 200
        assert res.json()["status"] == "simulated"
        print("  [PASS] /webhooks/github/test accessible in development without secret")


def test_section_e_webhook_events_tenant_isolation(mock_pool):
    print("\n--- Test E: Webhook events tenant isolation ---")
    client = TestClient(main.app)

    # Create sessions for Alice (user 1001) and Bob (user 2002)
    s1 = session_store.create_session(
        github_user_id=1001,
        github_login="alice",
        github_access_token="gho_alice_token_111",
    )
    s2 = session_store.create_session(
        github_user_id=2002,
        github_login="bob",
        github_access_token="gho_bob_token_222",
    )

    # Save events for Alice and Bob
    session_store.save_webhook_event(
        event_type="issues",
        action="opened",
        repo_full_name="alice/repo1",
        sender_id=1001,
        sender_login="alice",
        summary={"id": 1, "title": "Alice's Issue"},
    )
    session_store.save_webhook_event(
        event_type="pull_request",
        action="opened",
        repo_full_name="bob/repo2",
        sender_id=2002,
        sender_login="bob",
        summary={"id": 2, "title": "Bob's PR"},
    )

    # Alice queries events without repo param -> sees only Alice's events
    res_alice = client.get(
        "/webhooks/github/events",
        headers={"Authorization": f"Bearer {s1}"},
    )
    assert res_alice.status_code == 200
    events_alice = res_alice.json()["events"]
    assert all(e["sender_id"] == 1001 for e in events_alice)
    assert not any(e["sender_id"] == 2002 for e in events_alice)

    # Bob queries events without repo param -> sees only Bob's events
    res_bob = client.get(
        "/webhooks/github/events",
        headers={"Authorization": f"Bearer {s2}"},
    )
    assert res_bob.status_code == 200
    events_bob = res_bob.json()["events"]
    assert all(e["sender_id"] == 2002 for e in events_bob)
    assert not any(e["sender_id"] == 1001 for e in events_bob)

    # Alice queries Bob's repo with repo parameter:
    # verify_repo_access will check with GitHub API using Alice's token and reject access
    with patch("routers.webhooks.verify_repo_access", side_effect=HTTPException(status_code=403, detail="You do not have access to repository bob/repo2.")):
        res_unauthorized = client.get(
            "/webhooks/github/events?repo=bob/repo2",
            headers={"Authorization": f"Bearer {s1}"},
        )
        assert res_unauthorized.status_code == 403
        assert "You do not have access to repository" in res_unauthorized.json()["detail"]

    print("  [PASS] Webhook events strictly scoped to caller sender_id or verified repo access")


def test_section_f_cors_configuration():
    print("\n--- Test F: CORS production configuration ---")

    # 1. In development -> includes localhost and 127.0.0.1
    with patch.dict(os.environ, {"ENVIRONMENT": "development"}, clear=False):
        dev_origins = get_cors_allowed_origins()
        assert "http://localhost:3000" in dev_origins
        assert "http://127.0.0.1:8000" in dev_origins
        print("  [PASS] Development CORS retains localhost and 127.0.0.1 origins")

    # 2. In production with no CORS_ALLOWED_ORIGINS specified -> defaults to secure bugsense.ai domains
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "CORS_ALLOWED_ORIGINS": ""}, clear=False):
        prod_origins = get_cors_allowed_origins()
        assert "*" not in prod_origins
        assert "https://bugsense.ai" in prod_origins
        assert "https://app.bugsense.ai" in prod_origins
        assert all(o.startswith("https://") for o in prod_origins)
        print("  [PASS] Production CORS defaults to HTTPS-only BugSense origins with no wildcards")

    # 3. In production with explicit CORS_ALLOWED_ORIGINS
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "CORS_ALLOWED_ORIGINS": "https://portal.bugsense.ai,https://admin.bugsense.ai"}):
        custom_origins = get_cors_allowed_origins()
        assert custom_origins == ["https://portal.bugsense.ai", "https://admin.bugsense.ai"]
        assert "*" not in custom_origins
        print("  [PASS] Production CORS enforces explicit HTTPS origins and excludes wildcards")

    # 4. In production with insecure or wildcard origin -> filtered out safely
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "CORS_ALLOWED_ORIGINS": "*,http://insecure.site,https://secure.site"}):
        filtered_origins = get_cors_allowed_origins()
        assert "*" not in filtered_origins
        assert "http://insecure.site" not in filtered_origins
        assert "https://secure.site" in filtered_origins
        print("  [PASS] Production CORS rejects wildcard '*' and insecure HTTP origins")


def test_section_g_pat_fallback_prevention():
    print("\n--- Test G: Protected GitHub routes cannot fall back to developer PAT ---")

    # 1. In production, calling _headers() without token raises RuntimeError
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_TOKEN": "ghp_dev_pat_token"}):
        try:
            github_service._headers(token=None)
            assert False, "Should have raised RuntimeError in production"
        except RuntimeError as e:
            assert "Missing user GitHub authorization token in production" in str(e)
            assert "Developer PAT fallback is strictly disabled" in str(e)
            print("  [PASS] github_service._headers(token=None) raises RuntimeError in production")

    # 2. In development, calling _headers() without token uses developer PAT
    with patch.dict(os.environ, {"ENVIRONMENT": "development", "GITHUB_TOKEN": "ghp_dev_pat_token"}):
        dev_headers = github_service._headers(token=None)
        assert dev_headers["Authorization"] == "Bearer ghp_dev_pat_token"
        print("  [PASS] Local development allows developer PAT fallback for dev/maintenance")

    # 3. User token is always respected regardless of environment
    with patch.dict(os.environ, {"ENVIRONMENT": "production", "GITHUB_TOKEN": "ghp_dev_pat_token"}):
        user_headers = github_service._headers(token="gho_user_actual_token")
        assert user_headers["Authorization"] == "Bearer gho_user_actual_token"
        print("  [PASS] User token propagated accurately in production")


def run_all_tests():
    print("==================================================")
    print("BUGSENSE AI — PRODUCTION HARDENING PHASE 1 TESTS")
    print("==================================================")
    mock_pool, mock_redis = setup_test_environment()

    test_section_a_review_verdict_persistence(mock_pool)
    test_section_b_review_verdict_tenant_isolation(mock_pool)
    test_section_c_webhook_secret_production()
    test_section_d_webhook_test_endpoint_production()
    test_section_e_webhook_events_tenant_isolation(mock_pool)
    test_section_f_cors_configuration()
    test_section_g_pat_fallback_prevention()

    print("\n==================================================")
    print("ALL PRODUCTION HARDENING TESTS PASSED SUCCESSFULLY!")
    print("==================================================")


if __name__ == "__main__":
    run_all_tests()
