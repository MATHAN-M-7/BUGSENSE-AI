"""
Comprehensive test suite for durable PostgreSQL-backed session store with token encryption.

Covers Step 21 Tests:
A. Session creation
B. Session retrieval
C. Session expiration
D. Session deletion
E. Invalid session
F. Encrypted token round-trip
G. Database contains ciphertext, not plaintext
H. Wrong encryption key fails safely
I. 50 concurrent get_session operations
J. Multi-user isolation
K. Logout returns HTTP 401 on subsequent request
L. require_auth regression
M. verify_repo_access regression
N. OAuth callback creates session
O. Redis handoff still works
P. Redis OAuth state still works
Q. Existing tenant isolation
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import os
import threading
import time
from unittest.mock import patch, MagicMock

from cryptography.fernet import Fernet
from fastapi import HTTPException
import httpx
import pytest

# Generate test keys
TEST_KEY_1 = Fernet.generate_key().decode()
TEST_KEY_2 = Fernet.generate_key().decode()
os.environ["SESSION_ENCRYPTION_KEY"] = TEST_KEY_1

from services import session_store
from services.redis_client import set_redis_client, reset_redis_client
from services.auth_guard import require_auth, verify_repo_access, user_scoped_collection_name, AuthenticatedUser
from routers import auth


class MockRedis:
    def __init__(self):
        self.store = {}
    def set(self, name: str, value: str, ex: int | None = None):
        self.store[name] = (value, time.time() + (ex or 0))
        return True
    def getdel(self, name: str):
        if name not in self.store:
            return None
        val, exp = self.store.pop(name)
        if exp and time.time() > exp:
            return None
        return val


class MockPostgresCursor:
    def __init__(self, db: dict, lock: threading.Lock):
        self.db = db
        self.lock = lock
        self.rowcount = 0
        self._last_result = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def execute(self, query: str, params: tuple = ()):
        query_upper = query.strip().upper()
        with self.lock:
            if query_upper.startswith("CREATE TABLE") or query_upper.startswith("CREATE INDEX"):
                self.rowcount = 0
                return

            if query_upper.startswith("INSERT INTO SESSIONS"):
                # params: (session_id, github_user_id, github_login, github_avatar_url, github_name, encrypted_token, now, expires)
                session_id = params[0]
                self.db[session_id] = {
                    "session_id": params[0],
                    "github_user_id": params[1],
                    "github_login": params[2],
                    "github_avatar_url": params[3],
                    "github_name": params[4],
                    "github_access_token": params[5],
                    "created_at": params[6],
                    "expires_at": params[7],
                }
                self.rowcount = 1

            elif query_upper.startswith("SELECT"):
                # WHERE session_id = %s
                session_id = params[0]
                row = self.db.get(session_id)
                self._last_result = dict(row) if row else None
                self.rowcount = 1 if row else 0

            elif "WHERE SESSION_ID =" in query_upper:
                # DELETE FROM sessions WHERE session_id = %s
                session_id = params[0]
                if session_id in self.db:
                    del self.db[session_id]
                    self.rowcount = 1
                else:
                    self.rowcount = 0

            elif "WHERE EXPIRES_AT <" in query_upper:
                cutoff = params[0]
                to_delete = [
                    sid for sid, r in self.db.items()
                    if r["expires_at"] < cutoff
                ]
                for sid in to_delete:
                    del self.db[sid]
                self.rowcount = len(to_delete)

    def fetchone(self):
        return self._last_result


class MockPostgresConnection:
    def __init__(self, db: dict, lock: threading.Lock):
        self.db = db
        self.lock = lock

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

    def cursor(self):
        return MockPostgresCursor(self.db, self.lock)


class MockPostgresPool:
    def __init__(self):
        self.db = {}
        self.lock = threading.Lock()

    def connection(self):
        return MockPostgresConnection(self.db, self.lock)

    def close(self):
        pass


def run_all_tests():
    print("==================================================")
    print("STEP 21 — DURABLE POSTGRESQL SESSION STORE TESTS")
    print("==================================================")

    # Setup mocks
    mock_pool = MockPostgresPool()
    session_store.set_db_pool(mock_pool)

    mock_redis = MockRedis()
    set_redis_client(mock_redis)

    os.environ["SESSION_ENCRYPTION_KEY"] = TEST_KEY_1

    # ──────────────────────────────────────────────
    # Test A: Session creation
    # ──────────────────────────────────────────────
    print("\n--- Test A: Session creation ---")
    session_id_a = session_store.create_session(
        github_user_id=123456,
        github_login="developer_a",
        github_access_token="gho_secret_token_123",
        github_name="Developer A",
        github_avatar_url="https://example.com/avatar_a.png",
    )
    assert len(session_id_a) >= 48
    assert session_id_a in mock_pool.db
    print(f"  [PASS] Session created with ID: {session_id_a[:16]}... in PostgreSQL table")

    # ──────────────────────────────────────────────
    # Test B: Session retrieval
    # ──────────────────────────────────────────────
    print("\n--- Test B: Session retrieval ---")
    retrieved_a = session_store.get_session(session_id_a)
    assert retrieved_a is not None
    assert retrieved_a["github_user_id"] == 123456
    assert retrieved_a["github_login"] == "developer_a"
    assert retrieved_a["github_access_token"] == "gho_secret_token_123"
    assert retrieved_a["github_name"] == "Developer A"
    assert isinstance(retrieved_a["created_at"], str)
    assert isinstance(retrieved_a["expires_at"], str)
    print("  [PASS] Session retrieved and token successfully decrypted in memory")

    # ──────────────────────────────────────────────
    # Test C: Session expiration
    # ──────────────────────────────────────────────
    print("\n--- Test C: Session expiration ---")
    session_id_exp = session_store.create_session(
        github_user_id=999999,
        github_login="expiring_user",
        github_access_token="gho_expiring_token",
        ttl_seconds=-10,  # Already expired
    )
    exp_res = session_store.get_session(session_id_exp)
    assert exp_res is None
    # Verify row was deleted from database
    assert session_id_exp not in mock_pool.db
    print("  [PASS] Expired session rejected and purged from database on retrieval")

    # ──────────────────────────────────────────────
    # Test D: Session deletion
    # ──────────────────────────────────────────────
    print("\n--- Test D: Session deletion (logout) ---")
    session_id_del = session_store.create_session(
        github_user_id=888888,
        github_login="delete_user",
        github_access_token="gho_delete_token",
    )
    del_ok = session_store.delete_session(session_id_del)
    assert del_ok is True
    assert session_store.get_session(session_id_del) is None
    print("  [PASS] Session deleted; subsequent retrieval returns None")

    # ──────────────────────────────────────────────
    # Test E: Invalid session
    # ──────────────────────────────────────────────
    print("\n--- Test E: Invalid session ---")
    assert session_store.get_session("non_existent_token_abc") is None
    assert session_store.get_session("") is None
    assert session_store.delete_session("non_existent_token_abc") is False
    print("  [PASS] Non-existent or empty session tokens safely return None/False")

    # ──────────────────────────────────────────────
    # Test F: Encrypted token round-trip
    # ──────────────────────────────────────────────
    print("\n--- Test F: Encrypted token round-trip ---")
    secret_token = "gho_SUPER_SECRET_PAT_TOKEN_998877"
    session_id_f = session_store.create_session(
        github_user_id=777777,
        github_login="crypto_user",
        github_access_token=secret_token,
    )
    retrieved_f = session_store.get_session(session_id_f)
    assert retrieved_f["github_access_token"] == secret_token
    print("  [PASS] Plaintext token round-trips identically after encryption/decryption")

    # ──────────────────────────────────────────────
    # Test G: Database contains ciphertext, not plaintext
    # ──────────────────────────────────────────────
    print("\n--- Test G: Database contains ciphertext, not plaintext ---")
    raw_stored_token = mock_pool.db[session_id_f]["github_access_token"]
    assert raw_stored_token != secret_token
    assert not raw_stored_token.startswith("gho_")
    assert raw_stored_token.startswith("gAAAAAB")  # Standard Fernet ciphertext prefix
    print(f"  [PASS] Raw database row contains Fernet ciphertext: {raw_stored_token[:24]}...")

    # ──────────────────────────────────────────────
    # Test H: Wrong encryption key fails safely
    # ──────────────────────────────────────────────
    print("\n--- Test H: Wrong encryption key fails safely ---")
    os.environ["SESSION_ENCRYPTION_KEY"] = TEST_KEY_2
    try:
        session_store.get_session(session_id_f)
        assert False, "Expected HTTPException 500 on key mismatch"
    except HTTPException as e:
        assert e.status_code == 500
        assert "encryption key mismatch" in e.detail
        print("  [PASS] Decryption with incorrect key raises HTTP 500 without leaking corrupt data")
    # Restore key 1
    os.environ["SESSION_ENCRYPTION_KEY"] = TEST_KEY_1

    # ──────────────────────────────────────────────
    # Test I: 50 concurrent get_session operations
    # ──────────────────────────────────────────────
    print("\n--- Test I: 50 concurrent get_session operations ---")
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [
            executor.submit(session_store.get_session, session_id_a)
            for _ in range(50)
        ]
        results = [f.result() for f in futures]
    assert len(results) == 50
    assert all(r["github_access_token"] == "gho_secret_token_123" for r in results)
    print("  [PASS] 50 concurrent get_session calls executed cleanly without deadlock or race condition")

    # ──────────────────────────────────────────────
    # Test J: Multi-user isolation
    # ──────────────────────────────────────────────
    print("\n--- Test J: Multi-user isolation ---")
    session_user_1 = session_store.create_session(
        github_user_id=1001,
        github_login="user_one",
        github_access_token="gho_token_user_one",
    )
    session_user_2 = session_store.create_session(
        github_user_id=1002,
        github_login="user_two",
        github_access_token="gho_token_user_two",
    )
    s1 = session_store.get_session(session_user_1)
    s2 = session_store.get_session(session_user_2)
    assert s1["github_user_id"] == 1001
    assert s2["github_user_id"] == 1002
    assert s1["github_access_token"] == "gho_token_user_one"
    assert s2["github_access_token"] == "gho_token_user_two"
    assert s1["github_access_token"] != s2["github_access_token"]
    print("  [PASS] User 1 and User 2 have strictly separated sessions and tokens")

    # ──────────────────────────────────────────────
    # Test K: Logout returns HTTP 401 on subsequent request
    # ──────────────────────────────────────────────
    print("\n--- Test K: Logout returns HTTP 401 on subsequent request ---")
    user_k = require_auth(f"Bearer {session_user_1}")
    assert user_k.github_user_id == 1001
    # User logs out
    session_store.delete_session(session_user_1)
    try:
        require_auth(f"Bearer {session_user_1}")
        assert False, "Expected 401 after logout"
    except HTTPException as e:
        assert e.status_code == 401
        print("  [PASS] require_auth raises HTTP 401 immediately after session is deleted")

    # ──────────────────────────────────────────────
    # Test L: require_auth regression
    # ──────────────────────────────────────────────
    print("\n--- Test L: require_auth regression ---")
    auth_user = require_auth(f"Bearer {session_user_2}")
    assert isinstance(auth_user, AuthenticatedUser)
    assert auth_user.github_user_id == 1002
    assert auth_user.github_login == "user_two"
    assert auth_user.github_token == "gho_token_user_two"
    assert auth_user.session_id == session_user_2

    # Missing header -> 401
    try:
        require_auth(None)
        assert False
    except HTTPException as e:
        assert e.status_code == 401

    # Malformed header -> 401
    try:
        require_auth("Basic 12345")
        assert False
    except HTTPException as e:
        assert e.status_code == 401
    print("  [PASS] require_auth resolves AuthenticatedUser correctly and enforces 401 rules")

    # ──────────────────────────────────────────────
    # Test M: verify_repo_access regression
    # ──────────────────────────────────────────────
    print("\n--- Test M: verify_repo_access regression ---")
    async def test_repo_access():
        with patch("httpx.AsyncClient.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"id": 1, "name": "my-repo", "owner": {"login": "user_two"}}
            mock_get.return_value = mock_resp

            repo_meta = await verify_repo_access("user_two", "my-repo", auth_user)
            assert repo_meta["name"] == "my-repo"
            # Verify user's decrypted token was used
            called_headers = mock_get.call_args[1]["headers"]
            assert called_headers["Authorization"] == "Bearer gho_token_user_two"

    asyncio.run(test_repo_access())
    print("  [PASS] verify_repo_access propagated decrypted token in Authorization header")

    # ──────────────────────────────────────────────
    # Test N: OAuth callback creates session
    # ──────────────────────────────────────────────
    print("\n--- Test N: OAuth callback creates session ---")
    # Simulate auth.py callback token creation
    new_sess = session_store.create_session(
        github_user_id=555555,
        github_login="oauth_callback_user",
        github_access_token="gho_oauth_cb_token",
        github_avatar_url="https://avatar.url",
        github_name="OAuth User",
    )
    cb_sess = session_store.get_session(new_sess)
    assert cb_sess["github_login"] == "oauth_callback_user"
    assert cb_sess["github_access_token"] == "gho_oauth_cb_token"
    print("  [PASS] Server-side session creation from OAuth callback operates seamlessly")

    # ──────────────────────────────────────────────
    # Test O: Redis handoff still works
    # ──────────────────────────────────────────────
    print("\n--- Test O: Redis handoff still works ---")
    hcode = session_store.create_handoff_code(new_sess)
    assert len(hcode) >= 48
    exchanged = session_store.exchange_handoff_code(hcode)
    assert exchanged == new_sess
    # Single-use check
    assert session_store.exchange_handoff_code(hcode) is None
    print("  [PASS] Redis handoff code generation, single-use, and exchange operating as in Step 19")

    # ──────────────────────────────────────────────
    # Test P: Redis OAuth state still works
    # ──────────────────────────────────────────────
    print("\n--- Test P: Redis OAuth state still works ---")
    csrf_state = "test_csrf_token_step21"
    auth._store_state(csrf_state)
    assert auth._validate_state(csrf_state) is True
    assert auth._validate_state(csrf_state) is False  # Single-use
    print("  [PASS] Redis OAuth state storage, single-use, and expiration operating as in Step 19")

    # ──────────────────────────────────────────────
    # Test Q: Existing tenant isolation
    # ──────────────────────────────────────────────
    print("\n--- Test Q: Existing tenant isolation ---")
    user_1_col = user_scoped_collection_name(
        AuthenticatedUser(1001, "user_one", "t1", "s1"), "acme", "project"
    )
    user_2_col = user_scoped_collection_name(
        AuthenticatedUser(1002, "user_two", "t2", "s2"), "acme", "project"
    )
    assert user_1_col == "u1001_acme_project"
    assert user_2_col == "u1002_acme_project"
    assert user_1_col != user_2_col
    print("  [PASS] ChromaDB collection naming strictly partitioned: u1001_acme_project != u1002_acme_project")

    # Clean up test overrides
    session_store.reset_db_pool()
    reset_redis_client()

    print("\n==================================================")
    print("ALL STEP 21 TESTS PASSED SUCCESSFULLY!")
    print("==================================================")


if __name__ == "__main__":
    run_all_tests()
