"""
Comprehensive test suite for distributed OAuth ephemeral state via Redis.

Covers:
3. OAuth state creation/validation test
4. OAuth state expiry test
5. OAuth state single-use test
6. Handoff-code creation test
7. Handoff-code expiry test
8. Handoff-code single-use test
9. Invalid handoff-code test
10. Redis unavailable/error-path test (HTTP 503, no fallback)
11. Existing session retrieval test (SQLite sessions.db)
12. Existing logout test (SQLite sessions.db)
"""

import os
import time
from cryptography.fernet import Fernet
import pytest
from fastapi import HTTPException
import redis

from services import session_store
from services.redis_client import set_redis_client, reset_redis_client
from routers import auth
from test_durable_session import MockPostgresPool

if not os.getenv("SESSION_ENCRYPTION_KEY"):
    os.environ["SESSION_ENCRYPTION_KEY"] = Fernet.generate_key().decode()


class MockRedis:
    """In-memory Redis mock supporting set(ex=...), getdel, and TTL expiration."""
    def __init__(self):
        self.store = {}  # key -> (value, expire_at)
        self.commands = []

    def set(self, name: str, value: str, ex: int | None = None):
        self.commands.append(("SET", name, value, ex))
        expire_at = (time.time() + ex) if ex else None
        self.store[name] = (str(value), expire_at)
        return True

    def getdel(self, name: str):
        self.commands.append(("GETDEL", name))
        if name not in self.store:
            return None
        val, expire_at = self.store.pop(name)
        if expire_at and time.time() > expire_at:
            return None
        return val

    def expire_key(self, name: str, seconds_ago: float = 1.0):
        """Helper to simulate expiration."""
        if name in self.store:
            val, _ = self.store[name]
            self.store[name] = (val, time.time() - seconds_ago)


def test_all():
    print("==================================================")
    print("STEP 19 — REDIS DISTRIBUTED EPHEMERAL STATE TESTS")
    print("==================================================")

    mock_pool = MockPostgresPool()
    session_store.set_db_pool(mock_pool)

    mock = MockRedis()
    set_redis_client(mock)

    # ──────────────────────────────────────────────
    # Test 3: OAuth state creation and validation
    # ──────────────────────────────────────────────
    print("\n--- Test 3: OAuth state creation and validation ---")
    state_token = "secure_test_state_123456789"
    auth._store_state(state_token)
    assert f"oauth_state:{state_token}" in mock.store
    val, expire_at = mock.store[f"oauth_state:{state_token}"]
    assert val == "1"
    # Verify TTL is approx 600s
    assert expire_at > time.time() + 590
    print("  [PASS] OAuth state stored in Redis with key oauth_state:<state> and 600s TTL")

    valid = auth._validate_state(state_token)
    assert valid is True
    print("  [PASS] OAuth state validated successfully")

    # ──────────────────────────────────────────────
    # Test 4: OAuth state expiry
    # ──────────────────────────────────────────────
    print("\n--- Test 4: OAuth state expiry ---")
    state_expiring = "state_to_expire_abc"
    auth._store_state(state_expiring)
    # Simulate time passing beyond 600s
    mock.expire_key(f"oauth_state:{state_expiring}", seconds_ago=10)
    valid_after_expiry = auth._validate_state(state_expiring)
    assert valid_after_expiry is False
    print("  [PASS] Expired OAuth state rejected")

    # ──────────────────────────────────────────────
    # Test 5: OAuth state single-use
    # ──────────────────────────────────────────────
    print("\n--- Test 5: OAuth state single-use ---")
    state_single = "state_single_use_xyz"
    auth._store_state(state_single)
    # First validation succeeds
    assert auth._validate_state(state_single) is True
    # Second validation must fail (atomically consumed via GETDEL)
    assert auth._validate_state(state_single) is False
    print("  [PASS] OAuth state consumed atomically on first use (single-use enforced)")

    # ──────────────────────────────────────────────
    # Test 6: Handoff-code creation
    # ──────────────────────────────────────────────
    print("\n--- Test 6: Handoff-code creation ---")
    dummy_session = "bugsense_session_token_99999"
    code = session_store.create_handoff_code(dummy_session)
    assert len(code) >= 48  # 36 bytes token_urlsafe
    assert f"handoff_code:{code}" in mock.store
    val, expire_at = mock.store[f"handoff_code:{code}"]
    assert val == dummy_session
    assert expire_at > time.time() + 110  # 120s TTL
    print(f"  [PASS] Handoff code created ({code[:16]}...) stored with 120s TTL")

    # ──────────────────────────────────────────────
    # Test 7: Handoff-code expiry
    # ──────────────────────────────────────────────
    print("\n--- Test 7: Handoff-code expiry ---")
    code_expiring = session_store.create_handoff_code(dummy_session)
    mock.expire_key(f"handoff_code:{code_expiring}", seconds_ago=5)
    expired_result = session_store.exchange_handoff_code(code_expiring)
    assert expired_result is None
    print("  [PASS] Expired handoff code rejected")

    # ──────────────────────────────────────────────
    # Test 8: Handoff-code single-use
    # ──────────────────────────────────────────────
    print("\n--- Test 8: Handoff-code single-use ---")
    code_single = session_store.create_handoff_code(dummy_session)
    first_exchange = session_store.exchange_handoff_code(code_single)
    assert first_exchange == dummy_session
    # Second exchange must return None
    second_exchange = session_store.exchange_handoff_code(code_single)
    assert second_exchange is None
    print("  [PASS] Handoff code atomically deleted on first exchange (single-use enforced)")

    # ──────────────────────────────────────────────
    # Test 9: Invalid handoff-code
    # ──────────────────────────────────────────────
    print("\n--- Test 9: Invalid handoff-code ---")
    invalid_result = session_store.exchange_handoff_code("non_existent_code_12345")
    assert invalid_result is None
    print("  [PASS] Non-existent handoff code returns None")

    # ──────────────────────────────────────────────
    # Test 10: Redis unavailable/error-path test
    # ──────────────────────────────────────────────
    print("\n--- Test 10: Redis unavailable / error-path test ---")
    # Reset mock to test real client failure or error client
    class ErrorRedis:
        def set(self, *args, **kwargs):
            raise redis.ConnectionError("Redis connection refused on localhost:6379")
        def getdel(self, *args, **kwargs):
            raise redis.ConnectionError("Redis connection refused on localhost:6379")

    set_redis_client(ErrorRedis())

    # 1. Storing state when Redis is unavailable must raise HTTP 503
    try:
        auth._store_state("fail_state")
        assert False, "Expected HTTPException 503"
    except HTTPException as e:
        assert e.status_code == 503
        assert "temporarily unavailable" in e.detail
        print("  [PASS] _store_state raises HTTP 503 when Redis is down")

    # 2. Validating state when Redis is unavailable must raise HTTP 503
    try:
        auth._validate_state("fail_state")
        assert False, "Expected HTTPException 503"
    except HTTPException as e:
        assert e.status_code == 503
        assert "temporarily unavailable" in e.detail
        print("  [PASS] _validate_state raises HTTP 503 when Redis is down")

    # 3. Creating handoff code when Redis is unavailable must raise HTTP 503
    try:
        session_store.create_handoff_code("some_session")
        assert False, "Expected HTTPException 503"
    except HTTPException as e:
        assert e.status_code == 503
        assert "temporarily unavailable" in e.detail
        print("  [PASS] create_handoff_code raises HTTP 503 when Redis is down")

    # 4. Exchanging handoff code when Redis is unavailable must raise HTTP 503
    try:
        session_store.exchange_handoff_code("some_code")
        assert False, "Expected HTTPException 503"
    except HTTPException as e:
        assert e.status_code == 503
        assert "temporarily unavailable" in e.detail
        print("  [PASS] exchange_handoff_code raises HTTP 503 when Redis is down")

    # 5. Verify no fallback to in-memory dictionaries
    assert not hasattr(auth, "_pending_states"), "auth._pending_states must NOT exist"
    assert not hasattr(session_store, "_handoff_codes"), "session_store._handoff_codes must NOT exist"
    print("  [PASS] Verified _pending_states and _handoff_codes are completely removed (no silent fallback)")

    # ──────────────────────────────────────────────
    # Test 11 & 12: Existing SQLite session store
    # ──────────────────────────────────────────────
    print("\n--- Test 11: Existing session creation and retrieval (SQLite) ---")
    mock_user_id = 887766
    mock_login = "redis_test_user"
    mock_token = "gho_test_access_token_abc"
    session_id = session_store.create_session(
        github_user_id=mock_user_id,
        github_login=mock_login,
        github_access_token=mock_token,
        github_name="Redis Test User",
    )
    assert session_id is not None
    session_data = session_store.get_session(session_id)
    assert session_data is not None
    assert session_data["github_user_id"] == mock_user_id
    assert session_data["github_login"] == mock_login
    assert session_data["github_access_token"] == mock_token
    print(f"  [PASS] SQLite session store intact. Created and retrieved session: {session_id[:16]}...")

    print("\n--- Test 12: Existing session logout (SQLite) ---")
    deleted = session_store.delete_session(session_id)
    assert deleted is True
    session_after_delete = session_store.get_session(session_id)
    assert session_after_delete is None
    print("  [PASS] SQLite session store logout/deletion intact")

    # ──────────────────────────────────────────────
    # Test 13: Full FastAPI HTTP Endpoint Integration
    # ──────────────────────────────────────────────
    print("\n--- Test 13: FastAPI HTTP Endpoints Integration ---")
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    test_app = FastAPI()
    test_app.include_router(auth.router)
    client = TestClient(test_app, raise_server_exceptions=False)

    # A. With MockRedis active
    mock2 = MockRedis()
    set_redis_client(mock2)

    # 1. Login endpoint stores state in Redis
    login_resp = client.get("/auth/github/login")
    assert login_resp.status_code == 200
    login_json = login_resp.json()
    assert "auth_url" in login_json
    assert "state" in login_json
    login_state = login_json["state"]
    assert f"oauth_state:{login_state}" in mock2.store
    print("  [PASS] GET /auth/github/login returned 200 and stored state in Redis")

    # 2. Exchange callback code endpoint retrieves session
    temp_sess = session_store.create_session(
        github_user_id=112233,
        github_login="http_test_user",
        github_access_token="gho_http_test_tok",
        github_name="HTTP Test User",
    )
    hcode = session_store.create_handoff_code(temp_sess)
    exchange_resp = client.post("/auth/github/exchange-callback-code", json={"code": hcode})
    assert exchange_resp.status_code == 200
    assert exchange_resp.json()["session_token"] == temp_sess
    assert exchange_resp.json()["user"]["login"] == "http_test_user"
    print("  [PASS] POST /auth/github/exchange-callback-code returned 200 with session")

    # 3. Second exchange with same code returns 400
    second_resp = client.post("/auth/github/exchange-callback-code", json={"code": hcode})
    assert second_resp.status_code == 400
    print("  [PASS] Second POST with same handoff code returned 400 (single-use enforced)")

    # B. With ErrorRedis active (service unavailable)
    set_redis_client(ErrorRedis())
    fail_login = client.get("/auth/github/login")
    assert fail_login.status_code == 503
    print("  [PASS] GET /auth/github/login returned 503 when Redis is unavailable")

    fail_exchange = client.post("/auth/github/exchange-callback-code", json={"code": "any_code"})
    assert fail_exchange.status_code == 503
    print("  [PASS] POST /auth/github/exchange-callback-code returned 503 when Redis is unavailable")

    session_store.delete_session(temp_sess)

    # Clean up mock
    reset_redis_client()
    print("\n==================================================")
    print("ALL STEP 19 TESTS PASSED SUCCESSFULLY!")
    print("==================================================")


if __name__ == "__main__":
    test_all()
