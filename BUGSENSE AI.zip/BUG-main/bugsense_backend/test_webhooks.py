"""
Automated tests for GitHub Webhook integration in BugSense Backend.

Tests:
1. Health check regression.
2. POST /webhooks/github with ping event.
3. POST /webhooks/github with issues event (opened).
4. POST /webhooks/github with issue_comment event.
5. POST /webhooks/github with unknown event type.
6. GET /webhooks/github/events returns stored events.
7. POST /webhooks/github/test simulates events in dev mode.
8. Missing X-GitHub-Event header → 400.
9. HMAC signature verification (when secret is configured).

Requires: FastAPI server running on localhost:8000.
"""

import sys
import json
import hashlib
import hmac

import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def _sign_payload(payload_bytes: bytes, secret: str) -> str:
    """Generate a valid X-Hub-Signature-256 header value."""
    mac = hmac.new(secret.encode("utf-8"), payload_bytes, hashlib.sha256)
    return f"sha256={mac.hexdigest()}"


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense GitHub Webhooks")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check regression ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    health_ok = r.status_code == 200 and bool(version)
    results.append(test(f"GET /health returns version {version}", health_ok))

    # --- 1. Ping event ---
    print("\n-- Webhook Events --")
    ping_payload = {
        "zen": "Keep it logically awesome.",
        "hook_id": 12345,
        "repository": {"full_name": "octocat/Hello-World"},
    }
    r = httpx.post(
        f"{BASE}/webhooks/github",
        json=ping_payload,
        headers={
            "X-GitHub-Event": "ping",
            "X-GitHub-Delivery": "test-delivery-001",
        },
    )
    ping_ok = r.status_code == 200 and r.json().get("event") == "ping"
    results.append(test("POST /webhooks/github with ping event", ping_ok))

    # --- 2. Issues opened event ---
    issues_payload = {
        "action": "opened",
        "issue": {
            "number": 99,
            "title": "Test webhook issue",
            "body": "This was triggered by the webhook test suite.",
            "state": "open",
            "labels": [{"name": "bug"}, {"name": "webhook-test"}],
            "user": {"login": "test-bot"},
            "html_url": "https://github.com/octocat/Hello-World/issues/99",
        },
        "repository": {"full_name": "octocat/Hello-World"},
    }
    r = httpx.post(
        f"{BASE}/webhooks/github",
        json=issues_payload,
        headers={
            "X-GitHub-Event": "issues",
            "X-GitHub-Delivery": "test-delivery-002",
        },
    )
    issues_ok = r.status_code == 200 and r.json().get("event") == "issues"
    result_data = r.json().get("result", {})
    action_ok = result_data.get("action") == "opened"
    results.append(
        test(
            "POST /webhooks/github with issues.opened event",
            issues_ok and action_ok,
            f"action={result_data.get('action')} title={result_data.get('title', '')[:40]}",
        )
    )

    # --- 3. Issue comment event ---
    comment_payload = {
        "action": "created",
        "issue": {
            "number": 99,
            "title": "Test webhook issue",
        },
        "comment": {
            "id": 555,
            "body": "This is a test comment from the webhook test suite.",
            "user": {"login": "commenter-bot"},
        },
        "repository": {"full_name": "octocat/Hello-World"},
    }
    r = httpx.post(
        f"{BASE}/webhooks/github",
        json=comment_payload,
        headers={
            "X-GitHub-Event": "issue_comment",
            "X-GitHub-Delivery": "test-delivery-003",
        },
    )
    comment_ok = r.status_code == 200 and r.json().get("event") == "issue_comment"
    results.append(test("POST /webhooks/github with issue_comment.created event", comment_ok))

    # --- 4. Unknown event type ---
    r = httpx.post(
        f"{BASE}/webhooks/github",
        json={"action": "completed", "repository": {"full_name": "octocat/Hello-World"}},
        headers={
            "X-GitHub-Event": "check_run",
            "X-GitHub-Delivery": "test-delivery-004",
        },
    )
    unknown_ok = r.status_code == 200 and r.json().get("event") == "check_run"
    results.append(test("POST /webhooks/github with unknown event type (logged, not rejected)", unknown_ok))

    # --- 5. Missing event header → 400 ---
    r = httpx.post(
        f"{BASE}/webhooks/github",
        json={"some": "data"},
    )
    missing_header_ok = r.status_code in (400, 422)
    results.append(test("POST /webhooks/github without X-GitHub-Event → 400/422", missing_header_ok))

    # --- 6. Get recent events ---
    print("\n-- Event Store --")
    r = httpx.get(f"{BASE}/webhooks/github/events", params={"limit": 10})
    events_ok = r.status_code == 200 and isinstance(r.json().get("events"), list)
    event_count = r.json().get("count", 0)
    results.append(test(f"GET /webhooks/github/events returns {event_count} events", events_ok and event_count >= 3))

    # Verify events are ordered newest-first
    events = r.json().get("events", [])
    if len(events) >= 2:
        first_time = events[0].get("received_at", "")
        second_time = events[1].get("received_at", "")
        order_ok = first_time >= second_time
        results.append(test("Events are ordered newest-first", order_ok))
    else:
        results.append(test("Events are ordered newest-first", False, "Not enough events"))

    # --- 7. Dev test endpoint ---
    print("\n-- Dev Test Endpoint --")
    r = httpx.post(
        f"{BASE}/webhooks/github/test",
        json={
            "event_type": "issues",
            "payload": {
                "action": "closed",
                "issue": {
                    "number": 100,
                    "title": "Simulated closed issue",
                    "state": "closed",
                    "labels": [],
                    "user": {"login": "dev-tester"},
                    "html_url": "https://github.com/octocat/Hello-World/issues/100",
                },
                "repository": {"full_name": "octocat/Hello-World"},
            },
        },
    )
    # If webhook secret is not set, this should work (200).
    # If webhook secret IS set, this should fail (403).
    if r.status_code == 200:
        sim_ok = r.json().get("status") == "simulated"
        results.append(test("POST /webhooks/github/test simulates event (dev mode)", sim_ok))
    elif r.status_code == 403:
        results.append(test("POST /webhooks/github/test blocked (secret configured)", True, "Expected in production mode"))
    else:
        results.append(test("POST /webhooks/github/test", False, f"Unexpected status: {r.status_code}"))

    # --- 8. HMAC signature test ---
    print("\n-- Signature Verification --")
    # Test with a known secret and payload
    test_secret = "test_webhook_secret_12345"
    test_payload = json.dumps({"zen": "HMAC test", "hook_id": 9999, "repository": {"full_name": "test/hmac"}}).encode()
    valid_sig = _sign_payload(test_payload, test_secret)

    # Import and test the verify_signature function directly
    try:
        sys.path.insert(0, ".")
        from services.webhook_service import verify_signature

        sig_valid = verify_signature(test_payload, valid_sig, test_secret)
        results.append(test("verify_signature() accepts valid HMAC-SHA256", sig_valid))

        sig_invalid = not verify_signature(test_payload, "sha256=invalid_hex", test_secret)
        results.append(test("verify_signature() rejects invalid HMAC-SHA256", sig_invalid))

        sig_wrong_prefix = not verify_signature(test_payload, "sha1=abc123", test_secret)
        results.append(test("verify_signature() rejects wrong prefix (sha1)", sig_wrong_prefix))
    except Exception as e:
        results.append(test("verify_signature() import/test", False, str(e)))

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("WEBHOOK TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All webhook tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
