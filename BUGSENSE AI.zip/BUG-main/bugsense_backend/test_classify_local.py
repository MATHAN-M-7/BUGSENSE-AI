import asyncio
from dotenv import load_dotenv
load_dotenv('.env')

from services.llm_provider import get_llm_provider

async def main():
    p = get_llm_provider()
    res = await p.classify_issue("App crashes when I click the login button.")
    print(res)

if __name__ == "__main__":
    asyncio.run(main())
