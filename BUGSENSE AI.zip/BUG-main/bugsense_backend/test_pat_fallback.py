import httpx
import asyncio

async def test_pat_fallback():
    print("--- STAGE 10: PAT FALLBACK TEST ---")
    async with httpx.AsyncClient() as client:
        r = await client.get("http://127.0.0.1:8000/github/user")
        print("Status:", r.status_code)
        if r.status_code == 200:
            print("User:", r.json().get('login'))
        else:
            print("Error:", r.text)
        
        r2 = await client.get("http://127.0.0.1:8000/github/repos?per_page=1")
        print("Repos status:", r2.status_code)
        if r2.status_code == 200:
            repos = r2.json()
            print("Found repos:", len(repos))
            if repos:
                print("First repo:", repos[0].get('name'))
        else:
            print("Error:", r2.text)

if __name__ == "__main__":
    asyncio.run(test_pat_fallback())
