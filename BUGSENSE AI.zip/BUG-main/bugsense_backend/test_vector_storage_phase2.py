"""
Test Suite for Production-Safe Vector Storage Phase 2

Covers Requirements 1-12:
A. local development vector backend initialization
B. remote vector backend configuration
C. invalid remote configuration
D. unavailable remote vector backend
E. tenant collection naming
F. tenant isolation
G. document insertion/upsert
H. similarity retrieval
I. collection reopening
J. existing RAG compatibility
K. no production fallback to local storage
L. existing authentication/session/Redis regression
"""

import os
import shutil
import sys
import tempfile
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

# Mock optional dependencies if missing in test environment
for mod in ["firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore"]:
    if mod not in sys.modules:
        sys.modules[mod] = MagicMock()

import config
from services.vector_store import (
    VectorStore,
    get_vector_store,
    set_vector_store,
    reset_vector_store,
)
from services.auth_guard import AuthenticatedUser, user_scoped_collection_name
import main


def mock_genai_client():
    """Mock Google GenAI client to return synthetic embeddings for deterministic testing."""
    mock_client = MagicMock()
    # Mock single embed
    mock_single_emb = MagicMock()
    mock_single_emb.values = [0.05 * i for i in range(16)]
    # Mock batch embed
    mock_batch_emb1 = MagicMock()
    mock_batch_emb1.values = [0.05 * i for i in range(16)]
    mock_batch_emb2 = MagicMock()
    mock_batch_emb2.values = [0.02 * i for i in range(16)]

    mock_client.models.embed_content.return_value = MagicMock(
        embeddings=[mock_single_emb, mock_batch_emb2]
    )
    return mock_client


# ──────────────────────────────────────────────
# Test A: Local development vector backend initialization
# ──────────────────────────────────────────────
def test_section_a_local_backend_init():
    print("\n--- Test A: Local development vector backend initialization ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_a_")
    try:
        with patch.dict(os.environ, {
            "VECTOR_STORE_BACKEND": "chroma_local",
            "CHROMA_PERSIST_DIR": temp_dir,
            "ENVIRONMENT": "development",
        }):
            reset_vector_store()
            store = VectorStore(persist_dir=temp_dir)
            assert store._backend == "chroma_local"
            assert store._persist_dir == temp_dir
            assert hasattr(store._client, "get_or_create_collection")

            health = store.health_check()
            assert health["status"] == "healthy"
            assert health["backend"] == "chroma_local"
            assert health["reachable"] is True
            print("  [PASS] Local Chroma backend initialized correctly using PersistentClient and CHROMA_PERSIST_DIR")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test B: Remote vector backend configuration
# ──────────────────────────────────────────────
def test_section_b_remote_backend_config():
    print("\n--- Test B: Remote vector backend configuration ---")
    mock_remote_client = MagicMock()
    mock_remote_client.heartbeat.return_value = 123456789

    with patch.dict(os.environ, {
        "VECTOR_STORE_BACKEND": "chroma_remote",
        "CHROMA_HOST": "chroma.production.internal",
        "CHROMA_PORT": "8443",
        "CHROMA_SSL": "true",
        "CHROMA_API_KEY": "secret-auth-token-12345",
        "CHROMA_TENANT": "prod_tenant",
        "CHROMA_DATABASE": "prod_database",
    }):
        with patch("chromadb.HttpClient", return_value=mock_remote_client) as mock_http_constructor:
            reset_vector_store()
            store = VectorStore()
            assert store._backend == "chroma_remote"

            # Verify chromadb.HttpClient arguments
            mock_http_constructor.assert_called_once()
            call_kwargs = mock_http_constructor.call_args.kwargs
            assert call_kwargs["host"] == "chroma.production.internal"
            assert call_kwargs["port"] == 8443
            assert call_kwargs["ssl"] is True
            assert call_kwargs["tenant"] == "prod_tenant"
            assert call_kwargs["database"] == "prod_database"
            assert "X-Chroma-Token" in call_kwargs["headers"]
            assert call_kwargs["headers"]["X-Chroma-Token"] == "secret-auth-token-12345"

            health = store.health_check()
            assert health["status"] == "healthy"
            assert health["backend"] == "chroma_remote"
            assert health["reachable"] is True
            print("  [PASS] Remote Chroma HttpClient configured accurately with TLS, port, and authentication headers")


# ──────────────────────────────────────────────
# Test C: Invalid remote configuration
# ──────────────────────────────────────────────
def test_section_c_invalid_remote_config():
    print("\n--- Test C: Invalid remote configuration ---")
    # 1. Missing host in remote mode
    with patch.dict(os.environ, {
        "VECTOR_STORE_BACKEND": "chroma_remote",
        "CHROMA_HOST": "",
    }):
        reset_vector_store()
        try:
            VectorStore()
            assert False, "Should raise ValueError when CHROMA_HOST is empty"
        except ValueError as e:
            assert "CHROMA_HOST must be specified" in str(e)
            print("  [PASS] Empty CHROMA_HOST correctly raises ValueError")

    # 2. Unsupported backend name
    with patch.dict(os.environ, {
        "VECTOR_STORE_BACKEND": "unsupported_storage_engine",
    }):
        reset_vector_store()
        try:
            VectorStore()
            assert False, "Should raise ValueError on invalid backend"
        except ValueError as e:
            assert "Unsupported VECTOR_STORE_BACKEND" in str(e)
            print("  [PASS] Unsupported backend name correctly raises ValueError")


# ──────────────────────────────────────────────
# Test D: Unavailable remote vector backend
# ──────────────────────────────────────────────
def test_section_d_unavailable_remote_backend():
    print("\n--- Test D: Unavailable remote vector backend ---")
    with patch.dict(os.environ, {
        "VECTOR_STORE_BACKEND": "chroma_remote",
        "CHROMA_HOST": "10.255.255.1",
        "CHROMA_PORT": "9999",
        "CHROMA_API_KEY": "super_secret_chroma_key",
    }):
        with patch("chromadb.HttpClient", side_effect=ValueError("Could not connect to a Chroma server")):
            reset_vector_store()
            try:
                VectorStore()
                assert False, "Should raise RuntimeError on connection failure"
            except RuntimeError as e:
                err_text = str(e)
                assert "Failed to connect to remote Chroma server at 10.255.255.1:9999" in err_text
                assert "Silent fallback to local storage is strictly disabled" in err_text
                # Security audit: Confirm secrets are never leaked in error
                assert "super_secret_chroma_key" not in err_text
                print("  [PASS] Connection failure raises RuntimeError and prevents secret leakage")


# ──────────────────────────────────────────────
# Test E: Tenant collection naming
# ──────────────────────────────────────────────
def test_section_e_tenant_collection_naming():
    print("\n--- Test E: Tenant collection naming ---")
    user = AuthenticatedUser(
        github_user_id=12345,
        github_login="developer1",
        github_token="gho_test",
        session_id="sess_test",
    )
    col_name = user_scoped_collection_name(user, "facebook", "react")
    assert col_name == "u12345_facebook_react"

    # Sanitisation tests
    sanitised_normal = VectorStore._sanitise_collection_name("u12345_facebook_react")
    assert sanitised_normal == "u12345_facebook_react"

    # With dashes and dots
    sanitised_complex = VectorStore._sanitise_collection_name("u12345_my-org_special.repo-name")
    assert "." not in sanitised_complex
    assert "-" not in sanitised_complex
    assert sanitised_complex.startswith("u12345_my_org")
    assert len(sanitised_complex) <= 63
    print("  [PASS] Tenant collection naming format u{github_user_id}_{owner}_{repo} strictly enforced and sanitised")


# ──────────────────────────────────────────────
# Test F: Tenant isolation
# ──────────────────────────────────────────────
def test_section_f_tenant_isolation():
    print("\n--- Test F: Tenant isolation ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_f_")
    try:
        reset_vector_store()
        store = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        store._genai_client = mock_genai_client()

        # User 1 (id 1001) indexes an issue in facebook/react
        store.upsert_issue(
            repo_owner="facebook",
            repo_name="react",
            issue_number=10,
            text="Bug in useState hook with async updates",
            metadata={"title": "useState async bug"},
            github_user_id=1001,
        )

        # User 2 (id 2002) checks collection stats in facebook/react
        u2_stats = store.get_collection_stats(
            repo_owner="facebook",
            repo_name="react",
            github_user_id=2002,
        )
        assert u2_stats["count"] == 0

        # User 2 searches in facebook/react -> zero matches
        u2_matches = store.search_similar(
            repo_owner="facebook",
            repo_name="react",
            query="useState hook",
            n_results=5,
            github_user_id=2002,
        )
        assert len(u2_matches) == 0

        # User 1 searches in facebook/react -> finds their issue
        u1_matches = store.search_similar(
            repo_owner="facebook",
            repo_name="react",
            query="useState hook",
            n_results=5,
            github_user_id=1001,
        )
        assert len(u1_matches) == 1
        assert u1_matches[0]["id"] == "facebook_react_10"

        # User 1 on different repo: facebook/react vs facebook/flux
        u1_flux_stats = store.get_collection_stats(
            repo_owner="facebook",
            repo_name="flux",
            github_user_id=1001,
        )
        assert u1_flux_stats["count"] == 0

        print("  [PASS] Tenant isolation verified: User A + repo X != User B + repo X and User A + repo X != User A + repo Y")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test G: Document insertion/upsert
# ──────────────────────────────────────────────
def test_section_g_document_upsert():
    print("\n--- Test G: Document insertion/upsert ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_g_")
    try:
        reset_vector_store()
        store = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        store._genai_client = mock_genai_client()

        doc_id = store.upsert_issue(
            repo_owner="pallets",
            repo_name="flask",
            issue_number=42,
            text="Memory leak when handling chunked streaming responses",
            metadata={
                "title": "Memory leak streaming",
                "state": "open",
                "category": "Performance",
                "severity": "High",
            },
            github_user_id=5555,
        )
        assert doc_id == "pallets_flask_42"

        stats = store.get_collection_stats("pallets", "flask", github_user_id=5555)
        assert stats["count"] == 1
        print("  [PASS] Document upserted with correct ID, metadata, and embeddings")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test H: Similarity retrieval
# ──────────────────────────────────────────────
def test_section_h_similarity_retrieval():
    print("\n--- Test H: Similarity retrieval ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_h_")
    try:
        reset_vector_store()
        store = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        store._genai_client = mock_genai_client()

        store.upsert_issue(
            repo_owner="tiangolo",
            repo_name="fastapi",
            issue_number=1,
            text="Query parameter validation error with custom Pydantic models",
            metadata={"title": "Query validation"},
            github_user_id=7777,
        )

        matches = store.search_similar(
            repo_owner="tiangolo",
            repo_name="fastapi",
            query="pydantic model validation",
            n_results=3,
            github_user_id=7777,
        )
        assert len(matches) == 1
        m = matches[0]
        assert "similarity" in m
        assert "distance" in m
        assert "document" in m
        assert "metadata" in m
        assert m["id"] == "tiangolo_fastapi_1"
        assert 0.0 <= m["similarity"] <= 1.0
        print("  [PASS] Similarity search returned formatted results with score normalization")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test I: Collection reopening
# ──────────────────────────────────────────────
def test_section_i_collection_reopening():
    print("\n--- Test I: Collection reopening ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_i_")
    try:
        # Step 1: Open store, insert issue, then delete store instance
        store1 = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        store1._genai_client = mock_genai_client()
        store1.upsert_issue(
            repo_owner="django",
            repo_name="django",
            issue_number=100,
            text="ORM migration issue with foreign keys",
            github_user_id=8888,
        )
        del store1

        # Step 2: Open second store pointing to same directory
        store2 = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        stats = store2.get_collection_stats("django", "django", github_user_id=8888)
        assert stats["count"] == 1
        print("  [PASS] Collection reopening preserved existing vector documents and count")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test J: Existing RAG compatibility
# ──────────────────────────────────────────────
def test_section_j_rag_compatibility():
    print("\n--- Test J: Existing RAG compatibility ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_j_")
    try:
        reset_vector_store()
        store = VectorStore(persist_dir=temp_dir, backend="chroma_local")
        store._genai_client = mock_genai_client()
        set_vector_store(store)

        # Upsert test issue
        store.upsert_issue(
            repo_owner="org",
            repo_name="app",
            issue_number=202,
            text="NullPointerException in authentication filter",
            metadata={"title": "NPE in filter", "category": "Bug", "severity": "High"},
            github_user_id=9999,
        )

        # Test consumer 1: classifier agent retrieval helper pattern
        from services import classifier_agent
        results_c = classifier_agent._retrieve_similar_issues("org", "app", "NullPointer auth", n_results=3)
        assert isinstance(results_c, list)

        # Test consumer 2: resolution agent retrieval helper pattern
        from services import resolution_agent
        results_r = resolution_agent._retrieve_similar_issues("org", "app", "NullPointer auth", n_results=3)
        assert isinstance(results_r, list)

        # Test consumer 3: root cause agent retrieval helper pattern
        from services import root_cause_agent
        results_rc = root_cause_agent._retrieve_similar_issues("org", "app", "NullPointer auth", n_results=3)
        assert isinstance(results_rc, list)

        print("  [PASS] All existing agent RAG patterns operate seamlessly with vector store abstraction")
    finally:
        reset_vector_store()
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test K: No production fallback to local storage
# ──────────────────────────────────────────────
def test_section_k_no_silent_fallback_in_production():
    print("\n--- Test K: No production fallback to local storage ---")
    temp_dir = tempfile.mkdtemp(prefix="chroma_test_k_")
    try:
        # In production mode with chroma_remote and unavailable remote service:
        with patch.dict(os.environ, {
            "ENVIRONMENT": "production",
            "VECTOR_STORE_BACKEND": "chroma_remote",
            "CHROMA_HOST": "unreachable.chroma.cluster",
            "CHROMA_PORT": "8000",
            "CHROMA_PERSIST_DIR": temp_dir,
        }):
            with patch("chromadb.HttpClient", side_effect=ConnectionRefusedError("Connection actively refused")):
                reset_vector_store()
                try:
                    VectorStore()
                    assert False, "Production must raise RuntimeError and never silently fall back"
                except RuntimeError as exc:
                    assert "Silent fallback to local storage is strictly disabled in production" in str(exc)

                # Confirm no local database was created in temp_dir
                files = os.listdir(temp_dir)
                assert len(files) == 0, f"Local directory should be empty, found: {files}"
                print("  [PASS] Verified zero silent fallback to local disk when remote Chroma is unavailable")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ──────────────────────────────────────────────
# Test L: Vector search HTTP error handling (503 Service Unavailable)
# ──────────────────────────────────────────────
def test_section_l_vector_http_endpoints():
    print("\n--- Test L: Vector HTTP endpoints and health check ---")
    client = TestClient(main.app)

    # 1. Health check endpoint GET /search/health
    mock_store = MagicMock()
    mock_store.health_check.return_value = {
        "status": "healthy",
        "backend": "chroma_remote",
        "reachable": True,
    }
    set_vector_store(mock_store)

    res_health = client.get("/search/health")
    assert res_health.status_code == 200
    assert res_health.json()["status"] == "healthy"
    assert res_health.json()["backend"] == "chroma_remote"
    print("  [PASS] GET /search/health returned 200 with vector store reachability status")

    # 2. Vector store error returns 503 on search
    with patch("routers.search.require_auth", return_value=AuthenticatedUser(1001, "alice", "tok", "s1")):
        with patch("routers.search.verify_repo_access", return_value={"name": "repo"}):
            mock_failing_store = MagicMock()
            mock_failing_store.search_similar.side_effect = RuntimeError("Failed to connect to remote Chroma server at host:8000")
            set_vector_store(mock_failing_store)

            res_search = client.post(
                "/search/similar",
                json={"query": "test query", "repo_owner": "org", "repo_name": "repo", "n_results": 5},
                headers={"Authorization": "Bearer valid_token"},
            )
            assert res_search.status_code == 503
            assert "Vector search service is currently unavailable" in res_search.json()["detail"]
            print("  [PASS] Remote vector backend failure returned HTTP 503 Service Unavailable")
    reset_vector_store()


def run_all_tests():
    print("==================================================")
    print("BUGSENSE AI — PHASE 2 VECTOR STORAGE TESTS")
    print("==================================================")
    test_section_a_local_backend_init()
    test_section_b_remote_backend_config()
    test_section_c_invalid_remote_config()
    test_section_d_unavailable_remote_backend()
    test_section_e_tenant_collection_naming()
    test_section_f_tenant_isolation()
    test_section_g_document_upsert()
    test_section_h_similarity_retrieval()
    test_section_i_collection_reopening()
    test_section_j_rag_compatibility()
    test_section_k_no_silent_fallback_in_production()
    test_section_l_vector_http_endpoints()

    print("\n==================================================")
    print("ALL PHASE 2 VECTOR STORAGE TESTS PASSED SUCCESSFULLY!")
    print("==================================================")


if __name__ == "__main__":
    run_all_tests()
