import os
path = 'services/vector_store.py'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("http_options={'timeout': 60.0}", "http_options={'timeout': 60000}")
with open(path, 'w', encoding='utf-8') as f:
    f.write(text)
