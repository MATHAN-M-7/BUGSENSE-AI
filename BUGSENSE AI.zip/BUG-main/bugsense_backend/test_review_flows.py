"""
Test Suite: Human-in-the-Loop Review Flows (Approve / Edit / Reject).

Tests:
1. POST /analysis/review/verdict (APPROVED)
2. POST /analysis/review/verdict (EDITED with customized code)
3. POST /analysis/review/verdict (REJECTED with structured reason)
4. GET /analysis/review/verdicts audit querying and filtering
5. PR Gate lockout enforcement when an issue resolution has been REJECTED
6. PR Gate markdown rendering for human_approved and is_human_edited
"""

from fastapi.testclient import TestClient
from main import app
from services.github_service import build_pr_markdown

client = TestClient(app)

passed = 0
failed = 0


def ok(name: str, details: str = ""):
    global passed
    passed += 1
    d = f" -- {details}" if details else ""
    print(f"  [PASS] {name}{d}")


def fail(name: str, details: str = ""):
    global failed
    failed += 1
    d = f" -- {details}" if details else ""
    print(f"  [FAIL] {name}{d}")


def test_approve_verdict():
    payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 42,
        "verdict": "APPROVED",
        "reviewer": "sarah_engineer",
        "notes": "Verified patch locally on staging.",
    }
    r = client.post("/analysis/review/verdict", json=payload)
    if r.status_code == 200:
        data = r.json()
        assert data["verdict"] == "APPROVED"
        assert data["repo_owner"] == "octocat"
        assert data["issue_number"] == 42
        ok("Record APPROVED review verdict", f"recorded_at={data.get('recorded_at')}")
    else:
        fail("Record APPROVED review verdict", f"status={r.status_code} body={r.text}")


def test_edit_verdict():
    payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 43,
        "verdict": "EDITED",
        "reviewer": "alex_lead",
        "notes": "Added null check to snippet.",
        "edited_resolution": {
            "file_or_component": "lib/parser.dart",
            "code_snippet": "if (token == null) return;",
            "explanation": "Guard against null token",
        },
    }
    r = client.post("/analysis/review/verdict", json=payload)
    if r.status_code == 200:
        data = r.json()
        assert data["verdict"] == "EDITED"
        ok("Record EDITED review verdict", f"issue=43, reviewer={payload['reviewer']}")
    else:
        fail("Record EDITED review verdict", f"status={r.status_code} body={r.text}")


def test_reject_verdict():
    payload = {
        "repo_owner": "octocat",
        "repo_name": "Hello-World",
        "issue_number": 99,
        "verdict": "REJECTED",
        "reviewer": "chief_architect",
        "rejection_reason": "Incorrect Root Cause",
        "notes": "Memory leak was caused by stream subscription, not widget state.",
    }
    r = client.post("/analysis/review/verdict", json=payload)
    if r.status_code == 200:
        data = r.json()
        assert data["verdict"] == "REJECTED"
        assert data["rejection_reason"] == "Incorrect Root Cause"
        ok("Record REJECTED review verdict", f"reason={data['rejection_reason']}")
    else:
        fail("Record REJECTED review verdict", f"status={r.status_code} body={r.text}")


def test_query_verdicts_audit():
    r = client.get("/analysis/review/verdicts?repo_owner=octocat&issue_number=99")
    if r.status_code == 200:
        data = r.json()
        assert data["count"] >= 1
        verdict = data["verdicts"][0]
        assert verdict["verdict"] == "REJECTED"
        assert verdict["rejection_reason"] == "Incorrect Root Cause"
        ok("Query review verdicts audit trail", f"matches={data['count']}")
    else:
        fail("Query review verdicts audit trail", f"status={r.status_code}")


def test_pr_gate_locks_on_rejected_issue():
    # Issue 99 was rejected above. Attempting to generate a PR must return 403.
    payload = {
        "system_confidence_report": {
            "system_status": "READY_FOR_PR",
            "system_confidence": 0.95,
        },
        "resolution": {
            "code_suggestions": [
                {
                    "file_or_component": "lib/main.dart",
                    "code_snippet": "void main() {}",
                    "change_description": "test",
                }
            ]
        },
    }
    r = client.post(
        "/github/repos/octocat/Hello-World/issues/99/generate-pr",
        json=payload,
    )
    if r.status_code == 403:
        detail = r.json().get("detail", {})
        if detail.get("system_status") == "REJECTED" and "Incorrect Root Cause" in detail.get("rejection_reason", ""):
            ok("Safe PR Gate enforces permanent lockout on rejected issue #99", f"message={detail.get('message')}")
        else:
            fail("Safe PR Gate lockout detail mismatch", f"detail={detail}")
    else:
        fail("Safe PR Gate did not lock out rejected issue", f"status={r.status_code}")


def test_pr_gate_locks_on_explicit_is_rejected_payload():
    payload = {
        "is_rejected": True,
        "rejection_reason": "Hallucinated Code",
        "system_confidence_report": {
            "system_status": "READY_FOR_PR",
            "system_confidence": 0.95,
        },
        "resolution": {
            "code_suggestions": [
                {"file_or_component": "lib/main.dart", "code_snippet": "void main() {}"}
            ]
        },
    }
    r = client.post(
        "/github/repos/octocat/Hello-World/issues/101/generate-pr",
        json=payload,
    )
    if r.status_code == 403:
        detail = r.json().get("detail", {})
        if detail.get("system_status") == "REJECTED":
            ok("Safe PR Gate rejects payload with is_rejected=True", f"message={detail.get('message')}")
        else:
            fail("Safe PR Gate is_rejected status mismatch", f"detail={detail}")
    else:
        fail("Safe PR Gate allowed is_rejected=True payload", f"status={r.status_code}")


def test_pr_markdown_with_refinement_and_approval():
    # Test edited resolution formatting
    routing_result_edited = {
        "is_human_edited": True,
        "human_approved": True,
        "system_confidence_report": {
            "system_confidence": 0.88,
            "system_status": "READY_FOR_PR",
        },
        "resolution": {
            "fix_description": "Engineered fix with refined snippet",
            "code_suggestions": [
                {
                    "file_or_component": "src/cache.py",
                    "code_snippet": "cache.clear()",
                    "change_description": "Clear stale memory",
                }
            ],
        },
    }
    md_edited = build_pr_markdown(
        "octocat", "Hello-World", 43, "Fix stale cache", routing_result_edited
    )
    assert "Human-in-the-Loop Refinement" in md_edited
    ok("PR Markdown includes Human-in-the-Loop Refinement callout")

    # Test approved (non-edited) formatting
    routing_result_approved = {
        "is_human_edited": False,
        "human_approved": True,
        "system_confidence_report": {
            "system_confidence": 0.72,
            "system_status": "REQUIRES_HUMAN_REVIEW",
        },
        "resolution": {
            "fix_description": "Approved automated patch",
            "code_suggestions": [],
        },
    }
    md_approved = build_pr_markdown(
        "octocat", "Hello-World", 42, "Fix race condition", routing_result_approved
    )
    assert "Human Review Sign-Off" in md_approved
    ok("PR Markdown includes Human Review Sign-Off callout")


def run_all():
    print("Running Human-in-the-Loop Review Flows Test Suite...")
    test_approve_verdict()
    test_edit_verdict()
    test_reject_verdict()
    test_query_verdicts_audit()
    test_pr_gate_locks_on_rejected_issue()
    test_pr_gate_locks_on_explicit_is_rejected_payload()
    test_pr_markdown_with_refinement_and_approval()

    print(f"\nResults: {passed} passed, {failed} failed")
    if failed > 0:
        raise SystemExit(1)


if __name__ == "__main__":
    run_all()
