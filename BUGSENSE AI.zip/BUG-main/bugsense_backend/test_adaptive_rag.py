"""
Automated tests for Adaptive RAG in BugSense Backend.

Tests:
1. RAGStrategy enum values (skip, minimal, standard, expanded).
2. RAGConfig from route plan dictionaries.
3. Skip strategy returns empty results instantly with 0 latency.
4. Minimal / Standard / Expanded strategy configuration and floors.
5. AdaptiveRAG retrieval execution and RAGResult serialization.
"""

import sys
from services.adaptive_rag import (
    AdaptiveRAG,
    RAGConfig,
    RAGResult,
    RAGStrategy,
    get_adaptive_rag,
)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Adaptive RAG Engine")
    print(f"{'='*60}")

    results = []

    # ─── 1. RAGConfig from Route Plan ───
    print("\n-- 1. RAGConfig Creation & Parsing --")
    cfg_skip = RAGConfig.from_route_plan({"mode": "skip", "n_results": 0})
    results.append(test(
        "from_route_plan('skip') produces RAGStrategy.SKIP",
        cfg_skip.strategy == RAGStrategy.SKIP,
        f"strategy={cfg_skip.strategy}",
    ))

    cfg_exp = RAGConfig.from_route_plan({"mode": "expanded", "n_results": 5})
    results.append(test(
        "from_route_plan('expanded') produces RAGStrategy.EXPANDED with n_results=5",
        cfg_exp.strategy == RAGStrategy.EXPANDED and cfg_exp.n_results == 5,
        f"strategy={cfg_exp.strategy} n_results={cfg_exp.n_results}",
    ))

    cfg_std = RAGConfig.from_route_plan({"mode": "standard", "n_results": 3})
    results.append(test(
        "from_route_plan('standard') has expected min_similarity",
        cfg_std.min_similarity == RAGConfig.STANDARD_MIN_SIMILARITY,
        f"min_similarity={cfg_std.min_similarity}",
    ))

    # ─── 2. Skip Retrieval ───
    print("\n-- 2. Skip Retrieval Execution --")
    rag = get_adaptive_rag()
    issue_data = {
        "title": "Bug in login",
        "body": "Crash on login",
    }
    res_skip = rag.retrieve("octocat", "Hello-World", issue_data, config=cfg_skip)
    results.append(test(
        "Skip strategy returns 0 similar issues",
        len(res_skip.similar_issues) == 0,
        f"count={len(res_skip.similar_issues)}",
    ))
    results.append(test(
        "Skip strategy metadata['strategy'] is 'skip'",
        res_skip.metadata.get("strategy") == "skip",
        f"strategy={res_skip.metadata.get('strategy')}",
    ))

    # ─── 3. RAGResult Serialization ───
    print("\n-- 3. RAGResult Serialization --")
    d = res_skip.to_dict()
    results.append(test("RAGResult to_dict contains similar_issues", "similar_issues" in d))
    results.append(test("RAGResult to_dict contains metadata", "metadata" in d))

    # ─── 4. Graceful Retrieval on Missing / Empty Repo ───
    print("\n-- 4. Graceful Retrieval --")
    cfg_minimal = RAGConfig.from_route_plan({"mode": "minimal", "n_results": 1})
    res_min = rag.retrieve("nonexistent", "no_repo_12345", issue_data, config=cfg_minimal)
    results.append(test(
        "Retrieval on empty/unindexed repo returns RAGResult without crashing",
        isinstance(res_min, RAGResult),
        f"metadata_strategy={res_min.metadata.get('strategy')}",
    ))

    # ─── Summary ───
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'='*60}")
    print(f"ADAPTIVE RAG TEST SUMMARY: {passed}/{total} passed")
    print(f"{'='*60}")
    if passed < total:
        sys.exit(1)


if __name__ == "__main__":
    main()
