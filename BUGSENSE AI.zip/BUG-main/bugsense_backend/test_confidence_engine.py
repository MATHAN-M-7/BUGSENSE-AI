"""
Automated tests for Confidence Engine in BugSense Backend.

Tests:
1. Unit: Evaluate high-confidence payload -> READY_FOR_PR status.
2. Unit: Evaluate moderate-confidence payload -> REQUIRES_HUMAN_REVIEW status.
3. Unit: Evaluate aborted/gated payload -> ABORTED status.
4. Unit: Penalties applied for unsupported evidence or high complexity.
5. API: POST /analysis/evaluate-confidence endpoint validation.
"""

import sys
import httpx
from services.confidence_engine import (
    ConfidenceEngine,
    ConfidenceReport,
    SystemStatus,
    get_confidence_engine,
)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Confidence Engine")
    print(f"{'='*60}")

    results = []

    engine = get_confidence_engine()

    # ─── 1. Unit: High Confidence -> READY_FOR_PR ───
    print("\n-- 1. Unit: High Confidence Evaluation --")
    high_payload = {
        "status": "completed",
        "classification": {"confidence": 0.95},
        "root_cause": {"confidence": 0.92},
        "resolution": {"confidence": 0.94},
        "evidence_report": {
            "evidence_score": 0.90,
            "verdict": "STRONG",
        },
        "rag_retrieval": {
            "avg_similarity": 0.88,
        },
        "route_plan": {
            "complexity_score": 0.20,
        },
    }
    rep_high = engine.evaluate(high_payload)
    results.append(test(
        "High confidence produces system_confidence >= 0.80",
        rep_high.system_confidence >= 0.80,
        f"score={rep_high.system_confidence}",
    ))
    results.append(test(
        "High confidence produces READY_FOR_PR status",
        rep_high.system_status == SystemStatus.READY_FOR_PR.value,
        f"status={rep_high.system_status}",
    ))
    results.append(test(
        "Contributing factors contain expected signals",
        "llm_self_confidence" in rep_high.contributing_factors and "evidence_score" in rep_high.contributing_factors,
    ))

    # ─── 2. Unit: Moderate Confidence -> REQUIRES_HUMAN_REVIEW ───
    print("\n-- 2. Unit: Moderate Confidence Evaluation --")
    mod_payload = {
        "status": "completed",
        "classification": {"confidence": 0.70},
        "root_cause": {"confidence": 0.65},
        "resolution": {"confidence": 0.60},
        "evidence_report": {
            "evidence_score": 0.50,
            "verdict": "MODERATE",
        },
        "rag_retrieval": {
            "avg_similarity": 0.40,
        },
        "route_plan": {
            "complexity_score": 0.50,
        },
    }
    rep_mod = engine.evaluate(mod_payload)
    results.append(test(
        "Moderate confidence produces REQUIRES_HUMAN_REVIEW status",
        rep_mod.system_status == SystemStatus.REQUIRES_HUMAN_REVIEW.value,
        f"status={rep_mod.system_status}",
    ))

    # ─── 3. Unit: Aborted Payload ───
    print("\n-- 3. Unit: Aborted / Early Exit Evaluation --")
    abort_payload = {
        "status": "gated_early_exit",
    }
    rep_abort = engine.evaluate(abort_payload)
    results.append(test(
        "Early exit produces ABORTED status",
        rep_abort.system_status == SystemStatus.ABORTED.value,
        f"status={rep_abort.system_status}",
    ))
    results.append(test(
        "Early exit has 0.0 system_confidence",
        rep_abort.system_confidence == 0.0,
    ))

    # ─── 4. API Endpoint: POST /analysis/evaluate-confidence ───
    print("\n-- 4. API Endpoint: POST /analysis/evaluate-confidence --")
    try:
        r = httpx.post(f"{BASE}/analysis/evaluate-confidence", json=high_payload, timeout=10.0)
        results.append(test("POST /analysis/evaluate-confidence returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test("API returns system_confidence", "system_confidence" in data))
            results.append(test("API returns system_status", data.get("system_status") in ("READY_FOR_PR", "REQUIRES_HUMAN_REVIEW", "LOW_CONFIDENCE", "ABORTED")))
            results.append(test("API returns contributing_factors", isinstance(data.get("contributing_factors"), dict)))
    except Exception as e:
        results.append(test("API endpoint check failed", False, str(e)))

    # ─── Summary ───
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'='*60}")
    print(f"CONFIDENCE ENGINE TEST SUMMARY: {passed}/{total} passed")
    print(f"{'='*60}")
    if passed < total:
        sys.exit(1)


if __name__ == "__main__":
    main()
