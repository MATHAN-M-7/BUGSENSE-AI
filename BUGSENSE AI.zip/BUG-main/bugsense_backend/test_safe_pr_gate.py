import httpx
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)

# ──────────────────────────────────────────────
# Test Configuration & Helpers
# ──────────────────────────────────────────────

BASE = "http://localhost:8000"
passed = 0
failed = 0

def ok(name, details=""):
    global passed
    passed += 1
    d = f" -- {details}" if details else ""
    print(f"  [PASS] {name}{d}")

def fail(name, details=""):
    global failed
    failed += 1
    d = f" -- {details}" if details else ""
    print(f"  [FAIL] {name}{d}")

# ──────────────────────────────────────────────
# Tests
# ──────────────────────────────────────────────

def test_gate_rejects_low_confidence():
    payload = {
        "system_confidence_report": {
            "system_status": "LOW_CONFIDENCE",
            "system_confidence": 0.35,
        },
        "resolution": {
            "code_suggestions": [{"file_or_component": "test", "code_snippet": "test", "change_description": "test"}]
        }
    }
    r = client.post("/github/repos/testowner/testrepo/issues/1/generate-pr", json=payload)
    if r.status_code == 403:
        ok("Gate rejected LOW_CONFIDENCE")
    else:
        fail("Gate rejected LOW_CONFIDENCE", f"status={r.status_code}")

def test_gate_rejects_human_review():
    payload = {
        "system_confidence_report": {
            "system_status": "REQUIRES_HUMAN_REVIEW",
            "system_confidence": 0.70,
        },
        "resolution": {
            "code_suggestions": [{"file_or_component": "test", "code_snippet": "test", "change_description": "test"}]
        }
    }
    r = client.post("/github/repos/testowner/testrepo/issues/1/generate-pr", json=payload)
    if r.status_code == 403:
        ok("Gate rejected REQUIRES_HUMAN_REVIEW")
    else:
        fail("Gate rejected REQUIRES_HUMAN_REVIEW", f"status={r.status_code}")

def test_gate_rejects_no_code_suggestions():
    payload = {
        "system_confidence_report": {
            "system_status": "READY_FOR_PR",
            "system_confidence": 0.90,
        },
        "resolution": {
            "code_suggestions": []
        }
    }
    r = client.post("/github/repos/testowner/testrepo/issues/1/generate-pr", json=payload)
    if r.status_code == 400:
        ok("Gate rejected missing code suggestions")
    else:
        fail("Gate rejected missing code suggestions", f"status={r.status_code}")

def test_gate_allows_human_approved_review():
    payload = {
        "system_confidence_report": {
            "system_status": "REQUIRES_HUMAN_REVIEW",
            "system_confidence": 0.70,
        },
        "resolution": {
            "code_suggestions": [{"file_or_component": "test", "code_snippet": "test", "change_description": "test"}]
        }
    }
    # With human_approved=true, it should bypass the 403 gate check (may fail on GitHub API call with 500/etc, but not 403)
    r = client.post("/github/repos/testowner/testrepo/issues/1/generate-pr?human_approved=true", json=payload)
    if r.status_code != 403:
        ok("Gate passed REQUIRES_HUMAN_REVIEW with human_approved=true", f"status={r.status_code}")
    else:
        fail("Gate should pass REQUIRES_HUMAN_REVIEW with human_approved=true", f"status={r.status_code}")

def test_api_version():
    r = client.get("/health")
    v = r.json().get("version")
    if v == "0.18.0":
        ok("Version is 0.18.0")
    else:
        fail("Version check", f"Expected 0.18.0, got {v}")

if __name__ == "__main__":
    print("============================================================")
    print("  BugSense AI -- Phase 4: Safe PR Gate Tests")
    print("============================================================")
    
    test_api_version()
    test_gate_rejects_low_confidence()
    test_gate_rejects_human_review()
    test_gate_allows_human_approved_review()
    test_gate_rejects_no_code_suggestions()
    
    print("\n============================================================")
    print(f"  Results: {passed} passed, {failed} failed, 0 skipped")
    print("============================================================")
    
    if failed > 0:
        exit(1)
