import asyncio
from services.vector_store import VectorStore

def test_tenant_isolation():
    store = VectorStore(backend="chroma_local")
    # Clean up first
    user_a = 1234
    user_b = 5678
    owner = "testowner"
    repo = "testrepo"
    
    # User A indexes an issue
    doc_a = store.upsert_issue(
        repo_owner=owner,
        repo_name=repo,
        issue_number=1,
        text="User A issue about database crash",
        github_user_id=user_a,
    )
    
    # User B indexes an issue
    doc_b = store.upsert_issue(
        repo_owner=owner,
        repo_name=repo,
        issue_number=2,
        text="User B issue about UI glitch",
        github_user_id=user_b,
    )
    
    # User A searches
    results_a = store.search_similar(owner, repo, "crash", github_user_id=user_a)
    assert len(results_a) > 0
    assert results_a[0]["id"] == f"{owner}_{repo}_1"
    
    # User B searches
    results_b = store.search_similar(owner, repo, "glitch", github_user_id=user_b)
    assert len(results_b) > 0
    assert results_b[0]["id"] == f"{owner}_{repo}_2"
    
    # User A searches for User B's issue
    results_a_glitch = store.search_similar(owner, repo, "glitch", github_user_id=user_a)
    if len(results_a_glitch) > 0:
        # Distance should be higher (less similar) or it shouldn't be doc_b
        assert results_a_glitch[0]["id"] != f"{owner}_{repo}_2"
    
    print("Tenant isolation test passed!")

if __name__ == "__main__":
    test_tenant_isolation()
