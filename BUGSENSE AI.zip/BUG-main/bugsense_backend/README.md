# ⚙️ BugSense AI — FastAPI Backend

The intelligence server for **BugSense AI**, providing multi-agent issue analysis, semantic code retrieval (RAG via ChromaDB), deterministic evidence validation, and GitHub PR gating.

---

## 🚀 Quick Start

### 1. Environment Setup
```bash
python -m venv .venv

# Windows (PowerShell)
.\.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Configuration
Copy `.env.example` to `.env` and provide your API keys:
```bash
cp .env.example .env
```
Key variables:
- `GEMINI_API_KEY`: Google Gemini API key
- `GEMINI_MODEL`: e.g. `gemini-3.1-flash-lite` or `gemini-2.5-flash`
- `GITHUB_TOKEN`: Personal Access Token with `repo` and `read:user`
- `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET`: For OAuth flow
- `CHROMA_PERSIST_DIR`: Local ChromaDB vector database directory (default: `./chroma_data`)

### 3. Run Server
```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive API docs available at: `http://localhost:8000/docs`

---

## 🧪 Running Tests

Execute unit and integration tests:
```bash
pytest
```

For comprehensive project documentation, refer to the [Root README](../README.md).
