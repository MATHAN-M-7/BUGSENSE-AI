"""
Test: Analysis Token Propagation Fix

Verifies:
1. /health endpoint works
2. Session store creates/resolves/deletes sessions
3. Analysis endpoints accept Authorization header (static + runtime check)
4. require_auth resolves session tokens correctly
"""
import httpx
import asyncio
import sys
import os

# Ensure project is on path
sys.path.insert(0, os.path.dirname(__file__))

async def test_health():
    """Test 1: Backend health check."""
    print("\n=== TEST 1: Health Check ===")
    async with httpx.AsyncClient() as client:
        r = await client.get("http://127.0.0.1:8000/health")
        print(f"Status: {r.status_code}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}"
        data = r.json()
        print(f"Version: {data.get('version')}")
        assert data.get("status") == "ok"
        print("PASS")


def test_session_store():
    """Test 2: Session store unit behavior."""
    print("\n=== TEST 2: Session Store Unit Test ===")
    from services import session_store

    # Create a test session
    test_token = session_store.create_session(
        github_user_id=999999,
        github_login="test_user_token_propagation",
        github_access_token="gho_FAKE_TEST_TOKEN_12345",
        github_avatar_url="",
        github_name="Test User",
        ttl_seconds=60,
    )
    print(f"Created session: {test_token[:8]}...")
    assert test_token and len(test_token) > 20, "Session token too short"

    # Look up session
    session = session_store.get_session(test_token)
    assert session is not None, "Session lookup returned None"
    assert session["github_login"] == "test_user_token_propagation"
    assert session["github_user_id"] == 999999
    print(f"Session lookup OK: login={session['github_login']}")

    # Resolve to GitHub token
    gh_token = session_store.get_github_token_for_session(test_token)
    assert gh_token == "gho_FAKE_TEST_TOKEN_12345", f"Expected fake token, got {gh_token}"
    print(f"Token resolution OK: resolved to correct GitHub token")

    # Non-existent session
    bad = session_store.get_github_token_for_session("nonexistent_session_id")
    assert bad is None, "Expected None for non-existent session"
    print("Non-existent session returns None: OK")

    # Delete session
    deleted = session_store.delete_session(test_token)
    assert deleted, "Session delete returned False"
    after = session_store.get_session(test_token)
    assert after is None, "Session still exists after delete"
    print("Session deletion OK")

    print("PASS")


def test_extract_token():
    """Test 3: require_auth Resolution ==="""
    print("\n=== TEST 3: require_auth Resolution ===")
    from services import session_store
    from services.auth_guard import require_auth

    # Create a test session
    test_token = session_store.create_session(
        github_user_id=888888,
        github_login="extract_test_user",
        github_access_token="gho_EXTRACT_TEST_42",
        ttl_seconds=60,
    )

    # Case 1: Valid BugSense session token -> should resolve to GitHub token
    result = require_auth(f"Bearer {test_token}")
    assert result.github_token == "gho_EXTRACT_TEST_42", f"Expected GitHub token, got {result.github_token}"
    print("Session token resolution: OK")

    from fastapi import HTTPException
    
    # Case 2: No header -> 401
    try:
        require_auth(None)
        assert False, "Should have raised 401"
    except HTTPException as e:
        assert e.status_code == 401
    print("No header -> 401: OK")

    # Case 3: Empty bearer -> 401
    try:
        require_auth("Bearer ")
        assert False, "Should have raised 401"
    except HTTPException as e:
        assert e.status_code == 401
    print("Empty bearer -> 401: OK")

    # Case 4: Non-bearer -> 401
    try:
        require_auth("Basic dXNlcjpwYXNz")
        assert False, "Should have raised 401"
    except HTTPException as e:
        assert e.status_code == 401
    print("Non-bearer -> 401: OK")

    # Cleanup
    session_store.delete_session(test_token)

    print("PASS")


async def test_analysis_endpoints_accept_auth():
    """Test 4: All analysis endpoints accept Authorization header without error."""
    print("\n=== TEST 4: Analysis Endpoints Accept Authorization ===")
    
    from services import session_store
    test_token = session_store.create_session(
        github_user_id=777777,
        github_login="endpoint_test_user",
        github_access_token="gho_ENDPOINT_TEST_99",
        ttl_seconds=60,
    )
    
    headers = {
        "Authorization": f"Bearer {test_token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    
    # Minimal valid payload for analysis endpoints
    payload = {
        "repo_owner": "test",
        "repo_name": "test",
        "title": "test issue",
        "body": "test body",
    }
    
    endpoints = [
        "/analysis/classify",
        "/analysis/classify-rag",
        "/analysis/root-cause",
        "/analysis/resolve",
        "/analysis/complexity",
        "/analysis/route/plan",
        "/analysis/route",
    ]
    
    async with httpx.AsyncClient(timeout=5.0) as client:
        for ep in endpoints:
            try:
                r = await client.post(f"http://127.0.0.1:8000{ep}", json=payload, headers=headers)
                # We expect either success or a downstream error (503 for missing Gemini key,
                # 500 for network issues) -- but NOT 422 (validation error) which would mean
                # the endpoint rejected the Authorization header.
                assert r.status_code != 422, f"{ep}: Got 422 -- Authorization header not accepted!"
                print(f"  {ep}: status={r.status_code} (Authorization accepted)")
            except httpx.TimeoutException:
                print(f"  {ep}: TIMEOUT (endpoint exists, header accepted)")
            except Exception as e:
                print(f"  {ep}: Connection error: {e}")
    
    # Cleanup
    session_store.delete_session(test_token)
    print("PASS")


def test_static_inspection():
    """Test 5: Static inspection that every analysis endpoint has authorization parameter."""
    print("\n=== TEST 5: Static Code Inspection ===")
    import ast

    with open("routers/analysis.py", "r") as f:
        source = f.read()
    
    tree = ast.parse(source)

    # Find all async function definitions that are endpoint handlers
    endpoint_funcs = [
        "classify_issue",
        "classify_issue_rag", 
        "root_cause_analysis",
        "resolve_issue",
        "analyze_issue_complexity",
        "plan_adaptive_route",
        "execute_adaptive_route",
    ]
    
    all_ok = True
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name in endpoint_funcs:
            arg_names = [a.arg for a in node.args.args]
            has_auth = "authorization" in arg_names
            
            # Check if require_auth is called in the function body
            calls_require = False
            for child in ast.walk(node):
                if isinstance(child, ast.Call):
                    if isinstance(child.func, ast.Name) and child.func.id == "require_auth":
                        calls_require = True
                    elif isinstance(child.func, ast.Attribute) and child.func.attr == "require_auth":
                        calls_require = True
            
            status = "OK" if (has_auth and calls_require) else "FAIL"
            if status == "FAIL":
                all_ok = False
            print(f"  {node.name}: authorization={has_auth}, calls_require_auth={calls_require} -> {status}")
    
    assert all_ok, "Some endpoints missing authorization or require_auth!"
    print("PASS")


async def main():
    print("=" * 60)
    print("TOKEN PROPAGATION FIX -- VERIFICATION TESTS")
    print("=" * 60)

    try:
        await test_health()
    except Exception as e:
        print(f"FAIL: {e}")
        return

    try:
        test_session_store()
    except Exception as e:
        print(f"FAIL: {e}")
        return

    try:
        test_extract_token()
    except Exception as e:
        print(f"FAIL: {e}")
        return

    try:
        await test_analysis_endpoints_accept_auth()
    except Exception as e:
        print(f"FAIL: {e}")
        return

    try:
        test_static_inspection()
    except Exception as e:
        print(f"FAIL: {e}")
        return

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
