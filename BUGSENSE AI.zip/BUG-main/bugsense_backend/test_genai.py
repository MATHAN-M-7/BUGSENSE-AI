from pydantic import BaseModel
from google import genai
from google.genai import types

class MyModel(BaseModel):
    foo: str

print(types.InteractionConfig.model_fields.keys())
