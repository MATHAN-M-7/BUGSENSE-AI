"""
LLM Provider abstraction and Gemini implementation.

Provides a clean interface for AI model interactions, allowing
easy swapping between LLM backends (Gemini, OpenAI, etc.).
"""

from __future__ import annotations

import enum
import logging
from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

from config import get_gemini_api_key, get_gemini_model

logger = logging.getLogger("bugsense.llm")


# ──────────────────────────────────────────────
# Structured output models
# ──────────────────────────────────────────────

class IssueCategory(str, enum.Enum):
    BUG = "Bug"
    FEATURE = "Feature"
    ENHANCEMENT = "Enhancement"
    DOCUMENTATION = "Documentation"
    OTHER = "Other"


class IssueSeverity(str, enum.Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class IssueClassification(BaseModel):
    """Structured output schema for issue classification."""
    category: IssueCategory = Field(description="The category of this GitHub issue.")
    severity: IssueSeverity = Field(description="The severity level of this issue.")
    category_confidence: float = Field(
        description="Confidence score for the category classification (0.0 to 1.0).",
        ge=0.0,
        le=1.0,
    )
    severity_confidence: float = Field(
        description="Confidence score for the severity classification (0.0 to 1.0).",
        ge=0.0,
        le=1.0,
    )
    evidence_summary: str = Field(
        description="A concise 1-3 sentence summary explaining the classification rationale."
    )


class RootCauseAnalysis(BaseModel):
    """Structured output schema for root cause analysis."""
    probable_cause: str = Field(
        description="Concise description of the most likely root cause of this issue."
    )
    affected_components: list[str] = Field(
        description="List of software components, modules, or subsystems likely involved."
    )
    reproduction_steps: list[str] = Field(
        description="Ordered steps to reproduce the issue, if inferable from the report."
    )
    investigation_areas: list[str] = Field(
        description="Recommended areas or files to investigate for a fix."
    )
    confidence: float = Field(
        description="Overall confidence in the root cause analysis (0.0 to 1.0).",
        ge=0.0,
        le=1.0,
    )
    related_patterns: str = Field(
        description="Patterns observed across similar issues that support this analysis."
    )
    analysis_summary: str = Field(
        description="A 2-4 sentence overall summary of the root cause analysis."
    )


class EffortLevel(str, enum.Enum):
    TRIVIAL = "Trivial"
    SMALL = "Small"
    MEDIUM = "Medium"
    LARGE = "Large"
    UNKNOWN = "Unknown"


class CodeSuggestion(BaseModel):
    """A single code-level fix suggestion."""
    file_or_component: str = Field(
        description="The file, module, or component where the change should be made."
    )
    change_description: str = Field(
        description="Plain-language description of what to change."
    )
    code_snippet: str = Field(
        description="Pseudocode or code pattern showing the fix (not a full file)."
    )


class ResolutionSuggestion(BaseModel):
    """Structured output schema for fix/resolution suggestions."""
    fix_description: str = Field(
        description="Plain-language description of the recommended fix."
    )
    code_suggestions: list[CodeSuggestion] = Field(
        description="List of specific code-level changes to implement the fix."
    )
    implementation_strategy: list[str] = Field(
        description="Step-by-step implementation plan in order of execution."
    )
    testing_recommendations: list[str] = Field(
        description="How to verify the fix works (unit tests, integration tests, manual checks)."
    )
    risk_assessment: str = Field(
        description="Potential risks, side effects, or regressions the fix may introduce."
    )
    estimated_effort: EffortLevel = Field(
        description="Estimated effort level for the fix."
    )
    confidence: float = Field(
        description="Confidence in the resolution suggestion (0.0 to 1.0).",
        ge=0.0,
        le=1.0,
    )
    resolution_summary: str = Field(
        description="A 2-4 sentence overall summary of the fix recommendation."
    )


# ──────────────────────────────────────────────
# Abstract base class
# ──────────────────────────────────────────────

class LLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def classify_issue(self, issue_text: str) -> IssueClassification:
        """Classify a GitHub issue from its text representation."""
        ...

    @abstractmethod
    async def classify_issue_with_context(
        self, issue_text: str, similar_issues: list[dict[str, Any]]
    ) -> IssueClassification:
        """Classify a GitHub issue using RAG context from similar past issues."""
        ...

    @abstractmethod
    async def analyze_root_cause(
        self, issue_text: str, similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
    ) -> RootCauseAnalysis:
        """Perform root cause analysis on a GitHub issue."""
        ...

    @abstractmethod
    async def generate_resolution(
        self, issue_text: str, similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
        root_cause: dict[str, Any] | None = None,
    ) -> ResolutionSuggestion:
        """Generate fix suggestions for a GitHub issue."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return the model identifier being used."""
        ...


# ──────────────────────────────────────────────
# Gemini implementation
# ──────────────────────────────────────────────

_shared_genai_client = None

def get_shared_genai_client():
    global _shared_genai_client
    if _shared_genai_client is None:
        from google import genai
        api_key = get_gemini_api_key()
        _shared_genai_client = genai.Client(
            api_key=api_key,
            http_options={'timeout': 60000}
        )
    return _shared_genai_client

class GeminiProvider(LLMProvider):
    """Google Gemini API provider using the google-genai SDK."""

    def __init__(self):
        self._model = get_gemini_model()
        self._client = get_shared_genai_client()
        logger.info("GeminiProvider initialised with model=%s", self._model)

    @property
    def model_name(self) -> str:
        return self._model

    async def _create_interaction(self, **kwargs) -> Any:
        import asyncio
        import re
        max_retries = 4
        for attempt in range(max_retries):
            try:
                # Wrap in wait_for to guarantee backend returns before Flutter's 120s timeout
                return await asyncio.wait_for(
                    asyncio.to_thread(self._client.interactions.create, **kwargs),
                    timeout=75.0
                )
            except asyncio.TimeoutError:
                logger.error("Gemini network request timed out after 75s (backend-enforced).")
                if attempt == max_retries - 1:
                    raise RuntimeError("AI Provider Timeout: The request took too long to complete. Please try again.")
            except Exception as exc:
                exc_str = str(exc)
                is_rate_limit = any(k in exc_str.lower() for k in ("429", "quota", "too_many_requests", "resource_exhausted"))
                if is_rate_limit and attempt < max_retries - 1:
                    wait_time = 5.0 * (attempt + 1)
                    match = re.search(r"retry in ([0-9.]+)s", exc_str, re.IGNORECASE)
                    if match:
                        wait_time = min(float(match.group(1)) + 1.0, 60.0)
                    logger.warning("Gemini rate limit hit. Retrying in %.1fs (attempt %d/%d)...", wait_time, attempt + 1, max_retries)
                    await asyncio.sleep(wait_time)
                else:
                    logger.error("Gemini network or processing failure: %s", exc_str, exc_info=True)
                    # Include the exception type and string to trace the root cause.
                    raise RuntimeError(f"AI Provider Error: {type(exc).__name__}: {exc_str}")

    async def classify_issue(self, issue_text: str) -> IssueClassification:
        """
        Classify a GitHub issue using Gemini with structured output.

        Uses the Interactions API with Pydantic schema for guaranteed
        JSON conformance.
        """
        prompt = self._build_classification_prompt(issue_text)

        interaction = await self._create_interaction(
            model=self._model,
            input=prompt,
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": IssueClassification.model_json_schema(),
            },
        )

        # Parse the structured response
        result = IssueClassification.model_validate_json(interaction.output_text)
        logger.info(
            "Classification: category=%s (%.0f%%) severity=%s (%.0f%%)",
            result.category.value,
            result.category_confidence * 100,
            result.severity.value,
            result.severity_confidence * 100,
        )
        return result

    async def classify_issue_with_context(
        self, issue_text: str, similar_issues: list[dict[str, Any]]
    ) -> IssueClassification:
        """
        Classify a GitHub issue using RAG — similar past issues as few-shot context.
        """
        prompt = self._build_rag_prompt(issue_text, similar_issues)

        interaction = await self._create_interaction(
            model=self._model,
            input=prompt,
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": IssueClassification.model_json_schema(),
            },
        )

        result = IssueClassification.model_validate_json(interaction.output_text)
        logger.info(
            "RAG Classification: category=%s (%.0f%%) severity=%s (%.0f%%) context_issues=%d",
            result.category.value,
            result.category_confidence * 100,
            result.severity.value,
            result.severity_confidence * 100,
            len(similar_issues),
        )
        return result

    @staticmethod
    def _classification_rules() -> str:
        return """## Classification Rules

### Categories:
- **Bug**: Something is broken, not working as expected, causes errors or crashes.
- **Feature**: A request for new functionality that does not currently exist.
- **Enhancement**: An improvement to existing functionality (performance, UX, refactoring).
- **Documentation**: Issues related to docs, README, comments, guides, or missing documentation.
- **Other**: Anything that doesn't clearly fit the above (questions, discussions, meta).

### Severity:
- **Critical**: System crash, data loss, security vulnerability, complete feature failure, blocks all users.
- **High**: Major feature broken, significant performance degradation, affects many users, no workaround.
- **Medium**: Feature partially broken, has a workaround, moderate impact, affects some users.
- **Low**: Minor cosmetic issue, typo, nice-to-have improvement, minimal user impact.

### Confidence:
- Provide a confidence score between 0.0 and 1.0 for both category and severity.
- Use lower confidence (0.3-0.6) when the issue is ambiguous or lacks detail.
- Use higher confidence (0.7-1.0) when the classification is clearly supported by evidence.

### Evidence Summary:
- Provide a concise 1-3 sentence explanation of why you chose this classification.
- Reference specific keywords, phrases, or patterns from the issue text."""

    @staticmethod
    def _build_classification_prompt(issue_text: str) -> str:
        return f"""You are an expert software issue classifier for BugSense AI.

Analyze the following GitHub issue and classify it.

{GeminiProvider._classification_rules()}

## GitHub Issue to Classify:

{issue_text}"""

    @staticmethod
    def _build_rag_prompt(issue_text: str, similar_issues: list[dict[str, Any]]) -> str:
        # Format similar issues as few-shot context
        context_parts = []
        for i, issue in enumerate(similar_issues, 1):
            meta = issue.get("metadata", {})
            context_parts.append(
                f"### Example {i}\n"
                f"- **Title:** {meta.get('title', 'N/A')}\n"
                f"- **Category:** {meta.get('category', 'N/A')}\n"
                f"- **Severity:** {meta.get('severity', 'N/A')}\n"
                f"- **Similarity:** {issue.get('similarity', 0):.0%}\n"
                f"- **Text:** {issue.get('document', '')[:300]}"
            )
        context_block = "\n\n".join(context_parts)

        return f"""You are an expert software issue classifier for BugSense AI.

Analyze the following GitHub issue and classify it.

{GeminiProvider._classification_rules()}

## Similar Past Issues (for reference)

The following are previously classified issues from the same repository that are semantically similar to the current issue. Use them as reference examples to inform your classification, but classify the current issue independently based on its own content.

{context_block}

## GitHub Issue to Classify:

{issue_text}"""

    async def analyze_root_cause(
        self, issue_text: str, similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
    ) -> RootCauseAnalysis:
        """
        Perform root cause analysis on a GitHub issue.
        """
        prompt = self._build_root_cause_prompt(issue_text, similar_issues, classification)

        interaction = await self._create_interaction(
            model=self._model,
            input=prompt,
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": RootCauseAnalysis.model_json_schema(),
            },
        )

        result = RootCauseAnalysis.model_validate_json(interaction.output_text)
        logger.info(
            "Root cause analysis: confidence=%.0f%% components=%d investigation_areas=%d",
            result.confidence * 100,
            len(result.affected_components),
            len(result.investigation_areas),
        )
        return result

    @staticmethod
    def _build_root_cause_prompt(
        issue_text: str,
        similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
    ) -> str:
        # Classification context
        class_block = ""
        if classification:
            class_block = f"""\n## Prior Classification\n- **Category:** {classification.get('category', 'N/A')}
- **Severity:** {classification.get('severity', 'N/A')}
- **Evidence:** {classification.get('evidence_summary', 'N/A')}\n"""

        # Similar issues context
        context_parts = []
        for i, issue in enumerate(similar_issues, 1):
            meta = issue.get("metadata", {})
            context_parts.append(
                f"### Similar Issue {i}\n"
                f"- **Title:** {meta.get('title', 'N/A')}\n"
                f"- **Category:** {meta.get('category', 'N/A')}\n"
                f"- **Severity:** {meta.get('severity', 'N/A')}\n"
                f"- **Similarity:** {issue.get('similarity', 0):.0%}\n"
                f"- **Text:** {issue.get('document', '')[:300]}"
            )
        context_block = "\n\n".join(context_parts) if context_parts else "No similar issues found."

        return f"""You are an expert software engineer performing root cause analysis for BugSense AI.

Analyze the following GitHub issue and determine the most probable root cause.

## Analysis Guidelines

### Probable Cause:
- Identify the most likely technical root cause based on the issue description.
- Be specific: name the likely failing component, logic error, race condition, missing validation, etc.
- If the issue lacks technical detail, provide the best inference based on symptoms.

### Affected Components:
- List the software components, modules, files, or subsystems likely involved.
- Use general names if specific file names aren't mentioned (e.g., "Authentication Module", "Database Connection Pool").

### Reproduction Steps:
- Provide ordered steps to reproduce the issue if they can be inferred.
- If reproduction steps cannot be determined, provide a single entry: "Insufficient information to determine reproduction steps."

### Investigation Areas:
- Recommend specific areas, patterns, or files to investigate for a fix.
- Be actionable: "Check null handling in user authentication flow" is better than "Look at the code."

### Confidence:
- Provide a confidence score between 0.0 and 1.0.
- Use lower confidence (0.2-0.5) when the issue is vague or lacks technical detail.
- Use higher confidence (0.6-0.9) when error messages, stack traces, or specific symptoms are provided.

### Related Patterns:
- Note any patterns from similar past issues that support your analysis.
- If no similar issues are available, state "No similar issues available for pattern analysis."

### Analysis Summary:
- Provide a 2-4 sentence summary tying together the probable cause, impact, and recommended next steps.
{class_block}
## Similar Past Issues (for context)

{context_block}

## GitHub Issue to Analyze:

{issue_text}"""

    async def generate_resolution(
        self, issue_text: str, similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
        root_cause: dict[str, Any] | None = None,
    ) -> ResolutionSuggestion:
        """
        Generate fix suggestions for a GitHub issue.
        """
        prompt = self._build_resolution_prompt(
            issue_text, similar_issues, classification, root_cause
        )

        interaction = await self._create_interaction(
            model=self._model,
            input=prompt,
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": ResolutionSuggestion.model_json_schema(),
            },
        )

        result = ResolutionSuggestion.model_validate_json(interaction.output_text)
        logger.info(
            "Resolution: effort=%s confidence=%.0f%% suggestions=%d",
            result.estimated_effort.value,
            result.confidence * 100,
            len(result.code_suggestions),
        )
        return result

    @staticmethod
    def _build_resolution_prompt(
        issue_text: str,
        similar_issues: list[dict[str, Any]],
        classification: dict[str, Any] | None = None,
        root_cause: dict[str, Any] | None = None,
    ) -> str:
        # Prior classification context
        class_block = ""
        if classification:
            class_block = f"""\n## Prior Classification\n- **Category:** {classification.get('category', 'N/A')}
- **Severity:** {classification.get('severity', 'N/A')}
- **Evidence:** {classification.get('evidence_summary', 'N/A')}\n"""

        # Root cause context
        rca_block = ""
        if root_cause:
            components = ", ".join(root_cause.get("affected_components", []))
            areas = "; ".join(root_cause.get("investigation_areas", []))
            rca_block = f"""\n## Root Cause Analysis\n- **Probable Cause:** {root_cause.get('probable_cause', 'N/A')}
- **Affected Components:** {components or 'N/A'}
- **Investigation Areas:** {areas or 'N/A'}
- **Analysis Summary:** {root_cause.get('analysis_summary', 'N/A')}\n"""

        # Similar issues context
        context_parts = []
        for i, issue in enumerate(similar_issues, 1):
            meta = issue.get("metadata", {})
            context_parts.append(
                f"### Similar Issue {i}\n"
                f"- **Title:** {meta.get('title', 'N/A')}\n"
                f"- **Category:** {meta.get('category', 'N/A')}\n"
                f"- **Severity:** {meta.get('severity', 'N/A')}\n"
                f"- **Similarity:** {issue.get('similarity', 0):.0%}\n"
                f"- **Text:** {issue.get('document', '')[:300]}"
            )
        context_block = "\n\n".join(context_parts) if context_parts else "No similar issues found."

        return f"""You are an expert software engineer generating fix recommendations for BugSense AI.

Analyze the following GitHub issue and generate actionable fix suggestions.

## Fix Generation Guidelines

### Fix Description:
- Provide a clear, plain-language description of the recommended fix.
- Be specific about what needs to change and why.

### Code Suggestions:
- Provide specific code-level changes needed to fix the issue.
- For each suggestion, specify the file/component, what to change, and a code snippet.
- Code snippets should be pseudocode or language-appropriate patterns, not full files.
- Focus on the minimal change needed to fix the issue correctly.

### Implementation Strategy:
- Provide a step-by-step plan for implementing the fix.
- Order steps logically (dependencies first, then the actual fix, then cleanup).
- Include any migration or deployment considerations.

### Testing Recommendations:
- Specify unit tests, integration tests, or manual verification steps.
- Be specific: "Add a unit test for email addresses containing '+' character" is better than "Add tests."

### Risk Assessment:
- Identify potential side effects, regressions, or breaking changes.
- If the fix is low-risk, state that explicitly with reasoning.

### Estimated Effort:
- **Trivial**: Less than 30 minutes, simple one-line fix.
- **Small**: 1-4 hours, a few files changed.
- **Medium**: 1-2 days, moderate complexity.
- **Large**: 3+ days, significant refactoring or multiple subsystems.
- **Unknown**: Insufficient information to estimate.

### Confidence:
- Provide a confidence score between 0.0 and 1.0.
- Use lower confidence (0.2-0.5) when the issue is vague or the fix is speculative.
- Use higher confidence (0.6-0.9) when the root cause is clear and the fix is straightforward.
{class_block}{rca_block}
## Similar Past Issues (for context)

{context_block}

## GitHub Issue to Fix:

{issue_text}"""


# ──────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────

_provider_instance: LLMProvider | None = None


def get_llm_provider() -> LLMProvider:
    """Return the configured LLM provider (singleton)."""
    global _provider_instance
    if _provider_instance is None:
        _provider_instance = GeminiProvider()
    return _provider_instance


def reset_provider() -> None:
    """Reset the singleton (for testing)."""
    global _provider_instance
    _provider_instance = None
