"""
Redis client management for distributed OAuth ephemeral state.
"""

from __future__ import annotations

from typing import Any
import redis

from config import get_redis_url

_client: Any | None = None
_pool: redis.ConnectionPool | None = None


def get_redis_client() -> Any:
    """
    Return a thread-safe Redis client instance backed by a connection pool.
    """
    global _client, _pool
    if _client is not None:
        return _client

    if _pool is None:
        _pool = redis.ConnectionPool.from_url(
            get_redis_url(),
            decode_responses=True,
            socket_connect_timeout=2.0,
            socket_timeout=2.0,
        )
    return redis.Redis(connection_pool=_pool)


def set_redis_client(client: Any | None) -> None:
    """
    Override the Redis client (used for testing or dependency injection).
    """
    global _client
    _client = client


def reset_redis_client() -> None:
    """Reset the client and connection pool."""
    global _client, _pool
    _client = None
    if _pool is not None:
        try:
            _pool.disconnect()
        except Exception:
            pass
        _pool = None
