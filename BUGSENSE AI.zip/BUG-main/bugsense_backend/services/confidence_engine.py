"""
Confidence Engine — Phase 4 Milestone 5.

Synthesizes multiple signals from the adaptive routing pipeline into
a single, unified System Confidence metric. This metric determines the
final 'system_status' (e.g. READY_FOR_PR) that powers the Safe PR Gate.

Inputs:
    - LLM Self-Reported Confidence (Classifier, Root Cause, Resolution)
    - Evidence Validation Score (Deterministic textual backing)
    - RAG Retrieval Similarity (Quality of contextual grounding)
    - Issue Complexity Score (Inverse difficulty proxy)
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger("bugsense.confidence_engine")


# ──────────────────────────────────────────────
# Enums & Data Classes
# ──────────────────────────────────────────────

class SystemStatus(str, Enum):
    """Overall status of the AI pipeline execution."""
    READY_FOR_PR = "READY_FOR_PR"              # Score >= 0.85
    REQUIRES_HUMAN_REVIEW = "REQUIRES_HUMAN_REVIEW"  # Score >= 0.50
    LOW_CONFIDENCE = "LOW_CONFIDENCE"          # Score < 0.50
    ABORTED = "ABORTED"                        # Pipeline halted early


@dataclass
class ConfidenceReport:
    """Unified system confidence report."""
    system_confidence: float
    system_status: str
    contributing_factors: dict[str, float]
    penalties_applied: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ──────────────────────────────────────────────
# Core Engine
# ──────────────────────────────────────────────

class ConfidenceEngine:
    """Evaluates multi-modal signals to compute aggregate system confidence."""

    # Default weights for the base aggregate score
    WEIGHT_LLM = 0.30
    WEIGHT_EVIDENCE = 0.40
    WEIGHT_RAG = 0.15
    WEIGHT_COMPLEXITY = 0.15

    # Status thresholds
    READY_THRESHOLD = 0.85
    REVIEW_THRESHOLD = 0.50

    def evaluate(self, routing_result: dict[str, Any]) -> ConfidenceReport:
        """Evaluate a completed adaptive routing payload."""

        # 1. Check for hard aborts (pipeline halted early)
        if routing_result.get("status") == "gated_early_exit":
            return ConfidenceReport(
                system_confidence=0.0,
                system_status=SystemStatus.ABORTED.value,
                contributing_factors={},
                penalties_applied=["Pipeline aborted by confidence gate."],
            )

        factors: dict[str, float] = {}
        penalties: list[str] = []

        # 2. Extract LLM Self-Confidence (Average across executed agents)
        llm_conf = self._extract_llm_confidence(routing_result)
        if llm_conf is not None:
            factors["llm_self_confidence"] = llm_conf

        # 3. Extract Evidence Score
        evidence = routing_result.get("evidence_report", {})
        evidence_score = evidence.get("evidence_score")
        if evidence_score is not None:
            factors["evidence_score"] = evidence_score

        # 4. Extract RAG Similarity
        rag = routing_result.get("rag_retrieval", {})
        rag_sim = rag.get("avg_similarity")
        # If RAG was skipped (mode=skip), we consider it neutral/N/A, not 0.0
        if rag_sim is not None and rag.get("strategy") != "skip":
            factors["rag_similarity"] = rag_sim

        # 5. Extract Issue Complexity
        plan = routing_result.get("route_plan", {})
        complexity = plan.get("complexity_score")
        if complexity is not None:
            # We want an INVERSE proxy for confidence: lower complexity = higher confidence
            factors["inverse_complexity"] = round(1.0 - complexity, 4)

        # 6. Compute Base Score (Dynamic re-weighting if signals are missing)
        base_score = self._compute_weighted_average(factors)

        # 7. Apply Penalties
        final_score = base_score

        # Heavy penalty if evidence is insufficient
        if evidence.get("verdict") == "INSUFFICIENT":
            final_score *= 0.50
            penalties.append("Heavy penalty: INSUFFICIENT evidence verdict.")
        elif evidence.get("verdict") == "WEAK":
            final_score *= 0.80
            penalties.append("Penalty: WEAK evidence verdict.")

        # Minor penalty for poor RAG quality
        if "rag_similarity" in factors and factors["rag_similarity"] < 0.15:
            final_score *= 0.90
            penalties.append("Penalty: Low RAG similarity.")

        final_score = round(max(0.0, min(1.0, final_score)), 4)

        # 8. Determine Status
        status = self._determine_status(final_score)

        return ConfidenceReport(
            system_confidence=final_score,
            system_status=status.value,
            contributing_factors=factors,
            penalties_applied=penalties,
        )

    # ──────────────────────────────────────────
    # Helper Methods
    # ──────────────────────────────────────────

    def _extract_llm_confidence(self, result: dict[str, Any]) -> float | None:
        """Calculate the mean self-reported confidence of all executed agents."""
        scores = []
        for key in ("classification", "root_cause", "resolution"):
            stage_data = result.get(key)
            if isinstance(stage_data, dict):
                val = stage_data.get("confidence")
                if val is not None:
                    try:
                        scores.append(float(val))
                    except (ValueError, TypeError):
                        pass

        if not scores:
            return None
        return round(sum(scores) / len(scores), 4)

    def _compute_weighted_average(self, factors: dict[str, float]) -> float:
        """Compute the aggregate score, dynamically re-weighting for missing signals."""
        if not factors:
            return 0.0

        # Define ideal weights
        weights = {
            "llm_self_confidence": self.WEIGHT_LLM,
            "evidence_score": self.WEIGHT_EVIDENCE,
            "rag_similarity": self.WEIGHT_RAG,
            "inverse_complexity": self.WEIGHT_COMPLEXITY,
        }

        # Calculate total weight of available signals
        total_weight = sum(weights[k] for k in factors if k in weights)

        if total_weight <= 0:
            # Fallback to simple average if unknown factors
            return sum(factors.values()) / len(factors)

        # Normalize weights so they sum to 1.0 across AVAILABLE factors
        normalized_weights = {
            k: (weights[k] / total_weight) for k in factors if k in weights
        }

        score = sum(factors[k] * normalized_weights[k] for k in normalized_weights)
        return round(score, 4)

    def _determine_status(self, score: float) -> SystemStatus:
        if score >= self.READY_THRESHOLD:
            return SystemStatus.READY_FOR_PR
        elif score >= self.REVIEW_THRESHOLD:
            return SystemStatus.REQUIRES_HUMAN_REVIEW
        else:
            return SystemStatus.LOW_CONFIDENCE


# ──────────────────────────────────────────────
# Singleton Factory
# ──────────────────────────────────────────────

_engine_instance: ConfidenceEngine | None = None


def get_confidence_engine() -> ConfidenceEngine:
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = ConfidenceEngine()
    return _engine_instance
