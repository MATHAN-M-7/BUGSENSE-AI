"""
Resolution Agent — generates fix suggestions for GitHub issues.

Orchestrates:
1. Formatting issue data into a prompt.
2. Retrieving similar issues from ChromaDB for context (RAG).
3. Calling the LLM provider for fix generation.
4. Persisting the suggestion to Firestore (if available).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from services.llm_provider import ResolutionSuggestion, get_llm_provider

logger = logging.getLogger("bugsense.resolution")


def _format_issue_text(issue_data: dict[str, Any]) -> str:
    """Format issue data into a text representation for the LLM."""
    parts = []

    title = issue_data.get("title", "")
    if title:
        parts.append(f"**Title:** {title}")

    body = issue_data.get("body") or ""
    if body:
        if len(body) > 4000:
            body = body[:4000] + "\n... [truncated]"
        parts.append(f"**Body:**\n{body}")

    state = issue_data.get("state", "")
    if state:
        parts.append(f"**State:** {state}")

    labels = issue_data.get("labels", [])
    if labels:
        if isinstance(labels[0], dict):
            label_names = [lbl.get("name", "") for lbl in labels]
        else:
            label_names = labels
        parts.append(f"**Labels:** {', '.join(label_names)}")

    comments = issue_data.get("comments_text", [])
    if comments:
        comments_str = "\n".join(f"- {c}" for c in comments[:5])
        parts.append(f"**Comments:**\n{comments_str}")

    return "\n\n".join(parts)


def _retrieve_similar_issues(
    repo_owner: str, repo_name: str, issue_text: str, n_results: int = 3, github_user_id: int | None = None
) -> list[dict[str, Any]]:
    """Retrieve similar issues from ChromaDB. Returns [] on failure."""
    if not repo_owner or not repo_name:
        return []
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        results = store.search_similar(
            repo_owner=repo_owner,
            repo_name=repo_name,
            query=issue_text,
            n_results=n_results,
            github_user_id=github_user_id,
        )
        logger.info("Retrieved %d similar issues from ChromaDB", len(results))
        return results
    except Exception as exc:
        logger.debug("ChromaDB retrieval failed: %s", exc)
        return []


async def generate_resolution(
    issue_data: dict[str, Any],
    classification: dict[str, Any] | None = None,
    root_cause: dict[str, Any] | None = None,
    similar_issues: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """
    Generate fix suggestions for a GitHub issue.

    Args:
        issue_data: Dict containing at minimum 'title' and optionally
                    'body', 'state', 'labels', 'comments_text',
                    'repo_owner', 'repo_name', 'issue_number'.
        classification: Optional prior classification result.
        root_cause: Optional prior root cause analysis result.

    Returns:
        Dict with fix suggestions, metadata, and rag_context.
    """
    provider = get_llm_provider()
    issue_text = _format_issue_text(issue_data)

    repo_owner = issue_data.get("repo_owner", "")
    repo_name = issue_data.get("repo_name", "")
    github_user_id = issue_data.get("_github_user_id")

    logger.info(
        "Generating resolution: %s/%s#%s '%s'",
        repo_owner,
        repo_name,
        issue_data.get("issue_number", "?"),
        issue_data.get("title", "")[:50],
    )

    # 1. Retrieve similar issues from ChromaDB if not provided
    if similar_issues is None:
        import asyncio
        try:
            similar_issues = await asyncio.wait_for(
                asyncio.to_thread(
                    _retrieve_similar_issues, repo_owner, repo_name, issue_text, 3, github_user_id
                ),
                timeout=75.0
            )
        except Exception as exc:
            logger.warning("Retrieval blocked or failed: %s", exc)
            similar_issues = []

    # 2. Call the LLM for resolution generation
    resolution: ResolutionSuggestion = await provider.generate_resolution(
        issue_text, similar_issues, classification, root_cause
    )

    # 3. Build the result
    now = datetime.now(timezone.utc).isoformat()
    result = {
        "repo_owner": repo_owner,
        "repo_name": repo_name,
        "issue_number": issue_data.get("issue_number"),
        "issue_title": issue_data.get("title", ""),
        "fix_description": resolution.fix_description,
        "code_suggestions": [
            {
                "file_or_component": cs.file_or_component,
                "change_description": cs.change_description,
                "explanation": cs.change_description,
                "code_snippet": cs.code_snippet,
            }
            for cs in resolution.code_suggestions
        ],
        "implementation_strategy": resolution.implementation_strategy,
        "testing_recommendations": resolution.testing_recommendations,
        "risk_assessment": resolution.risk_assessment,
        "estimated_effort": resolution.estimated_effort.value,
        "confidence": resolution.confidence,
        "resolution_summary": resolution.resolution_summary,
        "model": provider.model_name,
        "analyzed_at": now,
        "analyzed_by": "resolution_agent_v1",
        "rag_context": [
            {
                "issue_id": si.get("id", ""),
                "title": si.get("metadata", {}).get("title", ""),
                "category": si.get("metadata", {}).get("category", ""),
                "severity": si.get("metadata", {}).get("severity", ""),
                "similarity": si.get("similarity", 0),
            }
            for si in similar_issues
        ],
        "github_user_id": issue_data.get("_github_user_id"),
    }

    # Include prior context if provided
    if classification:
        result["prior_classification"] = {
            "category": classification.get("category", ""),
            "severity": classification.get("severity", ""),
        }
    if root_cause:
        result["prior_root_cause"] = {
            "probable_cause": root_cause.get("probable_cause", ""),
            "affected_components": root_cause.get("affected_components", []),
        }

    # Persist to Firestore (best-effort)
    doc_id = _try_persist(result)
    if doc_id:
        result["analysis_id"] = doc_id

    return result


def _try_persist(result: dict[str, Any]) -> str | None:
    """Best-effort persist resolution to Firestore. Returns doc ID or None."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        _, doc_ref = db.collection("resolution_suggestions").add(result)
        logger.info("Resolution persisted to Firestore: %s", doc_ref.id)
        return doc_ref.id
    except Exception as exc:
        logger.debug("Firestore persistence skipped: %s", exc)
        return None
