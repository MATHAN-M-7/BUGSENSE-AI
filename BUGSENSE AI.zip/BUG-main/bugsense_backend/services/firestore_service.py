"""
Firestore service layer.

Manages Firebase Admin SDK initialisation and provides CRUD operations
for the `bug_reports` and `users` collections.

The SDK is initialised lazily on first use. If the service account
credentials file is missing the caller receives a clear RuntimeError
instead of a cryptic crash.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import firebase_admin
from firebase_admin import credentials, firestore

from config import get_firebase_credentials_path, get_firebase_project_id

_app: firebase_admin.App | None = None


# ──────────────────────────────────────────────
# Initialisation
# ──────────────────────────────────────────────

def init_firestore() -> None:
    """
    Initialise the Firebase Admin SDK (idempotent).

    Raises RuntimeError if the service-account JSON file is missing.
    """
    global _app
    if _app is not None:
        return

    cred_path = get_firebase_credentials_path()
    if not os.path.isfile(cred_path):
        raise RuntimeError(
            f"Firebase service account file not found at '{cred_path}'. "
            "Download it from Firebase Console → Project Settings → Service Accounts "
            "→ Generate New Private Key, then save it as firebase-service-account.json "
            "in the bugsense_backend directory."
        )

    cred = credentials.Certificate(cred_path)
    options: dict[str, Any] = {}
    project_id = get_firebase_project_id()
    if project_id:
        options["projectId"] = project_id

    _app = firebase_admin.initialize_app(cred, options)


def get_db() -> firestore.firestore.Client:
    """Return the Firestore client, initialising the SDK if needed."""
    init_firestore()
    return firestore.client()


# ──────────────────────────────────────────────
# Bug Reports  (collection: bug_reports)
# ──────────────────────────────────────────────

_BUGS = "bug_reports"


def create_bug_report(data: dict[str, Any]) -> str:
    """Create a new bug report document. Returns the document ID."""
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    doc_data = {
        "repo_owner": data.get("repo_owner", ""),
        "repo_name": data.get("repo_name", ""),
        "issue_number": data.get("issue_number"),
        "title": data.get("title", ""),
        "body": data.get("body", ""),
        "state": data.get("state", "open"),
        "labels": data.get("labels", []),
        "created_by": data.get("created_by", ""),
        "status": data.get("status", "new"),
        "github_user_id": data.get("github_user_id"),
        "created_at": now,
        "updated_at": now,
    }
    _, doc_ref = db.collection(_BUGS).add(doc_data)
    return doc_ref.id


def get_bug_report(doc_id: str) -> dict[str, Any] | None:
    """Get a single bug report by document ID."""
    db = get_db()
    doc = db.collection(_BUGS).document(doc_id).get()
    if doc.exists:
        result = doc.to_dict()
        result["id"] = doc.id
        return result
    return None


def list_bug_reports(
    repo_owner: str | None = None,
    repo_name: str | None = None,
    status: str | None = None,
    limit: int = 50,
    github_user_id: int | None = None,
) -> list[dict[str, Any]]:
    """List bug reports with optional filters. User-scoped when github_user_id provided."""
    db = get_db()
    query = db.collection(_BUGS)

    if github_user_id is not None:
        query = query.where("github_user_id", "==", github_user_id)
    if repo_owner:
        query = query.where("repo_owner", "==", repo_owner)
    if repo_name:
        query = query.where("repo_name", "==", repo_name)
    if status:
        query = query.where("status", "==", status)

    query = query.order_by("created_at", direction=firestore.Query.DESCENDING)
    query = query.limit(limit)

    results = []
    for doc in query.stream():
        item = doc.to_dict()
        item["id"] = doc.id
        results.append(item)
    return results


def update_bug_report(doc_id: str, data: dict[str, Any]) -> bool:
    """Update fields on an existing bug report. Returns True if the doc existed."""
    db = get_db()
    doc_ref = db.collection(_BUGS).document(doc_id)
    doc = doc_ref.get()
    if not doc.exists:
        return False

    data["updated_at"] = datetime.now(timezone.utc).isoformat()
    doc_ref.update(data)
    return True


def delete_bug_report(doc_id: str) -> bool:
    """Delete a bug report. Returns True if the doc existed."""
    db = get_db()
    doc_ref = db.collection(_BUGS).document(doc_id)
    doc = doc_ref.get()
    if not doc.exists:
        return False
    doc_ref.delete()
    return True


# ──────────────────────────────────────────────
# Users  (collection: users)
# ──────────────────────────────────────────────

_USERS = "users"


def upsert_user(login: str, data: dict[str, Any]) -> str:
    """Create or update a user profile. Returns the document ID (== login)."""
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    doc_ref = db.collection(_USERS).document(login)
    doc = doc_ref.get()

    user_data = {
        "login": login,
        "name": data.get("name"),
        "avatar_url": data.get("avatar_url"),
        "bio": data.get("bio"),
        "public_repos": data.get("public_repos", 0),
        "followers": data.get("followers", 0),
        "html_url": data.get("html_url"),
        "updated_at": now,
    }

    if doc.exists:
        doc_ref.update(user_data)
    else:
        user_data["created_at"] = now
        doc_ref.set(user_data)

    return login


def get_user(login: str) -> dict[str, Any] | None:
    """Retrieve a stored user profile by login."""
    db = get_db()
    doc = db.collection(_USERS).document(login).get()
    if doc.exists:
        result = doc.to_dict()
        result["id"] = doc.id
        return result
    return None


def delete_user_data(github_login: str, github_user_id: int) -> bool:
    """Delete the user profile and all bug reports owned by the user."""
    db = get_db()
    # Delete user profile
    doc_ref = db.collection(_USERS).document(github_login)
    doc_ref.delete()

    # Delete all bug reports by user
    query = db.collection(_BUGS).where("github_user_id", "==", github_user_id)
    for doc in query.stream():
        doc.reference.delete()
        
    return True

