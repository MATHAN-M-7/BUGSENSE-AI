"""
Root Cause Agent — performs deep root cause analysis on GitHub issues.

Orchestrates:
1. Formatting issue data into a prompt.
2. Retrieving similar issues from ChromaDB for context (RAG).
3. Calling the LLM provider for root cause analysis.
4. Persisting the analysis result to Firestore (if available).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from services.llm_provider import RootCauseAnalysis, get_llm_provider

logger = logging.getLogger("bugsense.root_cause")


def _format_issue_text(issue_data: dict[str, Any]) -> str:
    """Format issue data into a text representation for the LLM."""
    parts = []

    title = issue_data.get("title", "")
    if title:
        parts.append(f"**Title:** {title}")

    body = issue_data.get("body") or ""
    if body:
        if len(body) > 4000:
            body = body[:4000] + "\n... [truncated]"
        parts.append(f"**Body:**\n{body}")

    state = issue_data.get("state", "")
    if state:
        parts.append(f"**State:** {state}")

    labels = issue_data.get("labels", [])
    if labels:
        if isinstance(labels[0], dict):
            label_names = [lbl.get("name", "") for lbl in labels]
        else:
            label_names = labels
        parts.append(f"**Labels:** {', '.join(label_names)}")

    comments = issue_data.get("comments_text", [])
    if comments:
        comments_str = "\n".join(f"- {c}" for c in comments[:5])
        parts.append(f"**Comments:**\n{comments_str}")

    return "\n\n".join(parts)


def _retrieve_similar_issues(
    repo_owner: str, repo_name: str, issue_text: str, n_results: int = 3, github_user_id: int | None = None
) -> list[dict[str, Any]]:
    """Retrieve similar issues from ChromaDB. Returns [] on failure."""
    if not repo_owner or not repo_name:
        return []
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        results = store.search_similar(
            repo_owner=repo_owner,
            repo_name=repo_name,
            query=issue_text,
            n_results=n_results,
            github_user_id=github_user_id,
        )
        logger.info("Retrieved %d similar issues from ChromaDB", len(results))
        return results
    except Exception as exc:
        logger.debug("ChromaDB retrieval failed: %s", exc)
        return []


async def analyze_root_cause(
    issue_data: dict[str, Any],
    classification: dict[str, Any] | None = None,
    similar_issues: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """
    Perform root cause analysis on a GitHub issue.

    Args:
        issue_data: Dict containing at minimum 'title' and optionally
                    'body', 'state', 'labels', 'comments_text',
                    'repo_owner', 'repo_name', 'issue_number'.
        classification: Optional prior classification result
                        (category, severity, evidence_summary).

    Returns:
        Dict with root cause analysis results, metadata, and rag_context.
    """
    provider = get_llm_provider()
    issue_text = _format_issue_text(issue_data)

    repo_owner = issue_data.get("repo_owner", "")
    repo_name = issue_data.get("repo_name", "")
    github_user_id = issue_data.get("_github_user_id")

    logger.info(
        "Root cause analysis: %s/%s#%s '%s'",
        repo_owner,
        repo_name,
        issue_data.get("issue_number", "?"),
        issue_data.get("title", "")[:50],
    )

    # 1. Retrieve similar issues from ChromaDB for context if not provided
    if similar_issues is None:
        import asyncio
        try:
            similar_issues = await asyncio.wait_for(
                asyncio.to_thread(
                    _retrieve_similar_issues, repo_owner, repo_name, issue_text, 3, github_user_id
                ),
                timeout=75.0
            )
        except Exception as exc:
            logger.warning("Retrieval blocked or failed: %s", exc)
            similar_issues = []

    # 2. Call the LLM for root cause analysis
    analysis: RootCauseAnalysis = await provider.analyze_root_cause(
        issue_text, similar_issues, classification
    )

    # 3. Build the result
    now = datetime.now(timezone.utc).isoformat()
    result = {
        "repo_owner": repo_owner,
        "repo_name": repo_name,
        "issue_number": issue_data.get("issue_number"),
        "issue_title": issue_data.get("title", ""),
        "probable_cause": analysis.probable_cause,
        "affected_components": analysis.affected_components,
        "reproduction_steps": analysis.reproduction_steps,
        "investigation_areas": analysis.investigation_areas,
        "confidence": analysis.confidence,
        "related_patterns": analysis.related_patterns,
        "analysis_summary": analysis.analysis_summary,
        "model": provider.model_name,
        "analyzed_at": now,
        "analyzed_by": "root_cause_agent_v1",
        "rag_context": [
            {
                "issue_id": si.get("id", ""),
                "title": si.get("metadata", {}).get("title", ""),
                "category": si.get("metadata", {}).get("category", ""),
                "severity": si.get("metadata", {}).get("severity", ""),
                "similarity": si.get("similarity", 0),
            }
            for si in similar_issues
        ],
        "github_user_id": issue_data.get("_github_user_id"),
    }

    # Include prior classification if provided
    if classification:
        result["prior_classification"] = {
            "category": classification.get("category", ""),
            "severity": classification.get("severity", ""),
        }

    # Persist to Firestore (best-effort)
    analysis_id = _try_persist(result)
    if analysis_id:
        result["analysis_id"] = analysis_id

    return result


def _try_persist(result: dict[str, Any]) -> str | None:
    """Best-effort persist analysis to Firestore. Returns doc ID or None."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        _, doc_ref = db.collection("root_cause_analyses").add(result)
        logger.info("Root cause analysis persisted to Firestore: %s", doc_ref.id)
        return doc_ref.id
    except Exception as exc:
        logger.debug("Firestore persistence skipped: %s", exc)
        return None
