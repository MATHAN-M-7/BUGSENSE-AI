"""
GitHub Webhook service layer.

Handles HMAC-SHA256 signature verification, event routing,
and an in-memory event store for recent webhook deliveries.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
from collections import deque
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger("bugsense.webhooks")

# ──────────────────────────────────────────────
# In-memory event store (last 100 events)
# ──────────────────────────────────────────────

_MAX_EVENTS = 100
_recent_events: deque[dict[str, Any]] = deque(maxlen=_MAX_EVENTS)


def get_recent_events(limit: int = 20) -> list[dict[str, Any]]:
    """Return the most recent webhook events (newest first)."""
    events = list(_recent_events)
    events.reverse()
    return events[:limit]


def _store_event(event_type: str, action: str, summary: dict[str, Any]) -> dict[str, Any]:
    """Store a processed event and return it."""
    record = {
        "event_type": event_type,
        "action": action,
        "received_at": datetime.now(timezone.utc).isoformat(),
        **summary,
    }
    _recent_events.append(record)
    return record


# ──────────────────────────────────────────────
# Signature verification
# ──────────────────────────────────────────────

def verify_signature(payload: bytes, signature_header: str, secret: str) -> bool:
    """
    Verify GitHub's X-Hub-Signature-256 header.

    The header format is: ``sha256=<hex-digest>``
    """
    if not signature_header.startswith("sha256="):
        return False

    expected_sig = signature_header[7:]  # strip "sha256=" prefix
    mac = hmac.new(secret.encode("utf-8"), payload, hashlib.sha256)
    return hmac.compare_digest(mac.hexdigest(), expected_sig)


# ──────────────────────────────────────────────
# Event processors
# ──────────────────────────────────────────────

def process_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Route a webhook event to the appropriate handler."""
    handlers = {
        "ping": handle_ping_event,
        "issues": handle_issues_event,
        "issue_comment": handle_issue_comment_event,
    }

    handler = handlers.get(event_type, _handle_unknown_event)
    return handler(event_type, payload)


def handle_ping_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Handle GitHub's ping event (sent when webhook is first configured)."""
    zen = payload.get("zen", "")
    hook_id = payload.get("hook_id")
    repo = _extract_repo(payload)

    summary = {
        "repo": repo,
        "zen": zen,
        "hook_id": hook_id,
    }
    logger.info("Webhook ping received: hook_id=%s repo=%s", hook_id, repo)
    return _store_event(event_type, "ping", summary)


def handle_issues_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Handle issues events: opened, closed, reopened, labeled, etc."""
    action = payload.get("action", "unknown")
    issue = payload.get("issue", {})
    repo = _extract_repo(payload)

    summary = {
        "repo": repo,
        "issue_number": issue.get("number"),
        "title": issue.get("title", ""),
        "state": issue.get("state", ""),
        "labels": [lbl.get("name", "") for lbl in issue.get("labels", [])],
        "user": issue.get("user", {}).get("login", ""),
        "html_url": issue.get("html_url", ""),
    }

    logger.info(
        "Issue %s: #%s '%s' in %s",
        action,
        summary["issue_number"],
        summary["title"][:50],
        repo,
    )

    # Optionally persist to Firestore
    _try_firestore_sync(action, repo, issue)

    return _store_event(event_type, action, summary)


def handle_issue_comment_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Handle issue_comment events: created, edited, deleted."""
    action = payload.get("action", "unknown")
    issue = payload.get("issue", {})
    comment = payload.get("comment", {})
    repo = _extract_repo(payload)

    summary = {
        "repo": repo,
        "issue_number": issue.get("number"),
        "issue_title": issue.get("title", ""),
        "comment_id": comment.get("id"),
        "comment_body": (comment.get("body", "") or "")[:200],
        "comment_user": comment.get("user", {}).get("login", ""),
    }

    logger.info(
        "Comment %s on #%s in %s by %s",
        action,
        summary["issue_number"],
        repo,
        summary["comment_user"],
    )
    return _store_event(event_type, action, summary)


def _handle_unknown_event(event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Handle unrecognised event types — log and store them."""
    repo = _extract_repo(payload)
    action = payload.get("action", "")
    summary = {"repo": repo, "raw_action": action}
    logger.info("Unhandled webhook event: %s (action=%s)", event_type, action)
    return _store_event(event_type, action or "received", summary)


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _extract_repo(payload: dict[str, Any]) -> str:
    """Extract 'owner/repo' from the payload's repository field."""
    repo_data = payload.get("repository", {})
    return repo_data.get("full_name", "unknown/unknown")


def _try_firestore_sync(action: str, repo_full_name: str, issue: dict[str, Any]) -> None:
    """Best-effort sync of issue data to Firestore when an issue is opened."""
    if action != "opened":
        return

    try:
        from services.firestore_service import create_bug_report

        parts = repo_full_name.split("/", 1)
        owner = parts[0] if len(parts) > 0 else ""
        name = parts[1] if len(parts) > 1 else ""

        create_bug_report({
            "repo_owner": owner,
            "repo_name": name,
            "issue_number": issue.get("number"),
            "title": issue.get("title", ""),
            "body": issue.get("body", "") or "",
            "state": issue.get("state", "open"),
            "labels": [lbl.get("name", "") for lbl in issue.get("labels", [])],
            "created_by": issue.get("user", {}).get("login", ""),
            "status": "new",
        })
        logger.info("Issue #%s synced to Firestore", issue.get("number"))
    except Exception as exc:
        # Firestore may not be configured — that's fine, just log it
        logger.debug("Firestore sync skipped: %s", exc)
