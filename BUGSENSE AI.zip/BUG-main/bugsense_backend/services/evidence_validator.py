"""
Evidence-Based Validator — Deterministic Post-Pipeline Claim Verification.

Cross-references every claim produced by the multi-agent pipeline
(classification, root cause, resolution) against the original issue
text and RAG-retrieved context.  Produces per-claim evidence checks,
an aggregate evidence_score (0.0-1.0), and a human-readable verdict.

Design:
    * Zero LLM calls — pure string matching, keyword extraction, and
      token-overlap scoring.
    * Runs in <5 ms for typical payloads.
    * Consumed by the Adaptive Router as a post-pipeline validation
      step, and exposed as a standalone REST endpoint.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger("bugsense.evidence_validator")


# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────

class ClaimVerdict(str, Enum):
    """Per-claim verdict."""
    SUPPORTED = "SUPPORTED"
    PARTIAL = "PARTIAL"
    UNSUPPORTED = "UNSUPPORTED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class EvidenceVerdict(str, Enum):
    """Aggregate validation verdict."""
    STRONG = "STRONG"              # score >= 0.70
    MODERATE = "MODERATE"          # score >= 0.45
    WEAK = "WEAK"                  # score >= 0.20
    INSUFFICIENT = "INSUFFICIENT"  # score <  0.20


# ──────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────

@dataclass
class ClaimCheck:
    """Result of validating a single agent claim."""
    claim_type: str
    claim_value: str
    evidence_found: list[str] = field(default_factory=list)
    verdict: str = ClaimVerdict.UNSUPPORTED.value
    score: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ValidationResult:
    """Aggregate validation result for the entire pipeline output."""
    evidence_score: float = 0.0
    verdict: str = EvidenceVerdict.INSUFFICIENT.value
    claim_checks: list[ClaimCheck] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "evidence_score": self.evidence_score,
            "verdict": self.verdict,
            "claim_checks": [c.to_dict() for c in self.claim_checks],
            "metadata": self.metadata,
        }


# ──────────────────────────────────────────────
# Keyword dictionaries for category/severity
# ──────────────────────────────────────────────

_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "Bug": [
        "bug", "error", "crash", "fail", "broken", "defect", "fault",
        "exception", "traceback", "stack trace", "regression", "incorrect",
        "wrong", "unexpected", "not working", "doesn't work", "does not work",
    ],
    "Feature": [
        "feature", "request", "add", "new", "implement", "support",
        "would be nice", "proposal", "suggestion", "wish", "want",
    ],
    "Enhancement": [
        "enhance", "improvement", "improve", "better", "optimize",
        "refactor", "upgrade", "performance", "speed up", "faster",
    ],
    "Documentation": [
        "doc", "documentation", "readme", "typo", "spelling",
        "grammar", "example", "tutorial", "guide", "wiki",
    ],
    "Other": [],
}

_SEVERITY_KEYWORDS: dict[str, list[str]] = {
    "Critical": [
        "critical", "data loss", "security", "vulnerability", "exploit",
        "production down", "outage", "cannot deploy", "blocker",
        "urgent", "emergency", "p0", "severity: critical",
    ],
    "High": [
        "high", "crash", "exception", "traceback", "stack trace",
        "major", "significant", "p1", "severity: high", "breaking",
    ],
    "Medium": [
        "medium", "moderate", "intermittent", "sometimes", "p2",
        "severity: medium", "workaround",
    ],
    "Low": [
        "low", "minor", "cosmetic", "trivial", "nice to have",
        "p3", "severity: low", "typo",
    ],
}


# ──────────────────────────────────────────────
# Core Validator
# ──────────────────────────────────────────────

class EvidenceValidator:
    """Deterministic evidence-based validation engine.

    Usage::

        validator = EvidenceValidator()
        result = validator.validate(
            issue_data={"title": "...", "body": "..."},
            classification={"category": "Bug", "severity": "High", ...},
            root_cause={"probable_cause": "...", ...},
            resolution={"fix_description": "...", ...},
            rag_context=[...],
        )
        # result.evidence_score  -> 0.0 - 1.0
        # result.verdict         -> STRONG / MODERATE / WEAK / INSUFFICIENT
        # result.claim_checks    -> per-claim detail
    """

    # Verdict thresholds
    STRONG_THRESHOLD = 0.70
    MODERATE_THRESHOLD = 0.45
    WEAK_THRESHOLD = 0.20

    def validate(
        self,
        issue_data: dict[str, Any],
        classification: dict[str, Any] | None = None,
        root_cause: dict[str, Any] | None = None,
        resolution: dict[str, Any] | None = None,
        rag_context: list[dict[str, Any]] | None = None,
    ) -> ValidationResult:
        """Run all evidence checks and produce an aggregate result."""
        t0 = time.perf_counter()

        # Build the evidence corpus — all source text we can check against
        corpus = self._build_corpus(issue_data, rag_context)
        corpus_lower = corpus.lower()
        corpus_tokens = set(self._tokenize(corpus_lower))

        checks: list[ClaimCheck] = []

        # ── Classification checks ──
        if classification:
            checks.extend(self._check_classification(classification, corpus_lower))

        # ── Root cause checks ──
        if root_cause:
            checks.extend(self._check_root_cause(root_cause, corpus_lower, corpus_tokens))

        # ── Resolution checks ──
        if resolution:
            checks.extend(self._check_resolution(resolution, corpus_lower, corpus_tokens))

        # ── Aggregate score ──
        if checks:
            scorable = [c for c in checks if c.verdict != ClaimVerdict.NOT_APPLICABLE.value]
            if scorable:
                evidence_score = round(
                    sum(c.score for c in scorable) / len(scorable), 4
                )
            else:
                evidence_score = 0.0
        else:
            evidence_score = 0.0

        verdict = self._score_to_verdict(evidence_score)
        elapsed_ms = round((time.perf_counter() - t0) * 1000, 2)

        return ValidationResult(
            evidence_score=evidence_score,
            verdict=verdict.value,
            claim_checks=checks,
            metadata={
                "total_claims_checked": len(checks),
                "supported": sum(1 for c in checks if c.verdict == ClaimVerdict.SUPPORTED.value),
                "partial": sum(1 for c in checks if c.verdict == ClaimVerdict.PARTIAL.value),
                "unsupported": sum(1 for c in checks if c.verdict == ClaimVerdict.UNSUPPORTED.value),
                "not_applicable": sum(1 for c in checks if c.verdict == ClaimVerdict.NOT_APPLICABLE.value),
                "corpus_length": len(corpus),
                "latency_ms": elapsed_ms,
            },
        )

    # ──────────────────────────────────────────
    # Corpus builder
    # ──────────────────────────────────────────

    @staticmethod
    def _build_corpus(
        issue_data: dict[str, Any],
        rag_context: list[dict[str, Any]] | None = None,
    ) -> str:
        """Concatenate all source text into a single searchable corpus."""
        parts: list[str] = []

        parts.append(issue_data.get("title", ""))
        parts.append(issue_data.get("body", ""))

        for label in issue_data.get("labels", []):
            if isinstance(label, str):
                parts.append(label)

        for comment in issue_data.get("comments_text", []):
            if isinstance(comment, str):
                parts.append(comment)

        if rag_context:
            for ctx in rag_context:
                doc = ctx.get("document", "")
                if doc:
                    parts.append(doc)
                meta = ctx.get("metadata", {})
                if isinstance(meta, dict):
                    for v in meta.values():
                        if isinstance(v, str):
                            parts.append(v)

        return " ".join(p for p in parts if p)

    # ──────────────────────────────────────────
    # Classification checks
    # ──────────────────────────────────────────

    def _check_classification(
        self,
        classification: dict[str, Any],
        corpus_lower: str,
    ) -> list[ClaimCheck]:
        checks = []

        # Category check
        category = classification.get("category", "")
        if category:
            checks.append(self._check_category(category, corpus_lower))

        # Severity check
        severity = classification.get("severity", "")
        if severity:
            checks.append(self._check_severity(severity, corpus_lower))

        return checks

    def _check_category(self, category: str, corpus_lower: str) -> ClaimCheck:
        keywords = _CATEGORY_KEYWORDS.get(category, [])
        if not keywords:
            return ClaimCheck(
                claim_type="category",
                claim_value=category,
                verdict=ClaimVerdict.NOT_APPLICABLE.value,
                score=0.5,
            )

        found = [kw for kw in keywords if kw in corpus_lower]
        if len(found) >= 3:
            return ClaimCheck(
                claim_type="category",
                claim_value=category,
                evidence_found=found[:5],
                verdict=ClaimVerdict.SUPPORTED.value,
                score=1.0,
            )
        elif len(found) >= 1:
            return ClaimCheck(
                claim_type="category",
                claim_value=category,
                evidence_found=found,
                verdict=ClaimVerdict.PARTIAL.value,
                score=0.5,
            )
        else:
            return ClaimCheck(
                claim_type="category",
                claim_value=category,
                verdict=ClaimVerdict.UNSUPPORTED.value,
                score=0.0,
            )

    def _check_severity(self, severity: str, corpus_lower: str) -> ClaimCheck:
        keywords = _SEVERITY_KEYWORDS.get(severity, [])
        if not keywords:
            return ClaimCheck(
                claim_type="severity",
                claim_value=severity,
                verdict=ClaimVerdict.NOT_APPLICABLE.value,
                score=0.5,
            )

        found = [kw for kw in keywords if kw in corpus_lower]
        if len(found) >= 2:
            return ClaimCheck(
                claim_type="severity",
                claim_value=severity,
                evidence_found=found[:5],
                verdict=ClaimVerdict.SUPPORTED.value,
                score=1.0,
            )
        elif len(found) >= 1:
            return ClaimCheck(
                claim_type="severity",
                claim_value=severity,
                evidence_found=found,
                verdict=ClaimVerdict.PARTIAL.value,
                score=0.5,
            )
        else:
            return ClaimCheck(
                claim_type="severity",
                claim_value=severity,
                verdict=ClaimVerdict.UNSUPPORTED.value,
                score=0.0,
            )

    # ──────────────────────────────────────────
    # Root cause checks
    # ──────────────────────────────────────────

    def _check_root_cause(
        self,
        root_cause: dict[str, Any],
        corpus_lower: str,
        corpus_tokens: set[str],
    ) -> list[ClaimCheck]:
        checks = []

        # Probable cause — token overlap
        cause = root_cause.get("probable_cause", "")
        if cause:
            checks.append(self._check_token_overlap(
                "probable_cause", cause, corpus_tokens
            ))

        # Affected components — name match
        components = root_cause.get("affected_components", [])
        for comp in components:
            if isinstance(comp, str) and comp.strip():
                checks.append(self._check_name_in_corpus(
                    "affected_component", comp, corpus_lower
                ))

        # Investigation areas — name match
        areas = root_cause.get("investigation_areas", [])
        for area in areas:
            if isinstance(area, str) and area.strip():
                checks.append(self._check_name_in_corpus(
                    "investigation_area", area, corpus_lower
                ))

        return checks

    # ──────────────────────────────────────────
    # Resolution checks
    # ──────────────────────────────────────────

    def _check_resolution(
        self,
        resolution: dict[str, Any],
        corpus_lower: str,
        corpus_tokens: set[str],
    ) -> list[ClaimCheck]:
        checks = []

        # Fix description — token overlap
        fix_desc = resolution.get("fix_description", "")
        if fix_desc:
            checks.append(self._check_token_overlap(
                "fix_description", fix_desc, corpus_tokens
            ))

        # Code suggestions — file/component name match
        suggestions = resolution.get("code_suggestions", [])
        for sug in suggestions:
            if isinstance(sug, dict):
                target = sug.get("file_or_component", "")
                if target and target.strip():
                    checks.append(self._check_name_in_corpus(
                        "code_suggestion_target", target, corpus_lower
                    ))

        return checks

    # ──────────────────────────────────────────
    # Shared validation primitives
    # ──────────────────────────────────────────

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Split text into lowercase alphanumeric tokens, filtering noise."""
        tokens = re.findall(r"[a-z0-9_]+(?:\.[a-z0-9_]+)*", text.lower())
        # Remove very short tokens and common stop words
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "to", "of", "in", "for", "on", "at", "by", "and", "or",
            "it", "its", "this", "that", "with", "as", "from", "not",
            "has", "had", "have", "will", "can", "may", "but", "if",
            "do", "does", "did", "so", "no", "up", "out", "all",
        }
        return [t for t in tokens if len(t) > 2 and t not in stop_words]

    def _check_token_overlap(
        self,
        claim_type: str,
        claim_text: str,
        corpus_tokens: set[str],
    ) -> ClaimCheck:
        """Check how many tokens from a claim appear in the corpus."""
        claim_tokens = set(self._tokenize(claim_text.lower()))
        if not claim_tokens:
            return ClaimCheck(
                claim_type=claim_type,
                claim_value=claim_text[:100],
                verdict=ClaimVerdict.NOT_APPLICABLE.value,
                score=0.5,
            )

        overlap = claim_tokens & corpus_tokens
        overlap_ratio = len(overlap) / len(claim_tokens)

        if overlap_ratio >= 0.50:
            verdict = ClaimVerdict.SUPPORTED
            score = min(1.0, overlap_ratio * 1.2)  # Slight boost for high overlap
        elif overlap_ratio >= 0.25:
            verdict = ClaimVerdict.PARTIAL
            score = overlap_ratio * 1.5  # Scale up for partial
        else:
            verdict = ClaimVerdict.UNSUPPORTED
            score = overlap_ratio

        evidence_snippets = sorted(list(overlap))[:5]

        return ClaimCheck(
            claim_type=claim_type,
            claim_value=claim_text[:100],
            evidence_found=evidence_snippets,
            verdict=verdict.value,
            score=round(min(1.0, score), 4),
        )

    @staticmethod
    def _check_name_in_corpus(
        claim_type: str,
        name: str,
        corpus_lower: str,
    ) -> ClaimCheck:
        """Check if a component/file name appears in the corpus.

        Tries exact match first, then falls back to basename matching
        and individual-word matching for multi-word names.
        """
        name_lower = name.lower().strip()

        # Exact match
        if name_lower in corpus_lower:
            return ClaimCheck(
                claim_type=claim_type,
                claim_value=name,
                evidence_found=[name_lower],
                verdict=ClaimVerdict.SUPPORTED.value,
                score=1.0,
            )

        # Basename match (e.g., "src/auth/login.py" → "login.py" or "login")
        parts = re.split(r"[/\\.]", name_lower)
        meaningful_parts = [p for p in parts if len(p) > 2]

        found_parts = [p for p in meaningful_parts if p in corpus_lower]
        if found_parts:
            ratio = len(found_parts) / max(len(meaningful_parts), 1)
            if ratio >= 0.5:
                return ClaimCheck(
                    claim_type=claim_type,
                    claim_value=name,
                    evidence_found=found_parts[:3],
                    verdict=ClaimVerdict.PARTIAL.value,
                    score=round(ratio * 0.7, 4),
                )

        # Multi-word name check (e.g., "Authentication Service" → "authentication", "service")
        words = re.findall(r"[a-z]+", name_lower)
        meaningful_words = [w for w in words if len(w) > 3]
        if meaningful_words:
            found_words = [w for w in meaningful_words if w in corpus_lower]
            if found_words:
                ratio = len(found_words) / len(meaningful_words)
                if ratio >= 0.5:
                    return ClaimCheck(
                        claim_type=claim_type,
                        claim_value=name,
                        evidence_found=found_words[:3],
                        verdict=ClaimVerdict.PARTIAL.value,
                        score=round(ratio * 0.6, 4),
                    )

        return ClaimCheck(
            claim_type=claim_type,
            claim_value=name,
            verdict=ClaimVerdict.UNSUPPORTED.value,
            score=0.0,
        )

    def _score_to_verdict(self, score: float) -> EvidenceVerdict:
        if score >= self.STRONG_THRESHOLD:
            return EvidenceVerdict.STRONG
        elif score >= self.MODERATE_THRESHOLD:
            return EvidenceVerdict.MODERATE
        elif score >= self.WEAK_THRESHOLD:
            return EvidenceVerdict.WEAK
        else:
            return EvidenceVerdict.INSUFFICIENT


# ──────────────────────────────────────────────
# Module-level singleton
# ──────────────────────────────────────────────

_validator_instance: EvidenceValidator | None = None


def get_evidence_validator() -> EvidenceValidator:
    """Return the module-level EvidenceValidator singleton."""
    global _validator_instance
    if _validator_instance is None:
        _validator_instance = EvidenceValidator()
    return _validator_instance
