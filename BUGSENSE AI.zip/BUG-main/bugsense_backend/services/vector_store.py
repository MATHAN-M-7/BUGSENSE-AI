"""
Vector Store — ChromaDB-backed semantic search for GitHub issues.

Provides:
1. Embedding generation via Gemini Embedding API.
2. Persistent local vector storage via ChromaDB.
3. Semantic similarity search over indexed issues.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from config import (
    get_gemini_api_key,
    get_vector_store_backend,
    get_chroma_persist_dir,
    get_chroma_host,
    get_chroma_port,
    get_chroma_ssl,
    get_chroma_api_key,
    get_chroma_tenant,
    get_chroma_database,
    is_production,
)

logger = logging.getLogger("bugsense.vectorstore")

_DEFAULT_PERSIST_DIR = "./chroma_data"
_EMBEDDING_MODEL = "gemini-embedding-001"


class VectorStore:
    """ChromaDB-backed vector store supporting local and remote backends with Gemini embeddings."""

    def __init__(
        self,
        persist_dir: str | None = None,
        backend: str | None = None,
        client: Any | None = None,
    ):
        self._backend = (backend or get_vector_store_backend()).lower().strip()
        self._persist_dir = persist_dir or get_chroma_persist_dir()

        if client is not None:
            self._client = client
        elif self._backend in ("chroma_remote", "chroma_http", "chroma_server"):
            self._client = self._init_remote_client()
        elif self._backend == "chroma_local":
            self._client = self._init_local_client()
        else:
            raise ValueError(
                f"Unsupported VECTOR_STORE_BACKEND: '{self._backend}'. "
                "Must be 'chroma_local' or 'chroma_remote'."
            )

        self._genai_client = self._init_genai()
        logger.info(
            "VectorStore initialised: backend=%s, persist_dir=%s, embedding_model=%s",
            self._backend,
            self._persist_dir,
            _EMBEDDING_MODEL,
        )

    def _init_local_client(self) -> Any:
        """Initialise local PersistentClient Chroma backend."""
        import chromadb

        logger.info("Initialising local ChromaDB persistent client at %s", self._persist_dir)
        return chromadb.PersistentClient(path=self._persist_dir)

    def _init_remote_client(self) -> Any:
        """Initialise remote Chroma HttpClient backend. Strictly fails without silent fallback."""
        import chromadb
        from chromadb.config import Settings

        host = get_chroma_host()
        if not host:
            raise ValueError("CHROMA_HOST must be specified when using chroma_remote backend.")

        port = get_chroma_port()
        ssl = get_chroma_ssl()
        api_key = get_chroma_api_key()
        tenant = get_chroma_tenant()
        database = get_chroma_database()

        headers: dict[str, str] = {}
        settings = None
        if api_key:
            headers["X-Chroma-Token"] = api_key
            headers["Authorization"] = f"Bearer {api_key}"
            try:
                settings = Settings(
                    chroma_client_auth_provider="chromadb.auth.token_authn.TokenAuthClientProvider",
                    chroma_client_auth_credentials=api_key,
                )
            except Exception:
                settings = None

        logger.info("Connecting to remote Chroma server at %s:%d (ssl=%s)", host, port, ssl)

        try:
            client = chromadb.HttpClient(
                host=host,
                port=port,
                ssl=ssl,
                headers=headers if headers else None,
                settings=settings,
                tenant=tenant,
                database=database,
            )
            # Verify connectivity via heartbeat
            client.heartbeat()
            return client
        except Exception as exc:
            # CRITICAL: DO NOT silently fall back to local PersistentClient in production
            error_msg = (
                f"Failed to connect to remote Chroma server at {host}:{port} (ssl={ssl}). "
                "Silent fallback to local storage is strictly disabled in production."
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg) from exc

    def health_check(self) -> dict[str, Any]:
        """
        Lightweight health check distinguishing backend mode and service reachability.
        Never executes an expensive vector search or leaks credentials.
        """
        is_alive = False
        try:
            if hasattr(self._client, "heartbeat"):
                hb = self._client.heartbeat()
                is_alive = hb is not None
            else:
                is_alive = True
        except Exception as e:
            logger.warning("VectorStore health check failed: %s", e)
            is_alive = False

        return {
            "status": "healthy" if is_alive else "unhealthy",
            "backend": self._backend,
            "reachable": is_alive,
        }

    def _init_genai(self):
        """Initialise the Gemini client for embeddings."""
        from services.llm_provider import get_shared_genai_client
        return get_shared_genai_client()

    # ──────────────────────────────────────────
    # Collections
    # ──────────────────────────────────────────

    def get_or_create_collection(self, name: str):
        """Get or create a named ChromaDB collection.

        Collection names are sanitised to meet ChromaDB requirements:
        - 3-63 characters, starts/ends with alphanumeric, no consecutive dots.
        """
        safe_name = self._sanitise_collection_name(name)
        return self._client.get_or_create_collection(
            name=safe_name,
            metadata={"description": f"BugSense issues for {name}"},
        )

    @staticmethod
    def _sanitise_collection_name(name: str) -> str:
        """Sanitise a string into a valid ChromaDB collection name."""
        # Replace non-alphanumeric chars with underscores
        sanitised = "".join(c if c.isalnum() else "_" for c in name)
        # Ensure 3-63 char length
        if len(sanitised) < 3:
            sanitised = sanitised + "_col"
        sanitised = sanitised[:63]
        # Ensure starts/ends with alphanumeric
        sanitised = sanitised.strip("_") or "default_col"
        if not sanitised[0].isalnum():
            sanitised = "c" + sanitised
        if not sanitised[-1].isalnum():
            sanitised = sanitised + "0"
        return sanitised

    # ──────────────────────────────────────────
    # Embeddings
    # ──────────────────────────────────────────

    def embed_text(self, text: str) -> list[float]:
        """Generate an embedding vector for the given text using Gemini."""
        # Truncate to avoid token limits (embedding models typically ~2048 tokens)
        if len(text) > 8000:
            text = text[:8000]

        result = self._genai_client.models.embed_content(
            model=_EMBEDDING_MODEL,
            contents=text,
        )
        return result.embeddings[0].values

    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Batch embed multiple texts."""
        truncated = [t[:8000] for t in texts]
        result = self._genai_client.models.embed_content(
            model=_EMBEDDING_MODEL,
            contents=truncated,
        )
        return [e.values for e in result.embeddings]

    # ──────────────────────────────────────────
    # CRUD
    # ──────────────────────────────────────────

    def upsert_issue(
        self,
        repo_owner: str,
        repo_name: str,
        issue_number: int,
        text: str,
        metadata: dict[str, Any] | None = None,
        github_user_id: int | None = None,
    ) -> str:
        """Embed and upsert a single issue into the repo's collection.

        When github_user_id is provided, uses a user-scoped collection
        (u{github_user_id}_{owner}_{repo}) for multi-tenant isolation.

        Returns the document ID.
        """
        if github_user_id is not None:
            collection_name = f"u{github_user_id}_{repo_owner}_{repo_name}"
        else:
            collection_name = f"{repo_owner}_{repo_name}"
        collection = self.get_or_create_collection(collection_name)
        doc_id = f"{repo_owner}_{repo_name}_{issue_number}"

        embedding = self.embed_text(text)

        # ChromaDB metadata must be str/int/float/bool
        meta = {
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "issue_number": issue_number,
        }
        if metadata:
            for k, v in metadata.items():
                if isinstance(v, (str, int, float, bool)):
                    meta[k] = v

        collection.upsert(
            ids=[doc_id],
            embeddings=[embedding],
            documents=[text[:10000]],  # ChromaDB document for retrieval
            metadatas=[meta],
        )
        logger.info("Upserted issue %s into collection %s", doc_id, collection_name)
        return doc_id

    def search_similar(
        self,
        repo_owner: str,
        repo_name: str,
        query: str,
        n_results: int = 5,
        github_user_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """Search for issues semantically similar to a query.

        When github_user_id is provided, queries the user-scoped collection
        for multi-tenant isolation.

        Returns a list of matches with scores and metadata.
        """
        if github_user_id is not None:
            collection_name = f"u{github_user_id}_{repo_owner}_{repo_name}"
        else:
            collection_name = f"{repo_owner}_{repo_name}"
        try:
            collection = self.get_or_create_collection(collection_name)
        except Exception as exc:
            logger.warning("Collection not found for %s/%s: %s", repo_owner, repo_name, exc)
            return []

        if collection.count() == 0:
            return []

        # Clamp n_results to available docs
        n_results = min(n_results, collection.count())

        query_embedding = self.embed_text(query)

        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
            include=["documents", "metadatas", "distances"],
        )

        matches = []
        ids = results.get("ids", [[]])[0]
        documents = results.get("documents", [[]])[0]
        metadatas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]

        for i, doc_id in enumerate(ids):
            # ChromaDB returns L2 distances; convert to similarity score (0-1)
            distance = distances[i] if i < len(distances) else 0
            similarity = max(0.0, 1.0 / (1.0 + distance))

            match = {
                "id": doc_id,
                "similarity": round(similarity, 4),
                "distance": round(distance, 4),
                "document": documents[i] if i < len(documents) else "",
                "metadata": metadatas[i] if i < len(metadatas) else {},
            }
            matches.append(match)

        return matches

    def get_collection_stats(self, repo_owner: str, repo_name: str, github_user_id: int | None = None) -> dict[str, Any]:
        """Get statistics for a repo's vector collection."""
        if github_user_id is not None:
            collection_name = f"u{github_user_id}_{repo_owner}_{repo_name}"
        else:
            collection_name = f"{repo_owner}_{repo_name}"
        try:
            collection = self.get_or_create_collection(collection_name)
            return {
                "collection_name": collection_name,
                "count": collection.count(),
                "persist_dir": self._persist_dir,
                "embedding_model": _EMBEDDING_MODEL,
            }
        except Exception:
            return {
                "collection_name": collection_name,
                "count": 0,
                "persist_dir": self._persist_dir,
                "embedding_model": _EMBEDDING_MODEL,
            }

    def delete_collection(self, repo_owner: str, repo_name: str, github_user_id: int | None = None) -> bool:
        """Delete a repo's vector collection."""
        if github_user_id is not None:
            collection_name = f"u{github_user_id}_{repo_owner}_{repo_name}"
        else:
            collection_name = f"{repo_owner}_{repo_name}"
        safe_name = self._sanitise_collection_name(collection_name)
        try:
            self._client.delete_collection(name=safe_name)
            logger.info("Deleted collection %s", safe_name)
            return True
        except Exception:
            return False

    def delete_user_data(self, github_user_id: int) -> bool:
        """Delete all collections belonging to a specific user."""
        prefix = self._sanitise_collection_name(f"u{github_user_id}_")
        try:
            collections = self._client.list_collections()
            for c in collections:
                c_name = getattr(c, "name", c) if hasattr(c, "name") else c
                if c_name.startswith(prefix):
                    self._client.delete_collection(name=c_name)
                    logger.info("Deleted user collection %s", c_name)
            return True
        except Exception as e:
            logger.error("Failed to delete user collections: %s", e)
            return False


# ──────────────────────────────────────────────
# Singleton factory
# ──────────────────────────────────────────────

_store_instance: VectorStore | None = None


def get_vector_store() -> VectorStore:
    """Return the configured VectorStore (singleton)."""
    global _store_instance
    if _store_instance is None:
        _store_instance = VectorStore()
    return _store_instance


def set_vector_store(store: VectorStore | None) -> None:
    """Override the vector store singleton (for testing/mocking)."""
    global _store_instance
    _store_instance = store


def reset_vector_store() -> None:
    """Reset the singleton (for testing)."""
    global _store_instance
    _store_instance = None
