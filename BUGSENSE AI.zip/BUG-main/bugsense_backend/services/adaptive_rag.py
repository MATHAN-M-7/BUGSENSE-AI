"""
Adaptive RAG Engine — Route-Aware Retrieval for the Multi-Agent Pipeline.

Replaces the static, duplicated ``_retrieve_similar_issues(…, n_results=3)``
pattern across agents with a centralised, strategy-driven retrieval service
that adapts to the route plan computed by the Adaptive Agent Router.

Strategies:
    skip     — No retrieval.  Returns instantly.  (NEEDS_CLARIFICATION route)
    minimal  — k=1, title-only query, aggressive similarity filter.  (FAST_TRACK)
    standard — k=3, title+body query, moderate similarity filter.    (STANDARD)
    expanded — k=5, multi-query decomposition (title + body queried
               separately), merged & deduped, relaxed filter.        (DEEP_INVESTIGATION)

Every retrieval call produces a ``RAGResult`` containing the filtered
similar issues *and* structured metadata (strategy used, latency, raw vs
filtered counts, quality scores) for the adaptation audit trail.
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger("bugsense.adaptive_rag")


# ──────────────────────────────────────────────
# Enums & Configuration
# ──────────────────────────────────────────────

class RAGStrategy(str, Enum):
    """Retrieval strategy modes, ordered by cost/depth."""
    SKIP = "skip"
    MINIMAL = "minimal"
    STANDARD = "standard"
    EXPANDED = "expanded"


@dataclass
class RAGConfig:
    """Per-request retrieval configuration."""

    strategy: RAGStrategy = RAGStrategy.STANDARD
    n_results: int = 3
    min_similarity: float = 0.15
    expanded_sub_queries: bool = True
    dedup: bool = True

    # Strategy-specific similarity floors
    MINIMAL_MIN_SIMILARITY: float = 0.20
    STANDARD_MIN_SIMILARITY: float = 0.15
    EXPANDED_MIN_SIMILARITY: float = 0.12

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_route_plan(cls, rag_strategy: dict[str, Any]) -> "RAGConfig":
        """Build a RAGConfig from a route plan's ``rag_strategy`` dict.

        Expected shape::

            {"mode": "standard", "n_results": 3}
        """
        mode_str = rag_strategy.get("mode", "standard")
        n_results = int(rag_strategy.get("n_results", 3))

        try:
            strategy = RAGStrategy(mode_str)
        except ValueError:
            strategy = RAGStrategy.STANDARD

        # Auto-select similarity floor per strategy
        if strategy == RAGStrategy.SKIP:
            min_sim = 0.0
        elif strategy == RAGStrategy.MINIMAL:
            min_sim = cls.MINIMAL_MIN_SIMILARITY
        elif strategy == RAGStrategy.EXPANDED:
            min_sim = cls.EXPANDED_MIN_SIMILARITY
        else:
            min_sim = cls.STANDARD_MIN_SIMILARITY

        return cls(
            strategy=strategy,
            n_results=n_results,
            min_similarity=min_sim,
            expanded_sub_queries=(strategy == RAGStrategy.EXPANDED),
            dedup=True,
        )


@dataclass
class RAGResult:
    """Structured retrieval result with quality metadata."""

    similar_issues: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "similar_issues": self.similar_issues,
            "metadata": self.metadata,
        }


# ──────────────────────────────────────────────
# Adaptive RAG Engine
# ──────────────────────────────────────────────

class AdaptiveRAG:
    """Route-aware retrieval engine for the BugSense multi-agent pipeline.

    Usage::

        rag = AdaptiveRAG()
        config = RAGConfig.from_route_plan(plan["rag_strategy"])
        result = rag.retrieve("owner", "repo", issue_data, config)
        # result.similar_issues → quality-filtered list
        # result.metadata       → audit trail dict
    """

    def retrieve(
        self,
        repo_owner: str,
        repo_name: str,
        issue_data: dict[str, Any],
        config: RAGConfig,
    ) -> RAGResult:
        """Execute adaptive retrieval according to *config*.

        All ChromaDB and embedding errors are caught internally; failures
        degrade gracefully to an empty result with error metadata rather
        than raising.
        """
        t0 = time.perf_counter()

        # ── SKIP strategy ──
        if config.strategy == RAGStrategy.SKIP:
            return RAGResult(
                similar_issues=[],
                metadata=self._meta(config, t0, raw=0, filtered=0),
            )

        title = issue_data.get("title", "")
        body = issue_data.get("body", "")

        try:
            from services.vector_store import get_vector_store
            store = get_vector_store()
        except Exception as exc:
            logger.warning("AdaptiveRAG: VectorStore init failed: %s", exc)
            return RAGResult(
                similar_issues=[],
                metadata=self._meta(config, t0, raw=0, filtered=0, error=str(exc)),
            )

        # ── MINIMAL strategy — title-only query ──
        if config.strategy == RAGStrategy.MINIMAL:
            query = title
            raw_results = self._safe_search(store, repo_owner, repo_name, query, config.n_results, github_user_id=issue_data.get("_github_user_id"))
            filtered = self._filter_by_similarity(raw_results, config.min_similarity)
            return RAGResult(
                similar_issues=filtered,
                metadata=self._meta(
                    config, t0,
                    raw=len(raw_results),
                    filtered=len(filtered),
                    sub_queries=["title"],
                    avg_similarity=self._avg_sim(filtered),
                ),
            )

        # ── STANDARD strategy — title+body query ──
        if config.strategy == RAGStrategy.STANDARD:
            query = f"{title}\n{body}"
            raw_results = self._safe_search(store, repo_owner, repo_name, query, config.n_results, github_user_id=issue_data.get("_github_user_id"))
            filtered = self._filter_by_similarity(raw_results, config.min_similarity)
            return RAGResult(
                similar_issues=filtered,
                metadata=self._meta(
                    config, t0,
                    raw=len(raw_results),
                    filtered=len(filtered),
                    sub_queries=["title+body"],
                    avg_similarity=self._avg_sim(filtered),
                ),
            )

        # ── EXPANDED strategy — multi-query decomposition ──
        if config.strategy == RAGStrategy.EXPANDED:
            sub_queries_used: list[str] = []
            all_results: list[dict[str, Any]] = []

            # Sub-query 1: title
            title_results = self._safe_search(store, repo_owner, repo_name, title, config.n_results, github_user_id=issue_data.get("_github_user_id"))
            all_results.extend(title_results)
            sub_queries_used.append("title")

            # Sub-query 2: body (if non-trivial)
            if body and len(body.split()) > 5:
                body_results = self._safe_search(store, repo_owner, repo_name, body, config.n_results, github_user_id=issue_data.get("_github_user_id"))
                all_results.extend(body_results)
                sub_queries_used.append("body")

            raw_count = len(all_results)

            # Deduplicate by document ID, keeping highest similarity
            if config.dedup:
                all_results = self._deduplicate(all_results)

            # Filter by similarity
            filtered = self._filter_by_similarity(all_results, config.min_similarity)

            # Sort by similarity descending and cap to n_results
            filtered.sort(key=lambda r: r.get("similarity", 0), reverse=True)
            filtered = filtered[:config.n_results]

            return RAGResult(
                similar_issues=filtered,
                metadata=self._meta(
                    config, t0,
                    raw=raw_count,
                    filtered=len(filtered),
                    sub_queries=sub_queries_used,
                    avg_similarity=self._avg_sim(filtered),
                    dedup_removed=raw_count - len(all_results) if config.dedup else 0,
                ),
            )

        # Fallback (should not reach here)
        return RAGResult(
            similar_issues=[],
            metadata=self._meta(config, t0, raw=0, filtered=0, error="unknown strategy"),
        )

    # ──────────────────────────────────────────
    # Internal helpers
    # ──────────────────────────────────────────

    @staticmethod
    def _safe_search(
        store: Any,
        repo_owner: str,
        repo_name: str,
        query: str,
        n_results: int,
        github_user_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """Search ChromaDB, returning [] on any error."""
        if not repo_owner or not repo_name or not query.strip():
            return []
        try:
            return store.search_similar(
                repo_owner=repo_owner,
                repo_name=repo_name,
                query=query,
                n_results=n_results,
                github_user_id=github_user_id,
            )
        except Exception as exc:
            logger.debug("AdaptiveRAG: search failed: %s", exc)
            return []

    @staticmethod
    def _filter_by_similarity(
        results: list[dict[str, Any]],
        min_similarity: float,
    ) -> list[dict[str, Any]]:
        """Drop results whose similarity is below *min_similarity*."""
        return [r for r in results if r.get("similarity", 0) >= min_similarity]

    @staticmethod
    def _deduplicate(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Keep the highest-similarity entry per document ID."""
        best: dict[str, dict[str, Any]] = {}
        for r in results:
            doc_id = r.get("id", "")
            if doc_id not in best or r.get("similarity", 0) > best[doc_id].get("similarity", 0):
                best[doc_id] = r
        return list(best.values())

    @staticmethod
    def _avg_sim(results: list[dict[str, Any]]) -> float:
        if not results:
            return 0.0
        return round(sum(r.get("similarity", 0) for r in results) / len(results), 4)

    @staticmethod
    def _meta(
        config: RAGConfig,
        t0: float,
        *,
        raw: int,
        filtered: int,
        sub_queries: list[str] | None = None,
        avg_similarity: float = 0.0,
        dedup_removed: int = 0,
        error: str | None = None,
    ) -> dict[str, Any]:
        """Build structured retrieval metadata."""
        meta: dict[str, Any] = {
            "strategy": config.strategy.value,
            "n_results_requested": config.n_results,
            "min_similarity_threshold": config.min_similarity,
            "raw_results_count": raw,
            "filtered_results_count": filtered,
            "avg_similarity": avg_similarity,
            "latency_ms": round((time.perf_counter() - t0) * 1000, 2),
        }
        if sub_queries:
            meta["sub_queries_used"] = sub_queries
        if dedup_removed:
            meta["dedup_removed"] = dedup_removed
        if error:
            meta["error"] = error
        return meta


# ──────────────────────────────────────────────
# Module-level singleton
# ──────────────────────────────────────────────

_rag_instance: AdaptiveRAG | None = None


def get_adaptive_rag() -> AdaptiveRAG:
    """Return the module-level AdaptiveRAG singleton."""
    global _rag_instance
    if _rag_instance is None:
        _rag_instance = AdaptiveRAG()
    return _rag_instance
