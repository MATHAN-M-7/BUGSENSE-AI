"""
Adaptive Agent Router — Confidence-Aware Multi-Agent Routing Engine.

Dynamically selects and orchestrates the optimal execution path across
the BugSense multi-agent network (Classifier, Root Cause, Resolution)
using issue complexity signals and runtime confidence gating.

Route Types:
    1. FAST_TRACK           — Low complexity (< 0.30) or non-defects.
                              Fast triage via classifier only. Zero root cause/code overhead.
    2. STANDARD             — Moderate complexity (0.30 - 0.55).
                              Balanced 3-stage pipeline with standard RAG and mid-flight gating.
    3. DEEP_INVESTIGATION   — High/Critical complexity (>= 0.55), stack traces, or multi-module.
                              Expanded RAG, deep root cause, and strict resolution gating.
    4. NEEDS_CLARIFICATION  — High retrieval ambiguity, low specificity, vague description.
                              Halts prior to code generation to avoid hallucinated PRs.
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from services import classifier_agent, resolution_agent, root_cause_agent
from services.adaptive_rag import AdaptiveRAG, RAGConfig, RAGResult, get_adaptive_rag
from services.evidence_validator import get_evidence_validator
from services.confidence_engine import get_confidence_engine
from services.complexity_analyzer import (
    ComplexityAnalyzer,
    analyze_complexity,
    get_complexity_analyzer,
)

logger = logging.getLogger("bugsense.adaptive_router")


# ──────────────────────────────────────────────
# Route Enums & Policy
# ──────────────────────────────────────────────

class RouteType(str, Enum):
    FAST_TRACK = "FAST_TRACK"
    STANDARD = "STANDARD"
    DEEP_INVESTIGATION = "DEEP_INVESTIGATION"
    NEEDS_CLARIFICATION = "NEEDS_CLARIFICATION"


@dataclass
class RoutingPolicy:
    """Configurable routing thresholds and agent execution parameters."""

    # Complexity thresholds
    fast_track_max_complexity: float = 0.30
    deep_min_complexity: float = 0.55
    ambiguity_clarification_threshold: float = 0.75
    min_specificity_threshold: float = 0.35
    max_clarification_word_count: int = 30

    # Confidence gating thresholds
    classification_confidence_gate: float = 0.60
    root_cause_confidence_gate: float = 0.60
    deep_confidence_gate: float = 0.70

    # RAG parameters
    fast_track_rag_k: int = 1
    standard_rag_k: int = 3
    deep_rag_k: int = 5

    # Categories considered non-defects for adaptive skipping
    non_defect_categories: list[str] = field(
        default_factory=lambda: ["Documentation", "Enhancement", "Other"]
    )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ──────────────────────────────────────────────
# Adaptive Router Implementation
# ──────────────────────────────────────────────

class AdaptiveRouter:
    """Confidence-Aware Adaptive Agent Router.

    Evaluates issue complexity and determines the optimal agent path.
    Supports offline route planning and online gated orchestration.
    """

    def __init__(
        self,
        policy: RoutingPolicy | None = None,
        complexity_analyzer: ComplexityAnalyzer | None = None,
    ) -> None:
        self.policy = policy or RoutingPolicy()
        self.analyzer = complexity_analyzer or get_complexity_analyzer()

    def plan_route(
        self,
        issue_data: dict[str, Any],
        similar_issues: list[dict[str, Any]] | None = None,
        complexity_result: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Compute the deterministic route plan for an issue.

        Zero LLM calls — instant evaluation using measurable signals.

        Args:
            issue_data: Issue dictionary with title, body, labels, etc.
            similar_issues: Optional ChromaDB retrieval context.
            complexity_result: Pre-computed complexity analysis dict (optional).

        Returns:
            Route plan containing route_type, recommended_agents,
            rag_strategy, confidence_thresholds, and routing rationale.
        """
        if complexity_result is None:
            complexity_result = self.analyzer.analyze(issue_data, similar_issues)

        score = float(complexity_result.get("complexity_score", 0.0))
        signals = complexity_result.get("signals", {})

        # Extract signal scores and details
        ambiguity_score = signals.get("retrieval_ambiguity", {}).get("score", 1.0)
        specificity_score = signals.get("error_specificity", {}).get("score", 0.0)
        stack_score = signals.get("stack_trace_present", {}).get("score", 0.0)
        desc_detail = signals.get("description_complexity", {}).get("detail", {})
        word_count = desc_detail.get("word_count", 0)
        module_score = signals.get("affected_modules", {}).get("score", 0.0)

        # ─── Decision Tree ───

        # 1. Check for underspecified / vague issue needing clarification
        # (Very low word count, zero specificity, zero files, zero modules/labels)
        is_vague = (
            word_count < 10
            and specificity_score <= 0.1
            and module_score <= 0.1
            and not signals.get("referenced_files", {}).get("detail", {}).get("files_found")
            and not any(lbl.lower() in ("documentation", "docs", "typo") for lbl in issue_data.get("labels", []))
        )

        if is_vague or (
            ambiguity_score >= self.policy.ambiguity_clarification_threshold
            and specificity_score <= self.policy.min_specificity_threshold
            and word_count < 10
            and module_score <= 0.1
        ):
            route_type = RouteType.NEEDS_CLARIFICATION
            reason = (
                f"Issue is underspecified (brief text: {word_count} words, no referenced files, "
                f"no module context, zero error specificity). Routed to clarification to prevent hallucinated fixes."
            )
            recommended_agents = ["classifier_agent"]
            rag_strategy = {"mode": "skip", "n_results": 0}
            confidence_thresholds = {
                "classification": self.policy.classification_confidence_gate,
            }

        # 2. Check for low-complexity / Fast-Track issue
        elif score < self.policy.fast_track_max_complexity:
            route_type = RouteType.FAST_TRACK
            reason = (
                f"Low complexity score ({score:.3f} < {self.policy.fast_track_max_complexity:.2f}). "
                "Issue is suitable for direct triage via classifier without root cause or fix generation overhead."
            )
            recommended_agents = ["classifier_agent"]
            rag_strategy = {"mode": "minimal", "n_results": self.policy.fast_track_rag_k}
            confidence_thresholds = {
                "classification": self.policy.classification_confidence_gate,
            }

        # 3. Check for Deep Investigation (High/Critical score >= 0.55 OR active stack trace)
        elif (
            score >= self.policy.deep_min_complexity
            or stack_score >= 0.5
            or (score >= 0.45 and module_score >= 0.7)
        ):
            route_type = RouteType.DEEP_INVESTIGATION
            reasons = []
            if score >= self.policy.deep_min_complexity:
                reasons.append(f"complexity score {score:.3f} >= {self.policy.deep_min_complexity:.2f}")
            if stack_score >= 0.5:
                reasons.append("active stack trace / crash log detected")
            if module_score >= 0.7:
                reasons.append("broad multi-module impact")

            reason = f"Deep Investigation selected: {', '.join(reasons)}. Requires expanded context and thorough multi-agent analysis."
            recommended_agents = [
                "classifier_agent",
                "root_cause_agent",
                "resolution_agent",
            ]
            rag_strategy = {"mode": "expanded", "n_results": self.policy.deep_rag_k}
            confidence_thresholds = {
                "classification": self.policy.deep_confidence_gate,
                "root_cause": self.policy.deep_confidence_gate,
                "resolution": self.policy.deep_confidence_gate,
            }

        # 4. Fallback to Standard 3-stage pipeline
        else:
            route_type = RouteType.STANDARD
            reason = (
                f"Moderate complexity score ({score:.3f}). "
                "Assigned to standard 3-stage pipeline with balanced retrieval and mid-flight gating."
            )
            recommended_agents = [
                "classifier_agent",
                "root_cause_agent",
                "resolution_agent",
            ]
            rag_strategy = {"mode": "standard", "n_results": self.policy.standard_rag_k}
            confidence_thresholds = {
                "classification": self.policy.classification_confidence_gate,
                "root_cause": self.policy.root_cause_confidence_gate,
                "resolution": self.policy.root_cause_confidence_gate,
            }

        now = datetime.now(timezone.utc).isoformat()
        return {
            "route_type": route_type.value,
            "routing_reason": reason,
            "recommended_agents": recommended_agents,
            "rag_strategy": rag_strategy,
            "confidence_thresholds": confidence_thresholds,
            "complexity": complexity_result,
            "policy": self.policy.to_dict(),
            "planned_at": now,
            "router_version": "adaptive_router_v1",
        }

    async def route_and_execute(
        self,
        issue_data: dict[str, Any],
        plan: dict[str, Any] | None = None,
        max_stages: int | None = None,
        similar_issues: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Execute the issue analysis along the planned adaptive path.

        Monitors agent confidence at each step. Adaptively halts or adjusts
        the pipeline if confidence falls below thresholds or if the issue
        turns out to be non-defect.

        Args:
            issue_data: Issue dictionary with title, body, labels, etc.
            plan: Pre-computed route plan (if None, plan_route will be called).
            max_stages: Maximum number of stages to execute (optional cutoff).
            similar_issues: ChromaDB retrieval context (optional).

        Returns:
            Unified execution trace with route_plan, stages_executed,
            stages_skipped, adaptation_log, and agent outputs.
        """
        start_time = time.perf_counter()

        if plan is None:
            plan = self.plan_route(issue_data, similar_issues=similar_issues)

        route_type = plan.get("route_type", RouteType.STANDARD.value)
        recommended_agents: list[str] = list(plan.get("recommended_agents", []))
        thresholds: dict[str, float] = plan.get("confidence_thresholds", {})
        rag_strategy: dict[str, Any] = plan.get("rag_strategy", {})

        stages_executed: list[str] = []
        stages_skipped: list[dict[str, Any]] = []
        adaptation_log: list[dict[str, Any]] = []

        classification_res: dict[str, Any] | None = None
        root_cause_res: dict[str, Any] | None = None
        resolution_res: dict[str, Any] | None = None
        rag_result: RAGResult | None = None

        status = "completed"

        # ─── Adaptive RAG Retrieval (centralised, before any agent) ───
        try:
            import asyncio
            rag_config = RAGConfig.from_route_plan(rag_strategy)
            adaptive_rag = get_adaptive_rag()
            rag_result = await asyncio.wait_for(
                asyncio.to_thread(
                    adaptive_rag.retrieve,
                    repo_owner=issue_data.get("repo_owner", ""),
                    repo_name=issue_data.get("repo_name", ""),
                    issue_data=issue_data,
                    config=rag_config,
                ),
                timeout=75.0
            )
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "adaptive_rag",
                "event_type": "RAG_RETRIEVAL_COMPLETE",
                "reason": (
                    f"Adaptive RAG ({rag_config.strategy.value}) retrieved "
                    f"{rag_result.metadata.get('filtered_results_count', 0)} results "
                    f"(raw={rag_result.metadata.get('raw_results_count', 0)}) "
                    f"in {rag_result.metadata.get('latency_ms', 0):.1f}ms."
                ),
                "details": rag_result.metadata,
            })
        except Exception as exc:
            logger.warning("Adaptive RAG failed, agents will use own retrieval: %s", exc)
            rag_result = None
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "adaptive_rag",
                "event_type": "RAG_RETRIEVAL_FAILED",
                "reason": f"Adaptive RAG unavailable: {exc}. Agents will fall back to their own retrieval.",
                "details": {"error": str(exc)},
            })

        # ─── Stage 1: Classifier Agent ───
        if "classifier_agent" in recommended_agents:
            if max_stages is not None and len(stages_executed) >= max_stages:
                stages_skipped.append({"stage": "classifier_agent", "reason": "max_stages reached"})
            else:
                logger.info("Adaptive Router -> Executing classifier_agent")
                use_rag = rag_strategy.get("mode") in ("standard", "expanded")
                if use_rag:
                    classification_res = await classifier_agent.classify_issue_with_rag(
                        issue_data,
                        similar_issues=rag_result.similar_issues if rag_result else None,
                    )
                else:
                    classification_res = await classifier_agent.classify_issue(issue_data)
                stages_executed.append("classifier_agent")

                # Evaluate Classifier Confidence Gate
                cat_conf = float(classification_res.get("category_confidence", classification_res.get("confidence", 0.0)))
                gate = float(thresholds.get("classification", self.policy.classification_confidence_gate))

                if cat_conf < gate:
                    event = {
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "stage": "classifier_agent",
                        "event_type": "LOW_CONFIDENCE_WARNING",
                        "reason": f"Classification confidence {cat_conf:.2f} is below gate threshold {gate:.2f}.",
                        "details": {"confidence": cat_conf, "gate": gate},
                    }
                    adaptation_log.append(event)
                    logger.warning("Adaptive Router: %s", event["reason"])
                else:
                    adaptation_log.append({
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "stage": "classifier_agent",
                        "event_type": "GATE_PASSED",
                        "reason": f"Classification confidence {cat_conf:.2f} passed gate {gate:.2f}.",
                        "details": {"confidence": cat_conf, "gate": gate},
                    })

                # Check if non-defect category requires adaptive bypass of root cause
                category = classification_res.get("category", "")
                if category in self.policy.non_defect_categories and "root_cause_agent" in recommended_agents:
                    adaptation_log.append({
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "stage": "root_cause_agent",
                        "event_type": "STAGE_SKIPPED",
                        "reason": f"Issue classified as '{category}' (non-defect). Defect root-cause analysis is not applicable.",
                        "details": {"category": category},
                    })
                    stages_skipped.append({
                        "stage": "root_cause_agent",
                        "reason": f"Non-defect category: {category}",
                    })
                    # Remove root cause from active execution list for this run
                    recommended_agents = [a for a in recommended_agents if a != "root_cause_agent"]

        # If Route was NEEDS_CLARIFICATION or FAST_TRACK, we stop here
        if route_type == RouteType.NEEDS_CLARIFICATION.value:
            status = "needs_clarification"
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "pipeline",
                "event_type": "EARLY_EXIT",
                "reason": "Pipeline halted after classification due to NEEDS_CLARIFICATION route to avoid hallucinated fixes.",
                "details": {"route_type": route_type},
            })
            for remaining in ["root_cause_agent", "resolution_agent"]:
                if remaining in recommended_agents:
                    stages_skipped.append({"stage": remaining, "reason": "NEEDS_CLARIFICATION route policy"})
            return self._finalize_result(
                start_time=start_time,
                plan=plan,
                status=status,
                stages_executed=stages_executed,
                stages_skipped=stages_skipped,
                adaptation_log=adaptation_log,
                classification=classification_res,
                root_cause=root_cause_res,
                resolution=resolution_res,
                issue_data=issue_data,
            )

        if route_type == RouteType.FAST_TRACK.value:
            status = "completed"
            for remaining in ["root_cause_agent", "resolution_agent"]:
                if remaining in recommended_agents:
                    stages_skipped.append({"stage": remaining, "reason": "FAST_TRACK route policy"})
            return self._finalize_result(
                start_time=start_time,
                plan=plan,
                status=status,
                stages_executed=stages_executed,
                stages_skipped=stages_skipped,
                adaptation_log=adaptation_log,
                classification=classification_res,
                root_cause=root_cause_res,
                resolution=resolution_res,
                issue_data=issue_data,
            )

        # ─── Stage 2: Root Cause Agent ───
        proceed_to_resolution = True
        if "root_cause_agent" in recommended_agents and "root_cause_agent" not in [s["stage"] for s in stages_skipped]:
            if max_stages is not None and len(stages_executed) >= max_stages:
                stages_skipped.append({"stage": "root_cause_agent", "reason": "max_stages reached"})
            else:
                logger.info("Adaptive Router -> Executing root_cause_agent")
                root_cause_res = await root_cause_agent.analyze_root_cause(
                    issue_data,
                    classification=classification_res,
                    similar_issues=rag_result.similar_issues if rag_result else None,
                )
                stages_executed.append("root_cause_agent")

                # Evaluate Root Cause Confidence Gate
                rc_conf = float(root_cause_res.get("confidence", 0.0))
                rc_gate = float(thresholds.get("root_cause", self.policy.root_cause_confidence_gate))

                if rc_conf < rc_gate:
                    proceed_to_resolution = False
                    status = "gated_early_exit"
                    event = {
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "stage": "root_cause_agent",
                        "event_type": "CONFIDENCE_GATE_HALT",
                        "reason": (
                            f"Root cause confidence {rc_conf:.2f} is below gate threshold {rc_gate:.2f}. "
                            "Halting pipeline before resolution generation to protect code safety."
                        ),
                        "details": {"confidence": rc_conf, "gate": rc_gate},
                    }
                    adaptation_log.append(event)
                    stages_skipped.append({
                        "stage": "resolution_agent",
                        "reason": f"Root cause confidence {rc_conf:.2f} below gate {rc_gate:.2f}",
                    })
                    logger.warning("Adaptive Router: %s", event["reason"])
                else:
                    adaptation_log.append({
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "stage": "root_cause_agent",
                        "event_type": "GATE_PASSED",
                        "reason": f"Root cause confidence {rc_conf:.2f} passed gate {rc_gate:.2f}.",
                        "details": {"confidence": rc_conf, "gate": rc_gate},
                    })

        # ─── Stage 3: Resolution Agent ───
        if (
            proceed_to_resolution
            and "resolution_agent" in recommended_agents
            and "resolution_agent" not in [s["stage"] for s in stages_skipped]
        ):
            if max_stages is not None and len(stages_executed) >= max_stages:
                stages_skipped.append({"stage": "resolution_agent", "reason": "max_stages reached"})
            else:
                logger.info("Adaptive Router -> Executing resolution_agent")
                resolution_res = await resolution_agent.generate_resolution(
                    issue_data,
                    classification=classification_res,
                    root_cause=root_cause_res,
                    similar_issues=rag_result.similar_issues if rag_result else None,
                )
                stages_executed.append("resolution_agent")

                res_conf = 0.0
                if isinstance(resolution_res, dict):
                    res_conf = float(resolution_res.get("confidence", 0.0))
                res_gate = float(thresholds.get("resolution", self.policy.deep_confidence_gate if route_type == RouteType.DEEP_INVESTIGATION.value else self.policy.root_cause_confidence_gate))

                adaptation_log.append({
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "stage": "resolution_agent",
                    "event_type": "GATE_PASSED" if res_conf >= res_gate else "LOW_CONFIDENCE_PATCH",
                    "reason": f"Resolution generated with confidence {res_conf:.2f} (gate: {res_gate:.2f}).",
                    "details": {"confidence": res_conf, "gate": res_gate},
                })

        return self._finalize_result(
            start_time=start_time,
            plan=plan,
            status=status,
            stages_executed=stages_executed,
            stages_skipped=stages_skipped,
            adaptation_log=adaptation_log,
            classification=classification_res,
            root_cause=root_cause_res,
            resolution=resolution_res,
            issue_data=issue_data,
        )

    def _finalize_result(
        self,
        start_time: float,
        plan: dict[str, Any],
        status: str,
        stages_executed: list[str],
        stages_skipped: list[dict[str, Any]],
        adaptation_log: list[dict[str, Any]],
        classification: dict[str, Any] | None,
        root_cause: dict[str, Any] | None,
        resolution: dict[str, Any] | None,
        issue_data: dict[str, Any],
    ) -> dict[str, Any]:
        """Compile execution metrics, trace, and persist results."""
        elapsed_ms = round((time.perf_counter() - start_time) * 1000, 2)
        now = datetime.now(timezone.utc).isoformat()

        result = {
            "route_type": plan.get("route_type", RouteType.STANDARD.value),
            "status": status,
            "route_plan": plan,
            "stages_executed": stages_executed,
            "stages_skipped": stages_skipped,
            "adaptation_log": adaptation_log,
            "classification": classification,
            "root_cause": root_cause,
            "resolution": resolution,
            "total_latency_ms": elapsed_ms,
            "repo_owner": issue_data.get("repo_owner", ""),
            "repo_name": issue_data.get("repo_name", ""),
            "issue_number": issue_data.get("issue_number"),
            "executed_at": now,
            "router_version": "adaptive_router_v2",
            "github_user_id": issue_data.get("_github_user_id"),
        }

        # Attach Adaptive RAG metadata if available
        rag_meta = None
        for entry in adaptation_log:
            if entry.get("stage") == "adaptive_rag":
                rag_meta = entry.get("details")
                break
        if rag_meta:
            result["rag_retrieval"] = rag_meta

        # ─── Evidence-Based Validation (post-pipeline) ───
        try:
            validator = get_evidence_validator()
            validation = validator.validate(
                issue_data=issue_data,
                classification=classification,
                root_cause=root_cause,
                resolution=resolution,
            )
            result["evidence_report"] = validation.to_dict()
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "evidence_validator",
                "event_type": "VALIDATION_COMPLETE",
                "reason": (
                    f"Evidence validation: {validation.verdict} "
                    f"(score={validation.evidence_score:.2f}, "
                    f"claims={validation.metadata.get('total_claims_checked', 0)})"
                ),
                "details": validation.metadata,
            })
        except Exception as exc:
            logger.warning("Evidence validation failed: %s", exc)
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "evidence_validator",
                "event_type": "VALIDATION_FAILED",
                "reason": f"Evidence validation unavailable: {exc}",
                "details": {"error": str(exc)},
            })

        # ─── System Confidence Engine (post-pipeline) ───
        try:
            engine = get_confidence_engine()
            confidence_report = engine.evaluate(result)
            result["system_confidence_report"] = confidence_report.to_dict()
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "confidence_engine",
                "event_type": "CONFIDENCE_EVALUATED",
                "reason": (
                    f"System Confidence evaluated: {confidence_report.system_status} "
                    f"({confidence_report.system_confidence:.2f})"
                ),
                "details": confidence_report.to_dict(),
            })
        except Exception as exc:
            logger.warning("Confidence Engine failed: %s", exc)
            adaptation_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "stage": "confidence_engine",
                "event_type": "CONFIDENCE_EVALUATION_FAILED",
                "reason": f"Confidence evaluation unavailable: {exc}",
                "details": {"error": str(exc)},
            })

        # Best-effort persist to Firestore
        doc_id = _try_persist_routing(result)
        if doc_id:
            result["routing_id"] = doc_id

        return result


# ──────────────────────────────────────────────
# Module-level convenience functions
# ──────────────────────────────────────────────

_router: AdaptiveRouter | None = None


def get_adaptive_router(
    policy: RoutingPolicy | None = None,
    complexity_analyzer: ComplexityAnalyzer | None = None,
) -> AdaptiveRouter:
    """Get or instantiate the global AdaptiveRouter singleton."""
    global _router
    if _router is None or policy is not None or complexity_analyzer is not None:
        _router = AdaptiveRouter(policy=policy, complexity_analyzer=complexity_analyzer)
    return _router


def plan_route(
    issue_data: dict[str, Any],
    similar_issues: list[dict[str, Any]] | None = None,
    complexity_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Convenience helper to plan route offline (zero LLM calls)."""
    router = get_adaptive_router()
    return router.plan_route(
        issue_data,
        similar_issues=similar_issues,
        complexity_result=complexity_result,
    )


async def route_and_execute(
    issue_data: dict[str, Any],
    plan: dict[str, Any] | None = None,
    max_stages: int | None = None,
    similar_issues: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Convenience helper to execute the confidence-aware routed pipeline."""
    router = get_adaptive_router()
    return await router.route_and_execute(
        issue_data,
        plan=plan,
        max_stages=max_stages,
        similar_issues=similar_issues,
    )


def _try_persist_routing(result: dict[str, Any]) -> str | None:
    """Best-effort persist routing decision to Firestore."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        doc_data = {
            "route_type": result.get("route_type"),
            "status": result.get("status"),
            "repo_owner": result.get("repo_owner"),
            "repo_name": result.get("repo_name"),
            "issue_number": result.get("issue_number"),
            "stages_executed": result.get("stages_executed"),
            "stages_skipped": result.get("stages_skipped"),
            "adaptation_log": result.get("adaptation_log"),
            "total_latency_ms": result.get("total_latency_ms"),
            "executed_at": result.get("executed_at"),
            "router_version": result.get("router_version"),
            "github_user_id": result.get("github_user_id", result.get("issue_data", {}).get("_github_user_id")),
        }
        _, doc_ref = db.collection("routing_decisions").add(doc_data)
        logger.info("Routing decision persisted to Firestore: %s", doc_ref.id)
        return doc_ref.id
    except Exception as exc:
        logger.debug("Firestore routing persistence skipped: %s", exc)
        return None
