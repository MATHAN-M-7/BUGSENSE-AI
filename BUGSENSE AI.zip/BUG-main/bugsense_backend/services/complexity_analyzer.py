"""
Issue Complexity Analyzer — deterministic, zero-LLM complexity scoring.

Computes a configurable complexity score for GitHub issues using 7
measurable textual signals. Designed as the foundational input for
the Confidence-Aware Adaptive Agent Router (Phase 4).

Signals:
    1. description_complexity — text verbosity and density
    2. stack_trace_present   — presence of error/stack output
    3. referenced_files      — file paths mentioned
    4. affected_modules      — breadth of component impact
    5. dependency_complexity  — external dependency indicators
    6. retrieval_ambiguity    — RAG context uncertainty
    7. error_specificity      — precision of error descriptions
"""

from __future__ import annotations

import logging
import math
import re
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger("bugsense.complexity")

# ──────────────────────────────────────────────
# Default signal weights
# ──────────────────────────────────────────────

DEFAULT_WEIGHTS: dict[str, float] = {
    "description_complexity": 0.15,
    "stack_trace_present": 0.10,
    "referenced_files": 0.15,
    "affected_modules": 0.15,
    "dependency_complexity": 0.10,
    "retrieval_ambiguity": 0.20,
    "error_specificity": 0.15,
}

# Complexity level thresholds
LEVEL_THRESHOLDS = [
    (0.75, "Critical"),
    (0.55, "High"),
    (0.30, "Medium"),
    (0.00, "Low"),
]


# ──────────────────────────────────────────────
# Regex patterns (compiled once)
# ──────────────────────────────────────────────

# Stack trace patterns across languages
_STACK_TRACE_PATTERNS = [
    re.compile(r"\bat\s+[\w.$]+\([\w.]+:\d+\)", re.IGNORECASE),        # Java/Kotlin
    re.compile(r"Traceback\s*\(most recent call", re.IGNORECASE),       # Python
    re.compile(r"File\s+\"[^\"]+\",\s+line\s+\d+", re.IGNORECASE),     # Python frame
    re.compile(r"^\s+at\s+.+\(.+:\d+:\d+\)", re.MULTILINE),            # JS/Node
    re.compile(r"Exception\s+in\s+thread", re.IGNORECASE),             # Java thread
    re.compile(r"Caused\s+by:", re.IGNORECASE),                        # Java chained
    re.compile(r"panic:\s+", re.IGNORECASE),                           # Go panic
    re.compile(r"SIGABRT|SIGSEGV|SIGFPE", re.IGNORECASE),             # Native crash
    re.compile(r"#\d+\s+0x[0-9a-f]+\s+in\s+", re.IGNORECASE),        # C/C++ gdb
    re.compile(r"goroutine\s+\d+\s+\[", re.IGNORECASE),               # Go goroutine
]

# File path patterns
_FILE_PATTERNS = [
    re.compile(
        r"(?:^|[\s`\"'(,])("
        r"[\w./\\-]+\.(?:py|java|kt|dart|js|ts|tsx|jsx|go|rs|c|cpp|h|hpp|rb|swift|m|cs|php|sh|yml|yaml|json|xml|toml|cfg|conf|ini|sql|proto|gradle|cmake|makefile)"
        r")",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        r"(?:src|lib|app|test|tests|pkg|cmd|internal|modules?|components?)[/\\][\w/\\.-]+",
        re.IGNORECASE,
    ),
]

# Dependency / external service keywords
_DEPENDENCY_KEYWORDS = [
    "npm", "pip", "gradle", "maven", "cargo", "pod", "cocoapods",
    "docker", "kubernetes", "k8s", "redis", "postgres", "mysql",
    "mongodb", "elasticsearch", "kafka", "rabbitmq", "aws", "gcp",
    "azure", "firebase", "supabase", "api", "sdk", "third-party",
    "third party", "upstream", "downstream", "dependency", "package",
    "library", "module", "plugin", "extension", "middleware",
    "microservice", "webhook", "oauth", "jwt", "ssl", "tls",
    "certificate", "cors", "proxy", "load balancer", "cdn",
    "database", "cache", "queue", "pubsub", "grpc", "graphql",
    "rest api", "endpoint",
]

# Technical / domain-specific terms for description density
_TECHNICAL_TERMS = [
    "null", "undefined", "exception", "error", "crash", "segfault",
    "memory", "leak", "overflow", "buffer", "deadlock", "race condition",
    "timeout", "latency", "throughput", "bottleneck", "regression",
    "deprecat", "migration", "refactor", "async", "await", "promise",
    "callback", "thread", "mutex", "semaphore", "socket", "stream",
    "serializ", "deserializ", "marshal", "unmarshal", "encode", "decode",
    "encrypt", "decrypt", "hash", "token", "session", "cookie",
    "authentication", "authorization", "permission", "role", "scope",
    "schema", "migration", "index", "query", "transaction", "commit",
    "rollback", "constraint", "foreign key", "primary key", "join",
    "aggregate", "pipeline", "batch", "cron", "scheduler", "worker",
    "container", "image", "volume", "network", "port", "dns",
    "stack trace", "stacktrace", "backtrace", "core dump",
    "heap", "stack", "gc", "garbage collect", "finalizer",
]

# Error specificity patterns
_ERROR_CODE_PATTERNS = [
    re.compile(r"\b[A-Z][A-Z0-9_]{2,}(?:Error|Exception|Fault)\b"),        # Named exceptions
    re.compile(r"\bHTTP\s*[45]\d{2}\b", re.IGNORECASE),                    # HTTP error codes
    re.compile(r"\b(?:errno|error\s*code|exit\s*code)\s*[=:]?\s*-?\d+", re.IGNORECASE),
    re.compile(r"\bE\d{4,}\b"),                                             # Numbered error codes
    re.compile(r"\b(?:status|code)\s*(?:=|:)\s*\d{3}\b", re.IGNORECASE),
    re.compile(r"\b(?:0x[0-9A-Fa-f]{4,})\b"),                             # Hex error codes
    re.compile(r"\bline\s+\d+\b", re.IGNORECASE),                          # Line references
    re.compile(r"\b(?:version|v)\s*\d+\.\d+", re.IGNORECASE),             # Version references
]

# Module / component keywords (for affected_modules)
_MODULE_INDICATORS = [
    "module", "component", "service", "controller", "handler", "manager",
    "provider", "factory", "adapter", "repository", "store", "cache",
    "router", "middleware", "interceptor", "guard", "filter", "pipe",
    "resolver", "validator", "serializer", "mapper", "converter",
    "client", "server", "gateway", "proxy", "bridge", "facade",
    "observer", "listener", "subscriber", "publisher", "emitter",
    "worker", "scheduler", "dispatcher", "executor", "processor",
    "engine", "core", "util", "helper", "config", "settings",
]


class ComplexityAnalyzer:
    """Deterministic complexity scorer for GitHub issues.

    Analyses 7 measurable signals and produces a weighted composite
    score in [0, 1] plus a human-readable complexity level.

    All weights are configurable so the future adaptive router can
    tune them without code changes.
    """

    def __init__(self, weights: dict[str, float] | None = None):
        self._weights = {**DEFAULT_WEIGHTS, **(weights or {})}
        # Normalise weights to sum to 1.0
        total = sum(self._weights.values())
        if total > 0:
            self._weights = {k: v / total for k, v in self._weights.items()}

    def analyze(
        self,
        issue_data: dict[str, Any],
        similar_issues: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Compute complexity score for a GitHub issue.

        Args:
            issue_data: Dict with at minimum 'title'; optionally
                        'body', 'labels', 'comments_text', 'state'.
            similar_issues: Optional list of ChromaDB search results
                            (used for retrieval_ambiguity signal).

        Returns:
            Dict with complexity_score, complexity_level, signals,
            weights, and metadata.
        """
        title = issue_data.get("title", "")
        body = issue_data.get("body") or ""
        labels = issue_data.get("labels", [])
        comments = issue_data.get("comments_text", [])

        # Normalise labels to strings
        if labels and isinstance(labels[0], dict):
            labels = [lbl.get("name", "") for lbl in labels]

        # Combine all text for analysis
        full_text = f"{title}\n\n{body}"
        if comments:
            full_text += "\n\n" + "\n".join(comments[:10])

        # Compute each signal
        signals: dict[str, dict[str, Any]] = {
            "description_complexity": self._score_description_complexity(full_text),
            "stack_trace_present": self._score_stack_trace(full_text),
            "referenced_files": self._score_referenced_files(full_text),
            "affected_modules": self._score_affected_modules(full_text, labels),
            "dependency_complexity": self._score_dependency_complexity(full_text),
            "retrieval_ambiguity": self._score_retrieval_ambiguity(similar_issues),
            "error_specificity": self._score_error_specificity(full_text),
        }

        # Weighted composite score
        complexity_score = sum(
            signals[key]["score"] * self._weights.get(key, 0)
            for key in signals
        )
        complexity_score = round(min(1.0, max(0.0, complexity_score)), 4)

        # Map to level
        complexity_level = "Low"
        for threshold, level in LEVEL_THRESHOLDS:
            if complexity_score >= threshold:
                complexity_level = level
                break

        now = datetime.now(timezone.utc).isoformat()
        return {
            "complexity_score": complexity_score,
            "complexity_level": complexity_level,
            "signals": signals,
            "weights": self._weights,
            "issue_title": issue_data.get("title", ""),
            "repo_owner": issue_data.get("repo_owner", ""),
            "repo_name": issue_data.get("repo_name", ""),
            "analyzed_at": now,
            "analyzed_by": "complexity_analyzer_v1",
        }

    # ──────────────────────────────────────────
    # Signal scorers
    # ──────────────────────────────────────────

    @staticmethod
    def _score_description_complexity(text: str) -> dict[str, Any]:
        """Score based on text length, sentence count, and technical density."""
        words = text.split()
        word_count = len(words)

        # Sentence splitting (rough)
        sentences = re.split(r"[.!?\n]+", text)
        sentences = [s.strip() for s in sentences if s.strip()]
        sentence_count = max(len(sentences), 1)
        avg_sentence_len = word_count / sentence_count

        # Technical term density
        text_lower = text.lower()
        tech_hits = sum(1 for term in _TECHNICAL_TERMS if term in text_lower)
        tech_density = tech_hits / max(word_count, 1)

        # Section headers (markdown-style)
        section_count = len(re.findall(r"^#{1,4}\s+", text, re.MULTILINE))

        # Scoring rubric:
        #   Short (< 50 words) → low
        #   Medium (50-200 words) → medium-ish
        #   Long (200-500 words) → elevated
        #   Very long (500+) → high
        length_score = min(1.0, word_count / 500)

        # Technical density bonus (0-0.3)
        density_bonus = min(0.3, tech_density * 5)

        # Structural complexity (sections suggest structured, complex reports)
        structure_bonus = min(0.2, section_count * 0.05)

        score = min(1.0, length_score * 0.6 + density_bonus + structure_bonus + 0.1)
        # Floor at 0.05 even for nearly-empty descriptions
        score = max(0.05, score)

        return {
            "score": round(score, 4),
            "detail": {
                "word_count": word_count,
                "sentence_count": sentence_count,
                "avg_sentence_length": round(avg_sentence_len, 1),
                "technical_term_hits": tech_hits,
                "technical_density": round(tech_density, 4),
                "section_count": section_count,
            },
        }

    @staticmethod
    def _score_stack_trace(text: str) -> dict[str, Any]:
        """Score based on presence and depth of stack traces."""
        matches = []
        for pattern in _STACK_TRACE_PATTERNS:
            found = pattern.findall(text)
            if found:
                matches.extend(found)

        # Estimate stack depth by counting "at " lines
        at_lines = re.findall(r"^\s+at\s+", text, re.MULTILINE | re.IGNORECASE)
        stack_depth = len(at_lines)

        if not matches and stack_depth == 0:
            score = 0.0
        elif len(matches) <= 2 and stack_depth <= 3:
            score = 0.4
        elif len(matches) <= 5 or stack_depth <= 10:
            score = 0.7
        else:
            score = 1.0

        return {
            "score": round(score, 4),
            "detail": {
                "pattern_matches": len(matches),
                "estimated_stack_depth": stack_depth,
                "has_stack_trace": len(matches) > 0 or stack_depth > 0,
            },
        }

    @staticmethod
    def _score_referenced_files(text: str) -> dict[str, Any]:
        """Score based on number of distinct file paths mentioned."""
        files: set[str] = set()
        for pattern in _FILE_PATTERNS:
            for match in pattern.finditer(text):
                # Use the full match or first group
                path = match.group(1) if match.lastindex else match.group(0)
                # Normalise
                path = path.strip().lower().replace("\\", "/")
                if len(path) > 3:  # skip very short false positives
                    files.add(path)

        file_count = len(files)

        if file_count == 0:
            score = 0.0
        elif file_count <= 2:
            score = 0.3
        elif file_count <= 5:
            score = 0.6
        elif file_count <= 10:
            score = 0.8
        else:
            score = 1.0

        return {
            "score": round(score, 4),
            "detail": {
                "unique_file_count": file_count,
                "files_found": sorted(files)[:20],  # Cap for response size
            },
        }

    @staticmethod
    def _score_affected_modules(text: str, labels: list[str]) -> dict[str, Any]:
        """Score based on how many components/modules are referenced."""
        text_lower = text.lower()
        label_text = " ".join(labels).lower()
        combined = f"{text_lower} {label_text}"

        # Count distinct module indicators
        module_hits: set[str] = set()
        for indicator in _MODULE_INDICATORS:
            # Look for "SomethingManager", "auth_service", etc.
            pattern = re.compile(
                rf"\b\w*{re.escape(indicator)}\w*\b", re.IGNORECASE
            )
            for m in pattern.finditer(combined):
                module_hits.add(m.group(0).lower())

        # Also count distinct labels as potential modules
        label_modules = {lbl.lower() for lbl in labels if len(lbl) > 2}

        total_modules = len(module_hits | label_modules)

        if total_modules == 0:
            score = 0.1  # No explicit modules mentioned, slight base
        elif total_modules <= 2:
            score = 0.3
        elif total_modules <= 5:
            score = 0.6
        elif total_modules <= 10:
            score = 0.8
        else:
            score = 1.0

        return {
            "score": round(score, 4),
            "detail": {
                "module_indicator_count": len(module_hits),
                "label_module_count": len(label_modules),
                "total_unique_modules": total_modules,
                "modules_found": sorted(module_hits | label_modules)[:20],
            },
        }

    @staticmethod
    def _score_dependency_complexity(text: str) -> dict[str, Any]:
        """Score based on external dependency / service references."""
        text_lower = text.lower()
        hits: set[str] = set()
        for keyword in _DEPENDENCY_KEYWORDS:
            if keyword in text_lower:
                hits.add(keyword)

        hit_count = len(hits)

        if hit_count == 0:
            score = 0.0
        elif hit_count <= 2:
            score = 0.3
        elif hit_count <= 5:
            score = 0.6
        elif hit_count <= 10:
            score = 0.8
        else:
            score = 1.0

        return {
            "score": round(score, 4),
            "detail": {
                "dependency_keyword_count": hit_count,
                "keywords_found": sorted(hits),
            },
        }

    @staticmethod
    def _score_retrieval_ambiguity(
        similar_issues: list[dict[str, Any]] | None,
    ) -> dict[str, Any]:
        """Score based on ChromaDB retrieval quality.

        High ambiguity (= high complexity) when:
        - No similar issues available (unknown territory)
        - Low similarity scores (poor matches)
        - High variance in similarity (inconsistent context)
        """
        if not similar_issues:
            # No retrieval context at all → maximum ambiguity
            return {
                "score": 1.0,
                "detail": {
                    "similar_issues_count": 0,
                    "avg_similarity": 0.0,
                    "max_similarity": 0.0,
                    "similarity_spread": 0.0,
                    "reason": "no_similar_issues_available",
                },
            }

        similarities = [
            si.get("similarity", 0.0) for si in similar_issues
        ]
        avg_sim = sum(similarities) / len(similarities) if similarities else 0
        max_sim = max(similarities) if similarities else 0
        min_sim = min(similarities) if similarities else 0
        spread = max_sim - min_sim

        # High confidence retrieval → low ambiguity
        # Scoring: invert retrieval quality
        # max_sim > 0.8 and low spread → very clear (low ambiguity)
        # max_sim < 0.4 → very unclear (high ambiguity)
        retrieval_quality = max_sim * 0.6 + avg_sim * 0.3 + (1 - spread) * 0.1
        ambiguity_score = 1.0 - min(1.0, retrieval_quality)

        return {
            "score": round(ambiguity_score, 4),
            "detail": {
                "similar_issues_count": len(similar_issues),
                "avg_similarity": round(avg_sim, 4),
                "max_similarity": round(max_sim, 4),
                "min_similarity": round(min_sim, 4),
                "similarity_spread": round(spread, 4),
                "retrieval_quality": round(retrieval_quality, 4),
            },
        }

    @staticmethod
    def _score_error_specificity(text: str) -> dict[str, Any]:
        """Score based on precision of error descriptions."""
        matches: dict[str, int] = {}
        for pattern in _ERROR_CODE_PATTERNS:
            found = pattern.findall(text)
            if found:
                matches[pattern.pattern[:40]] = len(found)

        total_matches = sum(matches.values())

        # Also check for specific variable/class names (CamelCase identifiers)
        camel_case = re.findall(r"\b[A-Z][a-z]+(?:[A-Z][a-z]+){1,}\b", text)
        specific_identifiers = len(set(camel_case))

        combined = total_matches + min(specific_identifiers, 10)

        if combined == 0:
            score = 0.1  # Vague issue description
        elif combined <= 3:
            score = 0.4
        elif combined <= 8:
            score = 0.6
        elif combined <= 15:
            score = 0.8
        else:
            score = 1.0

        return {
            "score": round(score, 4),
            "detail": {
                "error_pattern_matches": total_matches,
                "specific_identifiers": specific_identifiers,
                "combined_specificity": combined,
            },
        }


# ──────────────────────────────────────────────
# Module-level convenience
# ──────────────────────────────────────────────

_analyzer: ComplexityAnalyzer | None = None


def get_complexity_analyzer(
    weights: dict[str, float] | None = None,
) -> ComplexityAnalyzer:
    """Get or create the module-level ComplexityAnalyzer singleton."""
    global _analyzer
    if _analyzer is None or weights is not None:
        _analyzer = ComplexityAnalyzer(weights=weights)
    return _analyzer


def analyze_complexity(
    issue_data: dict[str, Any],
    similar_issues: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Convenience function: analyse issue complexity."""
    analyzer = get_complexity_analyzer()
    return analyzer.analyze(issue_data, similar_issues)


def _try_persist(result: dict[str, Any]) -> str | None:
    """Best-effort persist complexity analysis to Firestore."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        _, doc_ref = db.collection("complexity_analyses").add(result)
        logger.info("Complexity analysis persisted to Firestore: %s", doc_ref.id)
        return doc_ref.id
    except Exception as exc:
        logger.debug("Firestore persistence skipped: %s", exc)
        return None
