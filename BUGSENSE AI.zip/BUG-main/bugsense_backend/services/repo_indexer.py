"""
Repository Indexer — fetches and classifies all issues in a GitHub repo.

Orchestrates:
1. Paginated issue fetching from GitHub API.
2. Batch classification via the Classifier Agent.
3. Summary storage in Firestore (repo_indexes collection).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from services import classifier_agent
from services.github_service import list_issues, get_issue, list_issue_comments

logger = logging.getLogger("bugsense.indexer")

_COLLECTION = "repo_indexes"


async def index_repository(
    owner: str,
    repo: str,
    max_issues: int = 50,
    token: str | None = None,
    github_user_id: int | None = None,
) -> dict[str, Any]:
    """
    Fetch and classify issues from a GitHub repository.

    Args:
        owner: Repository owner (e.g. 'octocat').
        repo: Repository name (e.g. 'Hello-World').
        max_issues: Maximum number of issues to index (default 50).
        token: Optional GitHub OAuth token.

    Returns:
        Index summary with breakdowns and classified issues.
    """
    logger.info("Starting indexing: %s/%s (max_issues=%d)", owner, repo, max_issues)

    # 0. Validate LLM provider is available (fail fast before fetching)
    from services.llm_provider import get_llm_provider
    get_llm_provider()  # Raises RuntimeError if GEMINI_API_KEY is missing

    # 1. Fetch issues (paginated)
    all_issues = await _fetch_all_issues(owner, repo, max_issues, token)
    logger.info("Fetched %d issues from %s/%s", len(all_issues), owner, repo)

    # 2. Classify each issue
    classified = []
    failed = 0
    category_breakdown: dict[str, int] = {}
    severity_breakdown: dict[str, int] = {}

    for i, issue in enumerate(all_issues):
        try:
            logger.info(
                "Classifying issue %d/%d: #%s %s",
                i + 1, len(all_issues),
                issue.get("number", "?"),
                issue.get("title", "")[:50],
            )

            # Fetch comments for richer context (up to 5)
            comments_text = []
            try:
                comments = await list_issue_comments(
                    owner, repo, issue["number"], per_page=5, token=token
                )
                comments_text = [c.get("body", "")[:500] for c in comments if c.get("body")]
            except Exception:
                pass  # Comments are optional context

            # Build classification input
            issue_data = {
                "repo_owner": owner,
                "repo_name": repo,
                "issue_number": issue.get("number"),
                "title": issue.get("title", ""),
                "body": issue.get("body", "") or "",
                "state": issue.get("state", "open"),
                "labels": [lbl.get("name", "") for lbl in issue.get("labels", []) if isinstance(lbl, dict)],
                "comments_text": comments_text,
            }

            result = await classifier_agent.classify_issue(issue_data)
            classified.append(result)

            # Track breakdowns
            cat = result.get("category", "Other")
            sev = result.get("severity", "Medium")
            category_breakdown[cat] = category_breakdown.get(cat, 0) + 1
            severity_breakdown[sev] = severity_breakdown.get(sev, 0) + 1

            # Embed into ChromaDB (best-effort, user-scoped)
            _try_embed_issue(issue_data, result, github_user_id=github_user_id)

        except Exception as exc:
            logger.warning("Failed to classify issue #%s: %s", issue.get("number"), exc)
            failed += 1

    # 3. Build index summary
    now = datetime.now(timezone.utc).isoformat()
    model = get_llm_provider().model_name

    index_summary = {
        "owner": owner,
        "repo": repo,
        "total_issues": len(all_issues),
        "classified": len(classified),
        "failed": failed,
        "category_breakdown": category_breakdown,
        "severity_breakdown": severity_breakdown,
        "indexed_at": now,
        "model": model,
        "status": "completed" if failed == 0 else "partial",
    }

    # 4. Persist to Firestore (best-effort, user-scoped)
    index_id = _try_persist_index(owner, repo, index_summary, github_user_id=github_user_id)
    if index_id:
        index_summary["index_id"] = index_id

    logger.info(
        "Indexing complete: %s/%s — %d classified, %d failed",
        owner, repo, len(classified), failed,
    )

    return {
        "summary": index_summary,
        "issues": classified,
    }


async def _fetch_all_issues(
    owner: str,
    repo: str,
    max_issues: int,
    token: str | None,
) -> list[dict[str, Any]]:
    """Fetch issues from GitHub, paginating until max_issues is reached.

    Always fetches 100 items per page from GitHub to avoid the case where
    a small per_page is entirely consumed by pull requests (which get
    filtered out by github_service.list_issues).
    """
    all_issues: list[dict[str, Any]] = []
    page = 1
    per_page = 100  # Always fetch large pages; PRs are filtered server-side
    max_pages = 10  # Safety limit to avoid infinite loops

    while len(all_issues) < max_issues and page <= max_pages:
        issues = await list_issues(
            owner, repo, state="all", per_page=per_page, page=page, token=token
        )
        if not issues:
            # If the raw GitHub response (before PR filtering) was likely empty,
            # check by seeing if we got nothing from a full page request.
            break
        all_issues.extend(issues)
        page += 1

    return all_issues[:max_issues]


def _try_persist_index(owner: str, repo: str, summary: dict[str, Any], github_user_id: int | None = None) -> str | None:
    """Persist index summary to Firestore. Returns doc ID or None."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        if github_user_id is not None:
            doc_id = f"u{github_user_id}_{owner}_{repo}"
            summary["github_user_id"] = github_user_id
        else:
            doc_id = f"{owner}_{repo}"
        db.collection(_COLLECTION).document(doc_id).set(summary)
        logger.info("Index summary persisted to Firestore: %s", doc_id)
        return doc_id
    except Exception as exc:
        logger.debug("Firestore persistence skipped: %s", exc)
        return None


def get_repo_index(owner: str, repo: str, github_user_id: int | None = None) -> dict[str, Any] | None:
    """Retrieve a stored index summary from Firestore (user-scoped)."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        if github_user_id is not None:
            doc_id = f"u{github_user_id}_{owner}_{repo}"
        else:
            doc_id = f"{owner}_{repo}"
        doc = db.collection(_COLLECTION).document(doc_id).get()
        if doc.exists:
            data = doc.to_dict()
            data["index_id"] = doc.id
            return data
        return None
    except Exception:
        return None


def list_indexed_repos(limit: int = 20, github_user_id: int | None = None) -> list[dict[str, Any]]:
    """List indexed repositories from Firestore (user-scoped when github_user_id provided)."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        query = db.collection(_COLLECTION)
        if github_user_id is not None:
            query = query.where("github_user_id", "==", github_user_id)
        query = (
            query
            .order_by("indexed_at", direction="DESCENDING")
            .limit(limit)
        )
        results = []
        for doc in query.stream():
            data = doc.to_dict()
            data["index_id"] = doc.id
            results.append(data)
        return results
    except Exception:
        return []


def get_repo_analyses(owner: str, repo: str, limit: int = 50, github_user_id: int | None = None) -> list[dict[str, Any]]:
    """List classified issues for a specific repo from Firestore (user-scoped)."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        query = db.collection("analyses")
        query = query.where("repo_owner", "==", owner)
        query = query.where("repo_name", "==", repo)
        if github_user_id is not None:
            query = query.where("github_user_id", "==", github_user_id)
        query = (
            query
            .order_by("analyzed_at", direction="DESCENDING")
            .limit(limit)
        )
        results = []
        for doc in query.stream():
            data = doc.to_dict()
            data["analysis_id"] = doc.id
            results.append(data)
        return results
    except Exception:
        return []


def _try_embed_issue(issue_data: dict[str, Any], classification: dict[str, Any], github_user_id: int | None = None) -> None:
    """Best-effort embed a classified issue into ChromaDB (user-scoped)."""
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()

        # Build text for embedding: title + body
        text_parts = [issue_data.get("title", "")]
        body = issue_data.get("body", "")
        if body:
            text_parts.append(body)
        text = "\n\n".join(text_parts)

        # Build metadata
        metadata = {
            "title": issue_data.get("title", "")[:200],
            "state": issue_data.get("state", "open"),
            "category": classification.get("category", "Other"),
            "severity": classification.get("severity", "Medium"),
        }

        store.upsert_issue(
            repo_owner=issue_data.get("repo_owner", ""),
            repo_name=issue_data.get("repo_name", ""),
            issue_number=issue_data.get("issue_number", 0),
            text=text,
            metadata=metadata,
            github_user_id=github_user_id,
        )
    except Exception as exc:
        logger.debug("ChromaDB embedding skipped: %s", exc)

