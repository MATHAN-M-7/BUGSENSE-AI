"""
Server-side session store backed by PostgreSQL with application-level token encryption.

Maps BugSense session tokens → encrypted GitHub OAuth access tokens.
GitHub access tokens NEVER leave this store in plaintext via any API response.
Redis continues to manage short-lived OAuth CSRF state and callback handoff codes.
"""

from __future__ import annotations

import json
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any
import os

from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException
import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool
import redis

from config import (
    get_database_url,
    get_session_encryption_key,
)
from services.redis_client import get_redis_client

# Default session lifetime: 7 days
_DEFAULT_TTL_SECONDS = 7 * 24 * 3600

# TTL for one-time mobile handoff codes: 2 minutes
_HANDOFF_TTL_SECONDS = 120

# Module-level connection pool (lazy)
_pool: Any | None = None


# ──────────────────────────────────────────────
# Token Encryption (Fernet / AES-128-CBC + HMAC)
# ──────────────────────────────────────────────

def _get_cipher() -> Fernet:
    """Return Fernet cipher initialized from config."""
    key = get_session_encryption_key()
    if isinstance(key, str):
        key = key.encode("utf-8")
    return Fernet(key)


def _encrypt_token(plaintext_token: str) -> str:
    """
    Encrypt plaintext GitHub access token.
    Ciphertext is stored in PostgreSQL.
    """
    if not plaintext_token:
        return ""
    cipher = _get_cipher()
    return cipher.encrypt(plaintext_token.encode("utf-8")).decode("utf-8")


def _decrypt_token(ciphertext_token: str) -> str:
    """
    Decrypt encrypted GitHub access token.
    Plaintext token lives only in transient process memory.
    """
    if not ciphertext_token:
        return ""
    cipher = _get_cipher()
    try:
        return cipher.decrypt(ciphertext_token.encode("utf-8")).decode("utf-8")
    except InvalidToken as e:
        raise HTTPException(
            status_code=500,
            detail="Failed to decrypt stored credentials (encryption key mismatch).",
        ) from e


# ──────────────────────────────────────────────
# Database Pool & Schema
# ──────────────────────────────────────────────

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id          VARCHAR(64) PRIMARY KEY,
    github_user_id      BIGINT NOT NULL,
    github_login        VARCHAR(255) NOT NULL,
    github_avatar_url   TEXT DEFAULT '',
    github_name         VARCHAR(255) DEFAULT '',
    github_access_token TEXT NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL,
    expires_at          TIMESTAMPTZ NOT NULL
);
"""

_CREATE_INDEX_EXPIRES_SQL = """
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions (expires_at);
"""

_CREATE_INDEX_USER_SQL = """
CREATE INDEX IF NOT EXISTS idx_sessions_github_user_id ON sessions (github_user_id);
"""

_CREATE_VERDICTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS review_verdicts (
    id                    SERIAL PRIMARY KEY,
    github_user_id        BIGINT NOT NULL,
    github_login          VARCHAR(255) NOT NULL,
    repo_owner            VARCHAR(255) NOT NULL,
    repo_name             VARCHAR(255) NOT NULL,
    issue_number          INTEGER NOT NULL,
    verdict               VARCHAR(32) NOT NULL,
    reviewer              VARCHAR(255) DEFAULT 'human_reviewer',
    rejection_reason      TEXT,
    notes                 TEXT DEFAULT '',
    has_edited_resolution BOOLEAN DEFAULT FALSE,
    edited_resolution     TEXT,
    recorded_at           TIMESTAMPTZ NOT NULL
);
"""

_CREATE_INDEX_VERDICTS_SQL = """
CREATE INDEX IF NOT EXISTS idx_review_verdicts_lookup ON review_verdicts (github_user_id, repo_owner, repo_name, issue_number);
"""

_CREATE_WEBHOOK_EVENTS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS webhook_events (
    id                    SERIAL PRIMARY KEY,
    event_type            VARCHAR(64) NOT NULL,
    action                VARCHAR(64) NOT NULL,
    delivery_id           VARCHAR(128),
    repo_full_name        VARCHAR(255) NOT NULL,
    sender_id             BIGINT,
    sender_login          VARCHAR(255),
    summary               TEXT,
    received_at           TIMESTAMPTZ NOT NULL
);
"""

_CREATE_INDEX_WEBHOOK_EVENTS_SQL = """
CREATE INDEX IF NOT EXISTS idx_webhook_events_user ON webhook_events (sender_id, repo_full_name);
"""

_CREATE_BUGSENSE_USERS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS bugsense_users (
    id                    SERIAL PRIMARY KEY,
    full_name             VARCHAR(255) NOT NULL,
    username              VARCHAR(255) UNIQUE NOT NULL,
    email                 VARCHAR(255) UNIQUE NOT NULL,
    password_hash         VARCHAR(255) NOT NULL,
    github_user_id        BIGINT,
    created_at            TIMESTAMPTZ NOT NULL
);
"""

_CREATE_BUGSENSE_SESSIONS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS bugsense_sessions (
    session_token         VARCHAR(64) PRIMARY KEY,
    user_id               INTEGER NOT NULL REFERENCES bugsense_users(id),
    created_at            TIMESTAMPTZ NOT NULL,
    expires_at            TIMESTAMPTZ NOT NULL
);
"""

# In-memory test / fallback stores (active only if DB pool unavailable or mock without table support)
_fallback_verdicts: list[dict[str, Any]] = []
_fallback_webhook_events: list[dict[str, Any]] = []


def _init_db(pool: Any) -> None:
    """Ensure session, review verdict, and webhook tables and indexes exist."""
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(_CREATE_TABLE_SQL)
                cur.execute(_CREATE_INDEX_EXPIRES_SQL)
                cur.execute(_CREATE_INDEX_USER_SQL)
                cur.execute(_CREATE_VERDICTS_TABLE_SQL)
                cur.execute(_CREATE_INDEX_VERDICTS_SQL)
                cur.execute(_CREATE_WEBHOOK_EVENTS_TABLE_SQL)
                cur.execute(_CREATE_INDEX_WEBHOOK_EVENTS_SQL)
                cur.execute(_CREATE_BUGSENSE_USERS_TABLE_SQL)
                cur.execute(_CREATE_BUGSENSE_SESSIONS_TABLE_SQL)
    except Exception:
        # Tables will be created by migrations or on first connect
        pass


def get_db_pool() -> Any:
    """Return the shared PostgreSQL connection pool (thread-safe, multi-worker)."""
    global _pool
    if _pool is not None:
        return _pool

    db_url = get_database_url()
    _pool = ConnectionPool(
        conninfo=db_url,
        min_size=1,
        max_size=20,
        kwargs={"row_factory": dict_row},
        open=True,
    )
    _init_db(_pool)
    return _pool


def set_db_pool(pool: Any | None) -> None:
    """Override the database pool (used for testing or dependency injection)."""
    global _pool
    _pool = pool


def close_pool() -> None:
    """
    Safely close the existing PostgreSQL ConnectionPool on application shutdown.

    If the pool was never initialized, does nothing.
    Safe to call more than once (idempotent).
    """
    global _pool
    if _pool is not None:
        if hasattr(_pool, "close"):
            try:
                _pool.close()
            except Exception:
                pass
        _pool = None


def reset_db_pool() -> None:
    """Close and reset the database pool (test utility alias for close_pool)."""
    close_pool()


# ──────────────────────────────────────────────
# BugSense Users & Sessions
# ──────────────────────────────────────────────

def create_bugsense_user(
    *,
    full_name: str,
    username: str,
    email: str,
    password_hash: str,
) -> int:
    """Create a new local BugSense user."""
    pool = get_db_pool()
    now = datetime.now(timezone.utc)
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO bugsense_users (full_name, username, email, password_hash, created_at)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (full_name, username, email, password_hash, now)
                )
                result = cur.fetchone()
                return result["id"] if result else 0
    except psycopg.errors.UniqueViolation as e:
        if "username" in str(e):
            raise ValueError("Username already exists")
        elif "email" in str(e):
            raise ValueError("Email already exists")
        raise
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Database temporarily unavailable: {str(e)}",
        ) from e


def get_bugsense_user_by_email_or_username(identifier: str) -> dict[str, Any] | None:
    """Look up a BugSense user by username or email."""
    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, full_name, username, email, password_hash, github_user_id, created_at
                    FROM bugsense_users
                    WHERE LOWER(email) = LOWER(%s) OR LOWER(username) = LOWER(%s)
                    """,
                    (identifier, identifier)
                )
                row = cur.fetchone()
                if row:
                    return dict(row)
    except Exception:
        return None
    return None

def link_github_to_bugsense_user(user_id: int, github_user_id: int) -> bool:
    """Link a GitHub user ID to a BugSense account."""
    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE bugsense_users
                    SET github_user_id = %s
                    WHERE id = %s
                    """,
                    (github_user_id, user_id)
                )
                return cur.rowcount > 0
    except Exception:
        return False

def create_bugsense_session(user_id: int, ttl_seconds: int = _DEFAULT_TTL_SECONDS) -> str:
    """Create a new BugSense local session token."""
    session_token = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=ttl_seconds)

    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO bugsense_sessions (session_token, user_id, created_at, expires_at)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (session_token, user_id, now, expires)
                )
    except Exception as e:
        raise HTTPException(status_code=503, detail="Database unavailable") from e
    return session_token

def get_bugsense_session(session_token: str) -> dict[str, Any] | None:
    """Get an active BugSense session."""
    if not session_token:
        return None
    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT s.session_token, s.user_id, s.created_at, s.expires_at,
                           u.full_name, u.username, u.email, u.github_user_id
                    FROM bugsense_sessions s
                    JOIN bugsense_users u ON s.user_id = u.id
                    WHERE s.session_token = %s
                    """,
                    (session_token,)
                )
                row = cur.fetchone()
    except Exception:
        return None

    if row is None:
        return None
    data = dict(row)
    expires_at = data["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)

    if datetime.now(timezone.utc) > expires_at:
        delete_bugsense_session(session_token)
        return None
        
    if isinstance(data["created_at"], datetime):
        data["created_at"] = data["created_at"].isoformat()
    if isinstance(data["expires_at"], datetime):
        data["expires_at"] = data["expires_at"].isoformat()
    return data

def delete_bugsense_session(session_token: str) -> bool:
    if not session_token:
        return False
    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM bugsense_sessions WHERE session_token = %s", (session_token,))
                return cur.rowcount > 0
    except Exception:
        return False

# ──────────────────────────────────────────────
# Session Operations (GitHub)
# ──────────────────────────────────────────────

def create_session(
    *,
    github_user_id: int,
    github_login: str,
    github_access_token: str,
    github_avatar_url: str = "",
    github_name: str = "",
    ttl_seconds: int = _DEFAULT_TTL_SECONDS,
) -> str:
    """
    Create a new durable session in PostgreSQL and return the BugSense session token.
    GitHub access token is encrypted at the application level before database write.
    """
    session_id = secrets.token_urlsafe(36)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=ttl_seconds)

    encrypted_token = _encrypt_token(github_access_token)

    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO sessions
                        (session_id, github_user_id, github_login, github_avatar_url,
                         github_name, github_access_token, created_at, expires_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        session_id,
                        github_user_id,
                        github_login,
                        github_avatar_url,
                        github_name,
                        encrypted_token,
                        now,
                        expires,
                    ),
                )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Authentication database temporarily unavailable: {str(e)}",
        ) from e

    return session_id


def get_session(session_id: str) -> dict[str, Any] | None:
    """
    Look up a session by its BugSense session token.
    Returns None if the session doesn't exist or has expired.
    Decrypts the stored GitHub access token in memory before returning.
    """
    if not session_id:
        return None

    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT session_id, github_user_id, github_login, github_avatar_url,
                           github_name, github_access_token, created_at, expires_at
                    FROM sessions
                    WHERE session_id = %s
                    """,
                    (session_id,),
                )
                row = cur.fetchone()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Authentication database temporarily unavailable: {str(e)}",
        ) from e

    if row is None:
        return None

    data = dict(row)

    # Validate expiration
    expires_at = data["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)

    if datetime.now(timezone.utc) > expires_at:
        delete_session(session_id)
        return None

    # Format timestamps as standard ISO strings
    if isinstance(data["created_at"], datetime):
        data["created_at"] = data["created_at"].isoformat()
    if isinstance(data["expires_at"], datetime):
        data["expires_at"] = data["expires_at"].isoformat()

    # Decrypt token in memory
    data["github_access_token"] = _decrypt_token(data["github_access_token"])
    return data


def get_github_token_for_session(session_id: str) -> str | None:
    """
    Resolve a BugSense session token to the user's decrypted GitHub access token.
    Returns None if the session is invalid or expired.
    This value must NEVER be sent to the client.
    """
    session = get_session(session_id)
    if session is None:
        return None
    return session["github_access_token"]


def delete_session(session_id: str) -> bool:
    """Delete a session (logout). Returns True if a row was deleted."""
    if not session_id:
        return False

    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM sessions WHERE session_id = %s",
                    (session_id,),
                )
                return cur.rowcount > 0
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Authentication database temporarily unavailable: {str(e)}",
        ) from e


def cleanup_expired() -> int:
    """Remove all expired sessions from PostgreSQL. Returns count of deleted rows."""
    now = datetime.now(timezone.utc)
    pool = get_db_pool()
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM sessions WHERE expires_at < %s",
                    (now,),
                )
                return cur.rowcount
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Authentication database temporarily unavailable: {str(e)}",
        ) from e


# ──────────────────────────────────────────────
# Step 19 Redis Handoff Code (Unmodified)
# ──────────────────────────────────────────────

def create_handoff_code(session_token: str) -> str:
    """
    Create a short-lived (2 minutes) one-time code for mobile handoff stored in Redis.
    Preserves 36-byte token_urlsafe code generation.
    """
    if not session_token:
        raise ValueError("Session token cannot be empty.")
    code = secrets.token_urlsafe(36)
    try:
        client = get_redis_client()
        client.set(f"handoff_code:{code}", session_token, ex=_HANDOFF_TTL_SECONDS)
    except redis.RedisError as e:
        raise HTTPException(
            status_code=503,
            detail="Authentication service temporarily unavailable (handoff store error).",
        ) from e
    return code


def exchange_handoff_code(code: str) -> str | None:
    """
    Exchange a one-time code for the session token.
    Invalidates code immediately via atomic Redis GETDEL.
    Returns None if invalid, expired, or already used.
    """
    if not code:
        return None
    try:
        client = get_redis_client()
        session_token = client.getdel(f"handoff_code:{code}")
        return session_token
    except redis.RedisError as e:
        raise HTTPException(
            status_code=503,
            detail="Authentication service temporarily unavailable (handoff store error).",
        ) from e


# ──────────────────────────────────────────────
# Human Review Verdicts (PostgreSQL Persistence)
# ──────────────────────────────────────────────

def save_review_verdict(
    *,
    github_user_id: int,
    github_login: str,
    repo_owner: str,
    repo_name: str,
    issue_number: int,
    verdict: str,
    reviewer: str = "human_reviewer",
    rejection_reason: str | None = None,
    notes: str = "",
    has_edited_resolution: bool = False,
    edited_resolution: dict[str, Any] | None = None,
    recorded_at: str | None = None,
) -> dict[str, Any]:
    """Persist human review decision in PostgreSQL scoped to github_user_id."""
    if recorded_at is None:
        recorded_at = datetime.now(timezone.utc).isoformat()

    edited_res_str = json.dumps(edited_resolution) if edited_resolution else None

    record = {
        "github_user_id": github_user_id,
        "github_login": github_login,
        "repo_owner": repo_owner,
        "repo_name": repo_name,
        "issue_number": issue_number,
        "verdict": verdict,
        "reviewer": reviewer,
        "rejection_reason": rejection_reason,
        "notes": notes,
        "has_edited_resolution": has_edited_resolution,
        "edited_resolution": edited_resolution,
        "recorded_at": recorded_at,
    }

    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO review_verdicts (
                        github_user_id, github_login, repo_owner, repo_name,
                        issue_number, verdict, reviewer, rejection_reason,
                        notes, has_edited_resolution, edited_resolution, recorded_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        github_user_id,
                        github_login,
                        repo_owner,
                        repo_name,
                        issue_number,
                        verdict,
                        reviewer,
                        rejection_reason,
                        notes,
                        has_edited_resolution,
                        edited_res_str,
                        recorded_at,
                    ),
                )
    except Exception:
        _fallback_verdicts.append(record)
        return record

    return record


def get_review_verdicts(
    *,
    github_user_id: int,
    repo_owner: str | None = None,
    repo_name: str | None = None,
    issue_number: int | None = None,
) -> list[dict[str, Any]]:
    """Retrieve human review decisions strictly scoped to authenticated github_user_id."""
    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                query = "SELECT * FROM review_verdicts WHERE github_user_id = %s"
                params: list[Any] = [github_user_id]
                if repo_owner:
                    query += " AND LOWER(repo_owner) = LOWER(%s)"
                    params.append(repo_owner)
                if repo_name:
                    query += " AND LOWER(repo_name) = LOWER(%s)"
                    params.append(repo_name)
                if issue_number is not None:
                    query += " AND issue_number = %s"
                    params.append(issue_number)
                query += " ORDER BY recorded_at ASC"
                cur.execute(query, tuple(params))
                rows = cur.fetchall()
                if rows is not None:
                    results = []
                    for r in rows:
                        row_dict = dict(r)
                        if isinstance(row_dict.get("edited_resolution"), str):
                            try:
                                row_dict["edited_resolution"] = json.loads(row_dict["edited_resolution"])
                            except Exception:
                                pass
                        if isinstance(row_dict.get("recorded_at"), datetime):
                            row_dict["recorded_at"] = row_dict["recorded_at"].isoformat()
                        results.append(row_dict)
                    return results
    except Exception:
        pass

    filtered = [v for v in _fallback_verdicts if v.get("github_user_id") == github_user_id]
    if repo_owner:
        filtered = [v for v in filtered if v["repo_owner"].lower() == repo_owner.lower()]
    if repo_name:
        filtered = [v for v in filtered if v["repo_name"].lower() == repo_name.lower()]
    if issue_number is not None:
        filtered = [v for v in filtered if v["issue_number"] == issue_number]
    return filtered


def get_latest_review_verdict(
    repo_owner: str,
    repo_name: str,
    issue_number: int,
    github_user_id: int | None = None,
) -> dict[str, Any] | None:
    """Retrieve the latest human review decision for an issue."""
    if github_user_id is not None:
        verdicts = get_review_verdicts(
            github_user_id=github_user_id,
            repo_owner=repo_owner,
            repo_name=repo_name,
            issue_number=issue_number,
        )
        return verdicts[-1] if verdicts else None

    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT * FROM review_verdicts 
                    WHERE LOWER(repo_owner) = LOWER(%s) AND LOWER(repo_name) = LOWER(%s) AND issue_number = %s
                    ORDER BY recorded_at DESC LIMIT 1
                    """,
                    (repo_owner, repo_name, issue_number),
                )
                row = cur.fetchone()
                if row:
                    row_dict = dict(row)
                    if isinstance(row_dict.get("edited_resolution"), str):
                        try:
                            row_dict["edited_resolution"] = json.loads(row_dict["edited_resolution"])
                        except Exception:
                            pass
                    if isinstance(row_dict.get("recorded_at"), datetime):
                        row_dict["recorded_at"] = row_dict["recorded_at"].isoformat()
                    return row_dict
    except Exception:
        pass

    matches = [
        v for v in _fallback_verdicts
        if v["repo_owner"].lower() == repo_owner.lower()
        and v["repo_name"].lower() == repo_name.lower()
        and v["issue_number"] == issue_number
    ]
    return matches[-1] if matches else None


# ──────────────────────────────────────────────
# Webhook Events (PostgreSQL Persistence)
# ──────────────────────────────────────────────

def save_webhook_event(
    *,
    event_type: str,
    action: str,
    delivery_id: str | None = None,
    repo_full_name: str,
    sender_id: int | None = None,
    sender_login: str | None = None,
    summary: dict[str, Any] | None = None,
    received_at: str | None = None,
) -> dict[str, Any]:
    """Persist webhook event metadata in PostgreSQL."""
    if received_at is None:
        received_at = datetime.now(timezone.utc).isoformat()

    summary_str = json.dumps(summary) if summary else None
    record = {
        "event_type": event_type,
        "action": action,
        "delivery_id": delivery_id,
        "repo_full_name": repo_full_name,
        "sender_id": sender_id,
        "sender_login": sender_login,
        "summary": summary,
        "received_at": received_at,
    }

    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO webhook_events (
                        event_type, action, delivery_id, repo_full_name,
                        sender_id, sender_login, summary, received_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        event_type,
                        action,
                        delivery_id,
                        repo_full_name,
                        sender_id,
                        sender_login,
                        summary_str,
                        received_at,
                    ),
                )
    except Exception:
        _fallback_webhook_events.append(record)
        return record

    return record


def get_webhook_events(
    *,
    github_user_id: int,
    repo_full_name: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Retrieve webhook events scoped to the authenticated user's ID or repository."""
    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                if repo_full_name:
                    cur.execute(
                        """
                        SELECT * FROM webhook_events 
                        WHERE LOWER(repo_full_name) = LOWER(%s)
                        ORDER BY received_at DESC LIMIT %s
                        """,
                        (repo_full_name, limit),
                    )
                else:
                    cur.execute(
                        """
                        SELECT * FROM webhook_events 
                        WHERE sender_id = %s
                        ORDER BY received_at DESC LIMIT %s
                        """,
                        (github_user_id, limit),
                    )
                rows = cur.fetchall()
                if rows is not None:
                    results = []
                    for r in rows:
                        row_dict = dict(r)
                        if isinstance(row_dict.get("summary"), str):
                            try:
                                row_dict["summary"] = json.loads(row_dict["summary"])
                            except Exception:
                                pass
                        if isinstance(row_dict.get("received_at"), datetime):
                            row_dict["received_at"] = row_dict["received_at"].isoformat()
                        results.append(row_dict)
                    return results
    except Exception:
        pass

    if repo_full_name:
        filtered = [e for e in _fallback_webhook_events if e.get("repo_full_name", "").lower() == repo_full_name.lower()]
    else:
        filtered = [e for e in _fallback_webhook_events if e.get("sender_id") == github_user_id]
    filtered.reverse()
    return filtered[:limit]


def delete_user_data(github_user_id: int) -> bool:
    """Delete all local data for a GitHub user, including sessions, verdicts, and webhook events."""
    try:
        pool = get_db_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                # First delete references from bugsense_sessions to bugsense_users
                cur.execute(
                    """
                    DELETE FROM bugsense_sessions 
                    WHERE user_id IN (SELECT id FROM bugsense_users WHERE github_user_id = %s)
                    """,
                    (github_user_id,)
                )
                cur.execute("DELETE FROM bugsense_users WHERE github_user_id = %s", (github_user_id,))
                cur.execute("DELETE FROM sessions WHERE github_user_id = %s", (github_user_id,))
                cur.execute("DELETE FROM review_verdicts WHERE github_user_id = %s", (github_user_id,))
                cur.execute("DELETE FROM webhook_events WHERE sender_id = %s", (github_user_id,))
            conn.commit()
            
        # Clean up fallback in-memory stores
        global _fallback_sessions, _fallback_verdicts, _fallback_webhook_events, _fallback_bugsense_users
        _fallback_sessions = {k: v for k, v in _fallback_sessions.items() if v.get("github_user_id") != github_user_id}
        _fallback_verdicts = {k: v for k, v in _fallback_verdicts.items() if v.get("github_user_id") != github_user_id}
        _fallback_webhook_events = [e for e in _fallback_webhook_events if e.get("sender_id") != github_user_id]
        _fallback_bugsense_users = {k: v for k, v in _fallback_bugsense_users.items() if v.get("github_user_id") != github_user_id}
        
        return True
    except Exception as e:
        logger.error("Failed to delete user data from DB: %s", e)
        return False
