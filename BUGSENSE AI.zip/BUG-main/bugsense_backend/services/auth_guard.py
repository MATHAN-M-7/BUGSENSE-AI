"""
Authentication and authorization guard for BugSense AI endpoints.

Provides a single, consistent mechanism to:
1. Require and validate a BugSense session from the Authorization header.
2. Resolve the authenticated GitHub user identity (user_id, login, token).
3. Verify that the authenticated user has access to a specific GitHub repository.

SECURITY RULES:
- User-facing endpoints MUST call require_auth() which raises HTTP 401 on failure.
- Repository-scoped operations MUST call verify_repo_access() before touching
  Firestore, ChromaDB, or GitHub resources for that repo.
- The developer PAT (config.get_github_token) is NEVER used as a silent fallback
  for user-facing operations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx
from fastapi import HTTPException

from services import session_store

_API_BASE = "https://api.github.com"


@dataclass(frozen=True)
class AuthenticatedUser:
    """Immutable identity of an authenticated BugSense user."""
    github_user_id: int
    github_login: str
    github_token: str          # The user's OAuth access token (server-side only)
    session_id: str            # The BugSense session token


def require_auth(authorization: str | None) -> AuthenticatedUser:
    """
    Validate the Authorization header and return the authenticated user.

    Raises HTTP 401 if the header is missing, malformed, or the session
    is invalid/expired.

    This function NEVER falls back to the developer PAT.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Missing or malformed Authorization header. "
                   "Provide: Authorization: Bearer <session_token>",
        )

    bearer_value = authorization.split("Bearer ", 1)[1].strip()
    if not bearer_value:
        raise HTTPException(
            status_code=401,
            detail="Empty Bearer token.",
        )

    # Look up the session
    session = session_store.get_session(bearer_value)
    if session is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired session. Please log in again.",
        )

    github_token = session.get("github_access_token")
    if not github_token:
        raise HTTPException(
            status_code=401,
            detail="Session has no associated GitHub token. Please re-authenticate.",
        )

    return AuthenticatedUser(
        github_user_id=session["github_user_id"],
        github_login=session["github_login"],
        github_token=github_token,
        session_id=bearer_value,
    )


async def verify_repo_access(
    owner: str,
    repo: str,
    user: AuthenticatedUser,
) -> dict[str, Any]:
    """
    Verify that the authenticated user has access to the specified repository
    using THEIR GitHub OAuth token (not the developer PAT).

    Returns the repository metadata dict from GitHub on success.
    Raises HTTP 403 if the user cannot access the repo.
    Raises HTTP 502 if the GitHub API call fails for infrastructure reasons.
    """
    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(
                f"{_API_BASE}/repos/{owner}/{repo}",
                headers={
                    "Authorization": f"Bearer {user.github_token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                    "User-Agent": "BugSense-AI",
                },
            )
            if r.status_code == 200:
                return r.json()
            if r.status_code in (401, 403, 404):
                raise HTTPException(
                    status_code=403,
                    detail=f"You do not have access to repository {owner}/{repo}.",
                )
            r.raise_for_status()
    except HTTPException:
        raise
    except httpx.HTTPStatusError as e:
        raise HTTPException(
            status_code=502,
            detail=f"GitHub API error while verifying repository access: {e.response.status_code}",
        )
    except Exception as e:
        raise HTTPException(
            status_code=502,
            detail=f"Failed to verify repository access: {str(e)}",
        )

    # Should not reach here, but satisfy the type checker
    raise HTTPException(status_code=502, detail="Unexpected error verifying repo access.")


def user_scoped_collection_name(user: AuthenticatedUser, owner: str, repo: str) -> str:
    """
    Return a ChromaDB collection name scoped to a specific user and repository.

    Format: u{github_user_id}_{owner}_{repo}

    This ensures that User A's indexed data for repo X is stored in a
    different collection than User B's indexed data for the same repo X,
    preventing cross-user data leakage via semantic search.
    """
    return f"u{user.github_user_id}_{owner}_{repo}"
