"""
Classifier Agent — analyses GitHub issues using an LLM provider.

Orchestrates:
1. Formatting issue data into a prompt.
2. Calling the LLM provider for classification.
3. Persisting the analysis result to Firestore (if available).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from services.llm_provider import IssueClassification, get_llm_provider

logger = logging.getLogger("bugsense.classifier")


def _format_issue_text(issue_data: dict[str, Any]) -> str:
    """Format issue data into a text representation for the LLM."""
    parts = []

    title = issue_data.get("title", "")
    if title:
        parts.append(f"**Title:** {title}")

    body = issue_data.get("body") or ""
    if body:
        # Truncate very long bodies to stay within token limits
        if len(body) > 4000:
            body = body[:4000] + "\n... [truncated]"
        parts.append(f"**Body:**\n{body}")

    state = issue_data.get("state", "")
    if state:
        parts.append(f"**State:** {state}")

    labels = issue_data.get("labels", [])
    if labels:
        if isinstance(labels[0], dict):
            label_names = [lbl.get("name", "") for lbl in labels]
        else:
            label_names = labels
        parts.append(f"**Labels:** {', '.join(label_names)}")

    comments = issue_data.get("comments_text", [])
    if comments:
        comments_str = "\n".join(f"- {c}" for c in comments[:5])
        parts.append(f"**Comments:**\n{comments_str}")

    return "\n\n".join(parts)


async def classify_issue(issue_data: dict[str, Any]) -> dict[str, Any]:
    """
    Classify a GitHub issue.

    Args:
        issue_data: Dict containing at minimum 'title' and optionally
                    'body', 'state', 'labels', 'comments_text',
                    'repo_owner', 'repo_name', 'issue_number'.

    Returns:
        Dict with classification results and metadata.
    """
    provider = get_llm_provider()

    # Format the issue into a text prompt
    issue_text = _format_issue_text(issue_data)
    logger.info(
        "Classifying issue: %s/%s#%s '%s'",
        issue_data.get("repo_owner", "?"),
        issue_data.get("repo_name", "?"),
        issue_data.get("issue_number", "?"),
        issue_data.get("title", "")[:50],
    )

    # Call the LLM
    classification: IssueClassification = await provider.classify_issue(issue_text)

    # Build the result
    now = datetime.now(timezone.utc).isoformat()
    result = {
        "repo_owner": issue_data.get("repo_owner", ""),
        "repo_name": issue_data.get("repo_name", ""),
        "issue_number": issue_data.get("issue_number"),
        "issue_title": issue_data.get("title", ""),
        "category": classification.category.value,
        "severity": classification.severity.value,
        "category_confidence": classification.category_confidence,
        "severity_confidence": classification.severity_confidence,
        "confidence": classification.category_confidence,
        "evidence_summary": classification.evidence_summary,
        "model": provider.model_name,
        "analyzed_at": now,
        "analyzed_by": "classifier_agent_v1",
        "github_user_id": issue_data.get("_github_user_id"),
    }

    # Persist to Firestore (best-effort)
    analysis_id = _try_persist(result)
    if analysis_id:
        result["analysis_id"] = analysis_id

    return result


async def classify_issue_with_rag(issue_data: dict[str, Any], similar_issues: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """
    Classify a GitHub issue using RAG — retrieves similar past issues
    from ChromaDB and injects them as context for the LLM.

    Falls back to standard classification if ChromaDB is empty or unavailable.

    Args:
        issue_data: Dict containing at minimum 'title' and optionally
                    'body', 'state', 'labels', 'comments_text',
                    'repo_owner', 'repo_name', 'issue_number'.

    Returns:
        Dict with classification results, metadata, and rag_context.
    """
    provider = get_llm_provider()
    issue_text = _format_issue_text(issue_data)

    repo_owner = issue_data.get("repo_owner", "")
    repo_name = issue_data.get("repo_name", "")

    logger.info(
        "RAG classifying issue: %s/%s#%s '%s'",
        repo_owner,
        repo_name,
        issue_data.get("issue_number", "?"),
        issue_data.get("title", "")[:50],
    )

    # 1. Retrieve similar issues from ChromaDB if not provided
    if similar_issues is None:
        github_user_id = issue_data.get("_github_user_id")
        import asyncio
        try:
            similar_issues = await asyncio.wait_for(
                asyncio.to_thread(
                    _retrieve_similar_issues, repo_owner, repo_name, issue_text, 3, github_user_id
                ),
                timeout=75.0
            )
        except Exception as exc:
            logger.warning("Retrieval blocked or failed: %s", exc)
            similar_issues = []

    # 2. Classify with or without RAG context
    if similar_issues:
        classification = await provider.classify_issue_with_context(
            issue_text, similar_issues
        )
        rag_used = True
    else:
        logger.info("No similar issues found — falling back to standard classification")
        classification = await provider.classify_issue(issue_text)
        rag_used = False

    # 3. Build the result
    now = datetime.now(timezone.utc).isoformat()
    result = {
        "repo_owner": repo_owner,
        "repo_name": repo_name,
        "issue_number": issue_data.get("issue_number"),
        "issue_title": issue_data.get("title", ""),
        "category": classification.category.value,
        "severity": classification.severity.value,
        "category_confidence": classification.category_confidence,
        "severity_confidence": classification.severity_confidence,
        "confidence": classification.category_confidence,
        "evidence_summary": classification.evidence_summary,
        "model": provider.model_name,
        "analyzed_at": now,
        "analyzed_by": "classifier_agent_v1_rag",
        "rag_used": rag_used,
        "rag_context": [
            {
                "issue_id": si.get("id", ""),
                "title": si.get("metadata", {}).get("title", ""),
                "category": si.get("metadata", {}).get("category", ""),
                "severity": si.get("metadata", {}).get("severity", ""),
                "similarity": si.get("similarity", 0),
            }
            for si in similar_issues
        ],
        "github_user_id": issue_data.get("_github_user_id"),
    }

    # Persist to Firestore (best-effort)
    analysis_id = _try_persist(result)
    if analysis_id:
        result["analysis_id"] = analysis_id

    return result


def _retrieve_similar_issues(
    repo_owner: str, repo_name: str, issue_text: str, n_results: int = 3, github_user_id: int | None = None
) -> list[dict[str, Any]]:
    """Retrieve similar issues from ChromaDB. Returns [] on failure."""
    if not repo_owner or not repo_name:
        return []
    try:
        from services.vector_store import get_vector_store

        store = get_vector_store()
        results = store.search_similar(
            repo_owner=repo_owner,
            repo_name=repo_name,
            query=issue_text,
            n_results=n_results,
            github_user_id=github_user_id,
        )
        logger.info("Retrieved %d similar issues from ChromaDB", len(results))
        return results
    except Exception as exc:
        logger.debug("ChromaDB retrieval failed: %s", exc)
        return []


def _try_persist(result: dict[str, Any]) -> str | None:
    """Best-effort persist analysis to Firestore. Returns doc ID or None."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        _, doc_ref = db.collection("analyses").add(result)
        logger.info("Analysis persisted to Firestore: %s", doc_ref.id)
        return doc_ref.id
    except Exception as exc:
        logger.debug("Firestore persistence skipped: %s", exc)
        return None


def get_analysis(analysis_id: str) -> dict[str, Any] | None:
    """Retrieve a stored analysis from Firestore."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        doc = db.collection("analyses").document(analysis_id).get()
        if doc.exists:
            data = doc.to_dict()
            data["analysis_id"] = doc.id
            return data
        return None
    except Exception:
        return None


def list_analyses(limit: int = 20, github_user_id: int | None = None) -> list[dict[str, Any]]:
    """List recent analyses from Firestore (user-scoped when github_user_id provided)."""
    try:
        from services.firestore_service import get_db, init_firestore

        init_firestore()
        db = get_db()
        query = db.collection("analyses")
        if github_user_id is not None:
            query = query.where("github_user_id", "==", github_user_id)
        query = (
            query
            .order_by("analyzed_at", direction="DESCENDING")
            .limit(limit)
        )
        results = []
        for doc in query.stream():
            data = doc.to_dict()
            data["analysis_id"] = doc.id
            results.append(data)
        return results
    except Exception:
        return []
