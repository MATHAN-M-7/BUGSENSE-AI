"""
GitHub OAuth 2.0 authentication service.

Handles:
- Generating OAuth authorization URLs with CSRF state protection.
- Exchanging OAuth authorization codes for GitHub access tokens.
"""

from __future__ import annotations

import secrets
from typing import Any
from urllib.parse import urlencode

import httpx
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

from config import (
    get_github_client_id,
    get_github_client_secret,
    get_github_redirect_uri,
)

_GITHUB_AUTH_URL = "https://github.com/login/oauth/authorize"
_GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
_DEFAULT_SCOPES = "repo,read:user"


def create_authorization_url(state: str | None = None) -> tuple[str, str]:
    """
    Generate a GitHub OAuth authorization URL and a secure CSRF state token.

    Returns:
        tuple[str, str]: (authorization_url, state)
    """
    if not state:
        state = secrets.token_urlsafe(24)

    params = {
        "client_id": get_github_client_id(),
        "redirect_uri": get_github_redirect_uri(),
        "scope": _DEFAULT_SCOPES,
        "state": state,
        "prompt": "select_account",  # Force GitHub account picker on every login
    }
    auth_url = f"{_GITHUB_AUTH_URL}?{urlencode(params)}"
    return auth_url, state


async def exchange_code_for_token(
    code: str,
    state: str | None = None,
) -> dict[str, Any]:
    """
    Exchange a temporary OAuth code for a GitHub access token.

    Args:
        code: The authorization code returned by GitHub.
        state: Optional state parameter to echo or verify.

    Returns:
        dict[str, Any]: Access token response from GitHub.
    """
    client_id = get_github_client_id()
    client_secret = get_github_client_secret()
    redirect_uri = get_github_redirect_uri()

    payload = {
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "redirect_uri": redirect_uri,
    }
    if state:
        payload["state"] = state

    headers = {
        "Accept": "application/json",
        "User-Agent": "BugSense-AI",
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(
            _GITHUB_TOKEN_URL,
            data=payload,
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

    if "error" in data:
        error_desc = data.get("error_description", data["error"])
        raise ValueError(f"GitHub OAuth error: {error_desc}")

    return data
