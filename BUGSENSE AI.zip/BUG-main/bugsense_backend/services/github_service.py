"""
GitHub API service layer.

All GitHub REST API v3 calls go through this module.
Uses httpx for async HTTP.
Accepts an optional user OAuth token, falling back to the configured GITHUB_TOKEN in config.
"""

from __future__ import annotations

from typing import Any

import httpx

from config import get_github_token, is_production

_API_BASE = "https://api.github.com"


def _headers(token: str | None = None) -> dict[str, str]:
    if token:
        auth_token = token
    else:
        if is_production():
            raise RuntimeError(
                "Missing user GitHub authorization token in production. "
                "Developer PAT fallback is strictly disabled on protected operations."
            )
        auth_token = get_github_token()
    return {
        "Authorization": f"Bearer {auth_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "BugSense-AI",
    }


async def get_authenticated_user(token: str | None = None) -> dict[str, Any]:
    """GET /user — returns the authenticated user's profile."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{_API_BASE}/user", headers=_headers(token))
        r.raise_for_status()
        return r.json()


async def list_repos(
    per_page: int = 30,
    page: int = 1,
    token: str | None = None,
) -> list[dict[str, Any]]:
    """GET /user/repos — returns repos visible to the authenticated user."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/user/repos",
            headers=_headers(token),
            params={
                "per_page": per_page,
                "page": page,
                "sort": "updated",
                "direction": "desc",
            },
        )
        r.raise_for_status()
        return r.json()


async def get_repo(
    owner: str,
    repo: str,
    token: str | None = None,
) -> dict[str, Any]:
    """GET /repos/{owner}/{repo} — returns full repository details."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}",
            headers=_headers(token),
        )
        r.raise_for_status()
        return r.json()


async def list_issues(
    owner: str,
    repo: str,
    state: str = "open",
    per_page: int = 30,
    page: int = 1,
    token: str | None = None,
) -> list[dict[str, Any]]:
    """GET /repos/{owner}/{repo}/issues — returns issues (excludes PRs)."""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}/issues",
            headers=_headers(token),
            params={
                "state": state,
                "per_page": per_page,
                "page": page,
            },
        )
        r.raise_for_status()
        # GitHub returns PRs in the issues endpoint; filter them out
        return [i for i in r.json() if "pull_request" not in i]


async def get_issue(
    owner: str,
    repo: str,
    issue_number: int,
    token: str | None = None,
) -> dict[str, Any]:
    """GET /repos/{owner}/{repo}/issues/{issue_number}"""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}/issues/{issue_number}",
            headers=_headers(token),
        )
        r.raise_for_status()
        return r.json()


async def list_issue_comments(
    owner: str,
    repo: str,
    issue_number: int,
    per_page: int = 30,
    page: int = 1,
    token: str | None = None,
) -> list[dict[str, Any]]:
    """GET /repos/{owner}/{repo}/issues/{issue_number}/comments"""
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}/issues/{issue_number}/comments",
            headers=_headers(token),
            params={
                "per_page": per_page,
                "page": page,
            },
        )
        r.raise_for_status()
        return r.json()


# ──────────────────────────────────────────────
# Pull Request Automation
# ──────────────────────────────────────────────

async def get_default_branch(owner: str, repo: str, token: str | None = None) -> str:
    """GET /repos/{owner}/{repo} -> returns default branch name."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{_API_BASE}/repos/{owner}/{repo}", headers=_headers(token))
        r.raise_for_status()
        return r.json().get("default_branch", "main")


async def get_ref_sha(owner: str, repo: str, branch: str, token: str | None = None) -> str:
    """GET /repos/{owner}/{repo}/git/ref/heads/{branch} -> returns commit SHA."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{_API_BASE}/repos/{owner}/{repo}/git/ref/heads/{branch}", headers=_headers(token))
        r.raise_for_status()
        return r.json().get("object", {}).get("sha", "")


async def create_branch(owner: str, repo: str, branch_name: str, sha: str, token: str | None = None) -> dict[str, Any]:
    """POST /repos/{owner}/{repo}/git/refs -> creates a new branch."""
    payload = {
        "ref": f"refs/heads/{branch_name}",
        "sha": sha
    }
    async with httpx.AsyncClient() as client:
        r = await client.post(f"{_API_BASE}/repos/{owner}/{repo}/git/refs", headers=_headers(token), json=payload)
        r.raise_for_status()
        return r.json()


async def create_or_update_file(
    owner: str,
    repo: str,
    path: str,
    message: str,
    content: str,  # plain text, will be b64 encoded
    branch: str,
    token: str | None = None,
) -> dict[str, Any]:
    """PUT /repos/{owner}/{repo}/contents/{path} -> creates/updates a file."""
    import base64
    b64_content = base64.b64encode(content.encode("utf-8")).decode("utf-8")
    payload = {
        "message": message,
        "content": b64_content,
        "branch": branch,
    }
    # Check if file exists to get its SHA (required for updates)
    async with httpx.AsyncClient() as client:
        check_res = await client.get(f"{_API_BASE}/repos/{owner}/{repo}/contents/{path}?ref={branch}", headers=_headers(token))
        if check_res.status_code == 200:
            payload["sha"] = check_res.json().get("sha")
            
        r = await client.put(f"{_API_BASE}/repos/{owner}/{repo}/contents/{path}", headers=_headers(token), json=payload)
        r.raise_for_status()
        return r.json()


async def create_pull_request(
    owner: str,
    repo: str,
    title: str,
    body: str,
    head: str,
    base: str,
    token: str | None = None,
) -> dict[str, Any]:
    """POST /repos/{owner}/{repo}/pulls -> creates a pull request."""
    payload = {
        "title": title,
        "body": body,
        "head": head,
        "base": base,
    }
    async with httpx.AsyncClient() as client:
        r = await client.post(f"{_API_BASE}/repos/{owner}/{repo}/pulls", headers=_headers(token), json=payload)
        r.raise_for_status()
        return r.json()


async def ensure_branch(
    owner: str,
    repo: str,
    branch_name: str,
    base_branch: str | None = None,
    token: str | None = None,
) -> dict[str, Any]:
    """
    Idempotent branch creation:
    Returns existing branch if already present, or creates it from base_branch.
    """
    async with httpx.AsyncClient() as client:
        # Check if branch exists
        ref_res = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}/git/ref/heads/{branch_name}",
            headers=_headers(token),
        )
        if ref_res.status_code == 200:
            existing_sha = ref_res.json().get("object", {}).get("sha", "")
            return {"branch": branch_name, "sha": existing_sha, "is_new": False}

        # Resolve base branch and its SHA
        base = base_branch or await get_default_branch(owner, repo, token=token)
        base_sha = await get_ref_sha(owner, repo, base, token=token)
        if not base_sha:
            raise RuntimeError(f"Failed to resolve base commit SHA for branch '{base}'")

        # Create branch
        created = await create_branch(owner, repo, branch_name, base_sha, token=token)
        return {"branch": branch_name, "sha": base_sha, "is_new": True, "details": created}


async def find_pull_request(
    owner: str,
    repo: str,
    head_branch: str,
    state: str = "open",
    token: str | None = None,
) -> dict[str, Any] | None:
    """GET /repos/{owner}/{repo}/pulls -> finds existing PR by head branch."""
    head_param = f"{owner}:{head_branch}"
    async with httpx.AsyncClient() as client:
        r = await client.get(
            f"{_API_BASE}/repos/{owner}/{repo}/pulls",
            headers=_headers(token),
            params={"head": head_param, "state": state},
        )
        if r.status_code == 200:
            prs = r.json()
            if isinstance(prs, list) and len(prs) > 0:
                return prs[0]
        return None


async def update_pull_request(
    owner: str,
    repo: str,
    pull_number: int,
    title: str | None = None,
    body: str | None = None,
    state: str | None = None,
    token: str | None = None,
) -> dict[str, Any]:
    """PATCH /repos/{owner}/{repo}/pulls/{pull_number} -> updates title, body, or state."""
    payload: dict[str, Any] = {}
    if title is not None:
        payload["title"] = title
    if body is not None:
        payload["body"] = body
    if state is not None:
        payload["state"] = state

    async with httpx.AsyncClient() as client:
        r = await client.patch(
            f"{_API_BASE}/repos/{owner}/{repo}/pulls/{pull_number}",
            headers=_headers(token),
            json=payload,
        )
        r.raise_for_status()
        return r.json()


async def add_issue_comment(
    owner: str,
    repo: str,
    issue_or_pr_number: int,
    comment_body: str,
    token: str | None = None,
) -> dict[str, Any]:
    """POST /repos/{owner}/{repo}/issues/{issue_or_pr_number}/comments -> adds a comment."""
    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{_API_BASE}/repos/{owner}/{repo}/issues/{issue_or_pr_number}/comments",
            headers=_headers(token),
            json={"body": comment_body},
        )
        r.raise_for_status()
        return r.json()


async def add_labels_to_issue(
    owner: str,
    repo: str,
    number: int,
    labels: list[str],
    token: str | None = None,
) -> list[dict[str, Any]]:
    """POST /repos/{owner}/{repo}/issues/{number}/labels -> attaches labels."""
    async with httpx.AsyncClient() as client:
        r = await client.post(
            f"{_API_BASE}/repos/{owner}/{repo}/issues/{number}/labels",
            headers=_headers(token),
            json={"labels": labels},
        )
        if r.status_code in (200, 201):
            return r.json()
        return []


def build_pr_markdown(
    owner: str,
    repo: str,
    issue_number: int,
    issue_title: str,
    routing_result: dict[str, Any],
) -> str:
    """
    Builds a rich, publication-grade markdown body for a BugSense AI Pull Request.
    """
    conf = routing_result.get("system_confidence_report") or {}
    score = conf.get("system_confidence", 0.0)
    status = conf.get("system_status", "READY_FOR_PR")
    breakdown = conf.get("confidence_breakdown") or {}
    penalties = conf.get("penalties_applied") or []

    evidence = routing_result.get("evidence_report") or {}
    verdict = evidence.get("verdict", "UNKNOWN")
    evidence_score = evidence.get("evidence_score", 0.0)
    verified_claims = evidence.get("verified_claims") or []
    unverified_claims = evidence.get("unverified_claims") or []
    recommendations = evidence.get("recommendations") or []

    route_plan = routing_result.get("route_plan") or {}
    route = routing_result.get("route") or route_plan.get("route", "STANDARD")
    complexity_score = route_plan.get("complexity_score", 0.0)
    rationale = route_plan.get("rationale", "")

    resolution = routing_result.get("resolution") or {}
    fix_description = resolution.get("fix_description", "Automated patch generated by BugSense AI.")
    code_suggestions = resolution.get("code_suggestions") or []
    impl_strategy = resolution.get("implementation_strategy") or []
    testing_recs = resolution.get("testing_recommendations") or []
    risk_assessment = resolution.get("risk_assessment", "")

    # Format percentage
    pct = int(score * 100)
    is_human_edited = routing_result.get("is_human_edited") or resolution.get("is_human_edited", False)
    human_approved = routing_result.get("human_approved", False)

    lines = [
        f"## 🎯 BugSense AI Autonomous Resolution",
        f"",
        f"**Resolves #{issue_number}**: *{issue_title}*",
        f"",
    ]

    if is_human_edited:
        lines.extend([
            f"> [!TIP]",
            f"> **✏️ Human-in-the-Loop Refinement:** This resolution was reviewed, customized, and verified by an engineer on the Mobile Review Screen prior to Pull Request generation.",
            f"",
        ])
    elif human_approved:
        lines.extend([
            f"> [!NOTE]",
            f"> **🛡️ Human Review Sign-Off:** This resolution was explicitly authorized by human review on mobile.",
            f"",
        ])

    lines.extend([
        f"---",
        f"",
        f"### 🛡️ Confidence Engine Audit",
        f"",
        f"| Metric | Value | Status |",
        f"|---|---|---|",
        f"| **Overall System Confidence** | **{pct}%** (`{score:.3f}`) | `{status}` |",
        f"| **Deterministic Evidence Score** | **{int(evidence_score * 100)}%** | `{verdict}` |",
        f"| **LLM Self-Confidence** | {int(breakdown.get('llm_self_confidence', 0.0) * 100)}% | Evaluated |",
        f"| **RAG Context Similarity** | {int(breakdown.get('rag_avg_similarity', 0.0) * 100)}% | Evaluated |",
        f"| **Inverse Issue Complexity** | {int(breakdown.get('inverse_complexity', 0.0) * 100)}% | Evaluated |",
        f"",
    ])

    if penalties:
        lines.append(f"> [!WARNING]")
        lines.append(f"> **Penalties Applied During Confidence Synthesis:**")
        for p in penalties:
            lines.append(f"> - {p}")
        lines.append(f"")

    lines.extend([
        f"### 🤖 Adaptive Routing Trace",
        f"- **Selected Route:** `{route}`",
        f"- **Complexity Score:** `{complexity_score:.3f}`",
        f"- **Routing Rationale:** {rationale}",
        f"",
        f"### 🔍 Evidence-Based Validation",
        f"- **Verdict:** `{verdict}` ({len(verified_claims)} verified claims, {len(unverified_claims)} unverified)",
    ])

    if verified_claims:
        lines.append(f"#### Verified Assertions")
        for vc in verified_claims[:5]:
            lines.append(f"- [x] {vc}")
        lines.append(f"")

    lines.extend([
        f"### 📝 Fix Description & Changes",
        f"{fix_description}",
        f"",
    ])

    if code_suggestions:
        lines.append(f"#### Code Suggestions")
        for idx, cs in enumerate(code_suggestions):
            f_name = cs.get("file_or_component", f"File {idx+1}")
            desc = cs.get("change_description") or cs.get("explanation", "")
            snippet = cs.get("code_snippet", "")
            lines.append(f"**{f_name}**")
            if desc:
                lines.append(f"> {desc}")
            lines.append(f"```")
            lines.append(snippet)
            lines.append(f"```")
            lines.append(f"")

    if impl_strategy:
        lines.append(f"### 📋 Implementation Strategy")
        for step_idx, step in enumerate(impl_strategy, 1):
            lines.append(f"{step_idx}. {step}")
        lines.append(f"")

    if testing_recs:
        lines.append(f"### 🧪 Testing & Verification Recommendations")
        for tr in testing_recs:
            lines.append(f"- [ ] {tr}")
        lines.append(f"")

    if risk_assessment:
        lines.append(f"### ⚠️ Risk Assessment")
        lines.append(f"{risk_assessment}")
        lines.append(f"")

    lines.extend([
        f"---",
        f"*Automated pull request safely gated by BugSense AI Confidence Engine (v0.18.0).* 🛡️",
    ])

    return "\n".join(lines)

