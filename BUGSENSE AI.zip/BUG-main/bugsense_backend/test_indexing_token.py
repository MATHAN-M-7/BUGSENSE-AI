"""Verify indexing token propagation fix (updated for auth_guard)."""
import httpx
import asyncio
import ast
import sys
import os

sys.path.insert(0, r"d:\BUG\bugsense_backend")

async def main():
    print("=" * 60)
    print("INDEXING TOKEN PROPAGATION — VERIFICATION")
    print("=" * 60)

    # Test 1: Health
    print("\n=== TEST 1: Health ===")
    async with httpx.AsyncClient() as c:
        r = await c.get("http://127.0.0.1:8000/health")
        assert r.status_code == 200
        print(f"Status: {r.status_code} -> PASS")

    # Test 2: require_auth resolves session token for indexing
    print("\n=== TEST 2: require_auth resolves session for indexing ===")
    from services import session_store
    from services.auth_guard import require_auth

    tok = session_store.create_session(
        github_user_id=111111,
        github_login="indexing_test_user",
        github_access_token="gho_INDEX_TEST_77",
        ttl_seconds=60,
    )
    user = require_auth(f"Bearer {tok}")
    assert user.github_token == "gho_INDEX_TEST_77", f"Got {user.github_token}"
    print("Session resolution: OK")

    # Test: No header → 401
    from fastapi import HTTPException
    try:
        require_auth(None)
        assert False, "Should have raised 401"
    except HTTPException as e:
        assert e.status_code == 401
    print("No header -> 401: OK")

    session_store.delete_session(tok)
    print("PASS")

    # Test 3: POST /repos/index requires Authorization header (returns 401 without)
    print("\n=== TEST 3: POST /repos/index requires Authorization ===")
    payload = {"owner": "test", "repo": "test", "max_issues": 1}
    async with httpx.AsyncClient(timeout=5.0) as c:
        r = await c.post("http://127.0.0.1:8000/repos/index", json=payload)
        assert r.status_code == 401, f"Expected 401 without auth, got {r.status_code}"
        print(f"Status without auth: {r.status_code} (401 as expected)")

    # With valid session
    tok2 = session_store.create_session(
        github_user_id=222222,
        github_login="index_ep_test",
        github_access_token="gho_EP_INDEX_88",
        ttl_seconds=60,
    )
    headers = {"Authorization": f"Bearer {tok2}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=5.0) as c:
        try:
            r = await c.post("http://127.0.0.1:8000/repos/index", json=payload, headers=headers)
            assert r.status_code != 401, f"Got 401 with valid session"
            assert r.status_code != 422, f"Got 422 -- Authorization header not accepted!"
            print(f"Status with auth: {r.status_code} (Authorization accepted)")
        except httpx.TimeoutException:
            print("TIMEOUT (endpoint exists, header accepted)")
    session_store.delete_session(tok2)
    print("PASS")

    # Test 4: Static AST inspection
    print("\n=== TEST 4: Static Code Inspection ===")
    with open(r"d:\BUG\bugsense_backend\routers\indexing.py") as f:
        tree = ast.parse(f.read())
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "trigger_indexing":
            arg_names = [a.arg for a in node.args.args]
            has_auth = "authorization" in arg_names
            calls_require_auth = any(
                isinstance(child, ast.Call)
                and isinstance(child.func, ast.Name)
                and child.func.id == "require_auth"
                for child in ast.walk(node)
            )
            print(f"trigger_indexing: authorization={has_auth}, calls_require_auth={calls_require_auth}")
            assert has_auth and calls_require_auth
    print("PASS")

    # Test 5: Verify repo_indexer passes token through
    print("\n=== TEST 5: repo_indexer token propagation (static) ===")
    with open(r"d:\BUG\bugsense_backend\services\repo_indexer.py") as f:
        src = f.read()
    assert "token: str | None = None" in src, "index_repository missing token param"
    print("index_repository accepts token: OK")
    assert "token=token" in src
    print("token passed to downstream calls: OK")
    assert "github_user_id" in src
    print("github_user_id propagation: OK")
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED")
    print("=" * 60)

asyncio.run(main())
