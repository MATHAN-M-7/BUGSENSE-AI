"""
Test script for the GitHub API integration.

Usage:
  1. Set GITHUB_TOKEN in .env (or environment)
  2. Start the server:  uvicorn main:app --port 8000
  3. Run this script:   python test_github.py

Tests every /github/* endpoint and prints results.
"""

import sys
import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, method: str, url: str, expect_status: int = 200):
    """Fire one request, print pass/fail, return the JSON body."""
    print(f"\n{'='*60}")
    print(f"TEST: {label}")
    print(f"  {method} {url}")
    r = httpx.request(method, url, timeout=30.0)
    ok = r.status_code == expect_status
    tag = "PASS" if ok else "FAIL"
    print(f"  Status: {r.status_code}  [{tag}]")
    if not ok:
        print(f"  Expected: {expect_status}")
        print(f"  Body: {r.text[:300]}")
    return ok, r.json() if r.status_code < 500 else {}


def main():
    results = []

    # --- 0. Health (Phase 1 — must still work) ---
    ok, data = test("Phase 1 health check", "GET", f"{BASE}/health")
    results.append(("Health check", ok))
    if ok:
        print(f"  version={data.get('version')}")

    # --- 1. Authenticated user ---
    ok, data = test("Authenticated GitHub user", "GET", f"{BASE}/github/user")
    results.append(("GitHub user", ok))
    if ok:
        login = data.get("login", "?")
        print(f"  login={login}")
    else:
        print("  ⚠️  Cannot continue without a valid token. Aborting.")
        _summary(results)
        sys.exit(1)

    # --- 2. List repos ---
    ok, data = test("List repos (page 1, 5 per page)", "GET",
                     f"{BASE}/github/repos?per_page=5&page=1")
    results.append(("List repos", ok))
    if ok and isinstance(data, list):
        for r in data[:3]:
            print(f"    - {r.get('full_name')}")

    # Pick the first repo, or fallback to octocat/Hello-World if user has 0 repos
    if ok and data:
        owner = data[0]["owner"]["login"]
        repo_name = data[0]["name"]
        print(f"  Using user repository: {owner}/{repo_name}")
    else:
        owner, repo_name = "octocat", "Hello-World"
        print(f"  User has 0 repositories. Testing with public repository: {owner}/{repo_name}")

    # --- 3. Repo details ---
    ok, data = test("Repo details", "GET",
                     f"{BASE}/github/repos/{owner}/{repo_name}")
    results.append(("Repo details", ok))
    if ok:
        print(f"  description={data.get('description', '(none)')}")
        print(f"  stars={data.get('stargazers_count')}")

    # --- 4. List issues ---
    ok, data = test("List issues", "GET",
                     f"{BASE}/github/repos/{owner}/{repo_name}/issues?state=all&per_page=10")
    results.append(("List issues", ok))
    issue_number = None
    if ok and isinstance(data, list) and data:
        # Prefer an issue that has comments if possible
        issues_with_comments = [i for i in data if i.get("comments", 0) > 0]
        issue_to_test = issues_with_comments[0] if issues_with_comments else data[0]
        issue_number = issue_to_test.get("number")
        for i in data[:3]:
            print(f"    #{i.get('number')} - {i.get('title')}")

    # --- 5. Issue details ---
    if issue_number:
        ok, data = test("Issue details", "GET",
                         f"{BASE}/github/repos/{owner}/{repo_name}/issues/{issue_number}")
        results.append(("Issue details", ok))
        if ok:
            print(f"  title={data.get('title')}")
            print(f"  state={data.get('state')}")

        # --- 6. Issue comments ---
        ok, data = test("Issue comments", "GET",
                         f"{BASE}/github/repos/{owner}/{repo_name}/issues/{issue_number}/comments?per_page=5")
        results.append(("Issue comments", ok))
        if ok and isinstance(data, list):
            print(f"  comment_count={len(data)}")
            for c in data[:2]:
                user_login = c.get("user", {}).get("login") if isinstance(c.get("user"), dict) else "?"
                print(f"    - @{user_login}: {c.get('body', '')[:60]}")
    else:
        print("\n  [!] No issues found - skipping issue detail / comment tests.")

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for _, ok in results if ok)
    total = len(results)
    for name, ok in results:
        print(f"  {'[PASS]' if ok else '[FAIL]'} {name}")
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All GitHub API tests passed!")
    else:
        print("  Some tests failed.")


if __name__ == "__main__":
    main()
