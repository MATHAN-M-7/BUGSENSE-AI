"""
Automated tests for Complexity Analyzer in BugSense Backend.

Tests:
1. Pure unit tests for analyze_complexity across all 7 signals.
2. Stack trace detection (Python, Java, JS, Go).
3. Referenced files detection.
4. Complexity levels (Low, Medium, High, Critical).
5. POST /analysis/complexity endpoint validation.
"""

import sys
import httpx
from services.complexity_analyzer import analyze_complexity, DEFAULT_WEIGHTS

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Complexity Analyzer")
    print(f"{'='*60}")

    results = []

    # ─── 1. Unit Tests: Basic Issue ───
    print("\n-- 1. Unit: Simple Issue Scoring --")
    simple_issue = {
        "title": "Fix typo in readme",
        "body": "Small typo in README.md",
        "labels": ["documentation"],
    }
    res = analyze_complexity(simple_issue)
    results.append(test(
        "Simple issue has complexity_score between 0.0 and 1.0",
        0.0 <= res["complexity_score"] <= 1.0,
        f"score={res['complexity_score']}",
    ))
    results.append(test(
        "Simple issue has Low or Medium level",
        res["complexity_level"] in ("Low", "Medium"),
        f"level={res['complexity_level']}",
    ))
    results.append(test(
        "All 7 signals present in result",
        len(res["signals"]) == 7,
        f"signals={list(res['signals'].keys())}",
    ))

    # ─── 2. Unit Tests: Stack Trace Detection ───
    print("\n-- 2. Unit: Stack Trace & File Extraction --")
    complex_issue = {
        "title": "Fatal crash in AuthManager",
        "body": (
            "Exception occurred:\n"
            "Traceback (most recent call last):\n"
            "  File \"auth/manager.py\", line 142, in login\n"
            "    user = db.query(User).filter_by(email=email).one()\n"
            "NullPointerException: user is null\n"
            "Also affects services/auth_service.py and models/user.py"
        ),
        "labels": ["bug", "crash"],
    }
    c_res = analyze_complexity(complex_issue)
    results.append(test(
        "Stack trace detected",
        c_res["signals"]["stack_trace_present"]["score"] > 0,
        f"stack_trace_score={c_res['signals']['stack_trace_present']['score']}",
    ))
    results.append(test(
        "Referenced files identified",
        c_res["signals"]["referenced_files"]["score"] > 0,
        f"files_score={c_res['signals']['referenced_files']['score']}",
    ))
    results.append(test(
        "Complex issue scores higher than simple issue",
        c_res["complexity_score"] > res["complexity_score"],
        f"complex={c_res['complexity_score']} > simple={res['complexity_score']}",
    ))

    # ─── 3. Unit Tests: RAG Ambiguity ───
    print("\n-- 3. Unit: Retrieval Ambiguity Signal --")
    sim_high = [{"similarity": 0.95}, {"similarity": 0.92}]
    res_high_sim = analyze_complexity(simple_issue, similar_issues=sim_high)
    res_no_sim = analyze_complexity(simple_issue, similar_issues=[])
    results.append(test(
        "High similarity reduces retrieval ambiguity score",
        res_high_sim["signals"]["retrieval_ambiguity"]["score"] <= res_no_sim["signals"]["retrieval_ambiguity"]["score"],
        f"high_sim={res_high_sim['signals']['retrieval_ambiguity']['score']} <= no_sim={res_no_sim['signals']['retrieval_ambiguity']['score']}",
    ))

    # ─── 4. API Endpoint Tests ───
    print("\n-- 4. API Endpoint: POST /analysis/complexity --")
    try:
        payload = {
            "repo_owner": "octocat",
            "repo_name": "Hello-World",
            "title": "NullPointerException on startup",
            "body": "App crashes at startup with NullPointerException in Main.java:42",
        }
        r = httpx.post(f"{BASE}/analysis/complexity", json=payload, timeout=10.0)
        results.append(test("POST /analysis/complexity returns 200", r.status_code == 200))
        if r.status_code == 200:
            data = r.json()
            results.append(test("API returns complexity_score", "complexity_score" in data and isinstance(data["complexity_score"], (int, float))))
            results.append(test("API returns complexity_level", data.get("complexity_level") in ("Low", "Medium", "High", "Critical")))
            results.append(test("API returns signals dict", isinstance(data.get("signals"), dict)))
    except Exception as e:
        results.append(test("API endpoint check failed", False, str(e)))

    # ─── Summary ───
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'='*60}")
    print(f"COMPLEXITY TEST SUMMARY: {passed}/{total} passed")
    print(f"{'='*60}")
    if passed < total:
        sys.exit(1)


if __name__ == "__main__":
    main()
