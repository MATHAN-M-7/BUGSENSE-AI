"""
Test suite for Phase 4 Milestone 8: GitHub Branch and PR Engine.
Verifies:
1. build_pr_markdown publication-grade template generator
2. GET /github/repos/{owner}/{repo}/issues/{issue_number}/pr endpoint
3. POST /github/repos/{owner}/{repo}/issues/{issue_number}/generate-pr endpoint lifecycle
4. Safe PR Gate integration & human approval override
"""

from fastapi.testclient import TestClient

from main import app
from services import github_service as gh

client = TestClient(app)

passed = 0
failed = 0


def ok(name: str, details: str = ""):
    global passed
    passed += 1
    d = f" -- {details}" if details else ""
    print(f"  [PASS] {name}{d}")


def fail(name: str, details: str = ""):
    global failed
    failed += 1
    d = f" -- {details}" if details else ""
    print(f"  [FAIL] {name}{d}")


# ──────────────────────────────────────────────
# Test Cases
# ──────────────────────────────────────────────

def test_api_version():
    r = client.get("/health")
    v = r.json().get("version")
    if v == "0.18.0":
        ok("Health check", f"status=ok, version={v}")
    else:
        fail("Health check version", f"Expected 0.18.0, got {v}")


def test_build_pr_markdown_template():
    mock_routing_result = {
        "issue_title": "NullPointerException in ImageDownloader",
        "route": "STANDARD",
        "route_plan": {
            "route": "STANDARD",
            "complexity_score": 0.45,
            "rationale": "Moderate defect requires standard multi-agent pipeline",
        },
        "system_confidence_report": {
            "system_confidence": 0.895,
            "system_status": "READY_FOR_PR",
            "confidence_breakdown": {
                "llm_self_confidence": 0.92,
                "evidence_validator_score": 0.90,
                "rag_avg_similarity": 0.80,
                "inverse_complexity": 0.55,
            },
            "penalties_applied": ["Minor penalty: Slight RAG ambiguity (-5%)"],
        },
        "evidence_report": {
            "verdict": "SUFFICIENT",
            "evidence_score": 0.90,
            "verified_claims": [
                "ImageDownloader crashes on line 42",
                "Asset URL is null in offline mode",
            ],
            "unverified_claims": [],
            "recommendations": ["Verify offline mode handling"],
        },
        "resolution": {
            "fix_description": "Add null check before accessing bitmap decoder",
            "code_suggestions": [
                {
                    "file_or_component": "ImageDownloader.java",
                    "explanation": "Guards against null asset dereference",
                    "code_snippet": "if (asset == null) {\n    return null;\n}",
                }
            ],
            "implementation_strategy": [
                "Guard asset parameter",
                "Add unit test for null URL",
            ],
            "testing_recommendations": [
                "Test offline mode with null URL",
                "Verify bitmap decoding remains functional",
            ],
            "risk_assessment": "Low risk. Null checks preserve existing behavior for valid URLs.",
        },
    }

    body = gh.build_pr_markdown(
        owner="testorg",
        repo="testrepo",
        issue_number=101,
        issue_title="NullPointerException in ImageDownloader",
        routing_result=mock_routing_result,
    )

    # Verifications
    assert "Resolves #101" in body, "PR body should reference Resolves #101"
    assert "Confidence Engine Audit" in body, "Should have Confidence Engine Audit section"
    assert "89%" in body or "0.895" in body, "Should display confidence score"
    assert "READY_FOR_PR" in body, "Should display system status"
    assert "Deterministic Evidence Score" in body, "Should display evidence score"
    assert "SUFFICIENT" in body, "Should display evidence verdict"
    assert "Minor penalty: Slight RAG ambiguity" in body, "Should display penalties"
    assert "ImageDownloader crashes on line 42" in body, "Should list verified assertions"
    assert "ImageDownloader.java" in body, "Should list code suggestions"
    assert "Testing & Verification Recommendations" in body, "Should have testing recommendations"
    assert "- [ ] Test offline mode with null URL" in body, "Should have checklist format"
    assert "Risk Assessment" in body, "Should have risk assessment section"
    assert "BugSense AI" in body, "Should have attribution"

    ok("build_pr_markdown template complete", f"length={len(body)} chars")


def test_get_issue_pr_endpoint_no_pr():
    # Test inquiring about an issue where no PR has been opened yet
    # Under test client without real GitHub credentials, this handles gracefully or 500/404
    r = client.get("/github/repos/testorg/testrepo/issues/999/pr")
    if r.status_code in (200, 500):
        # 200 = checked and returned has_pr: False, or 500 = mock github token unreachable
        ok("GET /github/repos/{owner}/{repo}/issues/{issue_number}/pr reachable", f"status={r.status_code}")
    else:
        fail("GET /github/repos/.../pr unexpected status", f"status={r.status_code}")


def test_generate_pr_gate_blocks_low_confidence():
    payload = {
        "issue_title": "Vague defect",
        "system_confidence_report": {
            "system_status": "LOW_CONFIDENCE",
            "system_confidence": 0.32,
            "penalties_applied": ["Heavy penalty: INSUFFICIENT evidence (-50%)"],
        },
        "resolution": {
            "fix_description": "Unverified guess",
            "code_suggestions": [
                {"file_or_component": "unknown.py", "code_snippet": "# todo"}
            ],
        },
    }
    r = client.post("/github/repos/testorg/testrepo/issues/50/generate-pr", json=payload)
    if r.status_code == 403:
        detail = r.json().get("detail", {})
        if detail.get("system_status") == "LOW_CONFIDENCE":
            ok("generate_pr strictly rejected LOW_CONFIDENCE with 403", f"status={detail.get('system_status')}")
        else:
            fail("generate_pr rejected but wrong detail", str(detail))
    else:
        fail("generate_pr did not block LOW_CONFIDENCE", f"status={r.status_code}")


def test_generate_pr_human_approval_signoff():
    payload = {
        "issue_title": "Moderate defect",
        "system_confidence_report": {
            "system_status": "REQUIRES_HUMAN_REVIEW",
            "system_confidence": 0.72,
        },
        "resolution": {
            "fix_description": "Refactor parser",
            "code_suggestions": [
                {"file_or_component": "parser.py", "code_snippet": "def fix(): pass"}
            ],
        },
    }

    # 1. Without approval -> should block 403
    r1 = client.post("/github/repos/testorg/testrepo/issues/51/generate-pr", json=payload)
    assert r1.status_code == 403, f"Expected 403, got {r1.status_code}"
    ok("generate_pr blocked REQUIRES_HUMAN_REVIEW without human approval")

    # 2. With human_approved=true -> should pass gate (proceeds to GitHub API call)
    r2 = client.post("/github/repos/testorg/testrepo/issues/51/generate-pr?human_approved=true", json=payload)
    if r2.status_code != 403:
        ok("generate_pr authorized by human review passed gate", f"status={r2.status_code}")
    else:
        fail("generate_pr failed to honor human_approved=true", f"status={r2.status_code}")


def test_generate_pr_ready_for_pr_passes_gate():
    payload = {
        "issue_title": "Deterministic crash",
        "system_confidence_report": {
            "system_status": "READY_FOR_PR",
            "system_confidence": 0.93,
        },
        "resolution": {
            "fix_description": "Clear deterministic fix",
            "code_suggestions": [
                {"file_or_component": "main.py", "code_snippet": "return True"}
            ],
        },
    }
    r = client.post("/github/repos/testorg/testrepo/issues/52/generate-pr", json=payload)
    if r.status_code != 403:
        ok("generate_pr READY_FOR_PR passed confidence gate", f"status={r.status_code}")
    else:
        fail("generate_pr READY_FOR_PR rejected by gate", f"status={r.status_code}")


if __name__ == "__main__":
    print("============================================================")
    print("  BugSense AI -- Phase 4: GitHub Branch & PR Engine Tests")
    print("============================================================")

    test_api_version()
    test_build_pr_markdown_template()
    test_get_issue_pr_endpoint_no_pr()
    test_generate_pr_gate_blocks_low_confidence()
    test_generate_pr_human_approval_signoff()
    test_generate_pr_ready_for_pr_passes_gate()

    print("\n============================================================")
    print(f"  Results: {passed} passed, {failed} failed, 0 skipped")
    print("============================================================")

    if failed > 0:
        exit(1)
