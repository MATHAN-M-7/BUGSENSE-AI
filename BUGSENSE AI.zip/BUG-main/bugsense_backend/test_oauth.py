"""
Automated tests for GitHub OAuth 2.0 implementation in BugSense Backend.

Tests:
1. OAuth URL generation & parameter structure (using auth_service).
2. GET /auth/github/login endpoint behavior.
3. GET /auth/github/callback error handling (e.g. access_denied).
4. POST /auth/github/exchange error handling (e.g. invalid code).
5. Optional Bearer token extraction in /github/user.
"""

import os
import sys
from urllib.parse import parse_qs, urlparse

import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense GitHub OAuth 2.0")
    print(f"{'='*60}")

    results = []

    # 1. Test unit URL generation directly via auth_service with test client_id
    os.environ["GITHUB_CLIENT_ID"] = "test_client_id_123"
    os.environ["GITHUB_CLIENT_SECRET"] = "test_client_secret_456"
    os.environ["GITHUB_REDIRECT_URI"] = "http://localhost:8000/auth/github/callback"

    from services import auth_service

    auth_url, state = auth_service.create_authorization_url()
    parsed = urlparse(auth_url)
    params = parse_qs(parsed.query)

    is_valid_url = (
        parsed.scheme == "https"
        and parsed.netloc == "github.com"
        and parsed.path == "/login/oauth/authorize"
        and params.get("client_id") == ["test_client_id_123"]
        and params.get("scope") == ["repo,read:user"]
        and params.get("state") == [state]
        and bool(state)
    )
    results.append(
        test(
            "auth_service.create_authorization_url() format",
            is_valid_url,
            f"URL: {auth_url[:50]}... state={state[:8]}...",
        )
    )

    # 2. Test GET /auth/github/login via running server
    r = httpx.get(f"{BASE}/auth/github/login")
    login_ok = r.status_code in (200, 500)
    # If GITHUB_CLIENT_ID isn't set in server process .env, it should return 500 with descriptive detail
    if r.status_code == 200:
        data = r.json()
        has_fields = "auth_url" in data and "state" in data
        results.append(
            test("GET /auth/github/login returns auth_url & state", has_fields, f"Keys: {list(data.keys())}")
        )
    else:
        err_detail = r.json().get("detail", "")
        is_descriptive = "GITHUB_CLIENT_ID" in err_detail
        results.append(
            test(
                "GET /auth/github/login gracefully detects missing client ID",
                is_descriptive,
                f"Detail: {err_detail[:60]}...",
            )
        )

    # 3. Test GET /auth/github/callback with GitHub error response
    r = httpx.get(
        f"{BASE}/auth/github/callback",
        params={"error": "access_denied", "error_description": "The user has denied your request"},
    )
    callback_err_handled = r.status_code == 400 and "denied" in r.text
    results.append(
        test(
            "GET /auth/github/callback handles authorization denials",
            callback_err_handled,
            f"Status: {r.status_code}",
        )
    )

    # 4. Test GET /auth/github/callback without code
    r = httpx.get(f"{BASE}/auth/github/callback")
    missing_code_handled = r.status_code == 400 and "code" in r.text.lower()
    results.append(
        test(
            "GET /auth/github/callback requires 'code' parameter",
            missing_code_handled,
            f"Status: {r.status_code}",
        )
    )

    # 5. Test POST /auth/github/exchange with invalid test code
    r = httpx.post(
        f"{BASE}/auth/github/exchange",
        json={"code": "invalid_test_code_999", "state": "test_state"},
    )
    # Should reject gracefully with 400/500/502 rather than crashing
    exchange_handled = r.status_code in (400, 500, 502)
    results.append(
        test(
            "POST /auth/github/exchange handles invalid codes safely",
            exchange_handled,
            f"Status: {r.status_code}",
        )
    )

    # 6. Verify existing endpoints remain operational with optional user token support
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    health_ok = r.status_code == 200 and bool(version)
    results.append(test(f"GET /health responds with version {version}", health_ok))

    # Summary
    print(f"\n{'='*60}")
    print("OAUTH TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"  {passed}/{total} passed")
    if passed == total:
        print("  All OAuth tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
