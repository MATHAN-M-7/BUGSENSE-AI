"""
Automated tests for Repository Indexing in BugSense Backend.

Tests:
1. Health check regression (v0.7.0).
2. POST /repos/index triggers indexing (with real repo, max_issues=3).
3. Response contains summary with breakdowns.
4. Each classified issue has valid schema.
5. GET /repos/{owner}/{repo}/index retrieves stored index.
6. GET /repos/{owner}/{repo}/index/issues lists classified issues.
7. GET /repos/indexed lists indexed repositories.
8. Graceful 503 when GEMINI_API_KEY is not set.

Requires: FastAPI server running on localhost:8000.
If GEMINI_API_KEY is set, tests exercise full AI classification pipeline.
"""

import sys
import httpx

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

BASE = "http://localhost:8000"

VALID_CATEGORIES = {"Bug", "Feature", "Enhancement", "Documentation", "Other"}
VALID_SEVERITIES = {"Critical", "High", "Medium", "Low"}


def test(label: str, passed: bool, detail: str = ""):
    tag = "[PASS]" if passed else "[FAIL]"
    print(f"  {tag} {label}")
    if detail:
        print(f"         {detail}")
    return passed


def main():
    print(f"\n{'='*60}")
    print("TEST SUITE: BugSense Repository Indexing")
    print(f"{'='*60}")

    results = []

    # --- 0. Health check ---
    print("\n-- Regression --")
    r = httpx.get(f"{BASE}/health")
    version = r.json().get("version", "")
    health_ok = r.status_code == 200 and bool(version)
    results.append(test(f"GET /health returns version {version}", health_ok))

    # --- 1. Trigger indexing ---
    print("\n-- Repository Indexing --")
    index_payload = {
        "owner": "octocat",
        "repo": "Hello-World",
        "max_issues": 3,
    }
    print("  Triggering indexing (octocat/Hello-World, max_issues=3)...")
    r = httpx.post(f"{BASE}/repos/index", json=index_payload, timeout=120.0)

    if r.status_code == 503:
        detail = r.json().get("detail", "")
        gemini_missing = "GEMINI_API_KEY" in detail
        results.append(test(
            "POST /repos/index returns 503 when Gemini is unconfigured",
            gemini_missing,
            f"Detail: {detail[:80]}...",
        ))
        results.append(test("Indexing tests skipped (no API key)", True, "Expected"))

        # Still test the read endpoints
        print("\n-- Read Endpoints (No Index Data) --")
        r = httpx.get(f"{BASE}/repos/indexed")
        results.append(test(
            "GET /repos/indexed returns 200",
            r.status_code == 200,
        ))

        r = httpx.get(f"{BASE}/repos/octocat/Hello-World/index/issues")
        results.append(test(
            "GET /repos/octocat/Hello-World/index/issues returns 200",
            r.status_code == 200,
        ))

        _summary(results)
        return

    index_ok = r.status_code == 200
    results.append(test("POST /repos/index returns 200", index_ok, f"status={r.status_code}"))

    if not index_ok:
        print(f"    Response: {r.status_code} {r.text[:300]}")
        _summary(results)
        return

    data = r.json()

    # --- 2. Validate summary ---
    print("\n-- Summary Validation --")
    summary = data.get("summary", {})

    results.append(test(
        "Summary contains owner",
        summary.get("owner") == "octocat",
        f"owner={summary.get('owner')}",
    ))
    results.append(test(
        "Summary contains repo",
        summary.get("repo") == "Hello-World",
        f"repo={summary.get('repo')}",
    ))
    results.append(test(
        "Summary contains total_issues",
        isinstance(summary.get("total_issues"), int) and summary["total_issues"] > 0,
        f"total_issues={summary.get('total_issues')}",
    ))
    results.append(test(
        "Summary contains classified count",
        isinstance(summary.get("classified"), int) and summary["classified"] > 0,
        f"classified={summary.get('classified')}",
    ))
    results.append(test(
        "Summary has category_breakdown",
        isinstance(summary.get("category_breakdown"), dict) and len(summary["category_breakdown"]) > 0,
        f"categories={summary.get('category_breakdown')}",
    ))
    results.append(test(
        "Summary has severity_breakdown",
        isinstance(summary.get("severity_breakdown"), dict) and len(summary["severity_breakdown"]) > 0,
        f"severities={summary.get('severity_breakdown')}",
    ))
    results.append(test(
        "Summary status is completed/partial",
        summary.get("status") in ("completed", "partial"),
        f"status={summary.get('status')}",
    ))

    # Validate category breakdown keys
    cat_keys = set(summary.get("category_breakdown", {}).keys())
    results.append(test(
        "All category_breakdown keys are valid",
        cat_keys.issubset(VALID_CATEGORIES),
        f"keys={cat_keys}",
    ))

    sev_keys = set(summary.get("severity_breakdown", {}).keys())
    results.append(test(
        "All severity_breakdown keys are valid",
        sev_keys.issubset(VALID_SEVERITIES),
        f"keys={sev_keys}",
    ))

    # --- 3. Validate classified issues ---
    print("\n-- Classified Issues --")
    issues = data.get("issues", [])
    results.append(test(
        "Response contains classified issues",
        isinstance(issues, list) and len(issues) > 0,
        f"count={len(issues)}",
    ))

    if issues:
        first = issues[0]
        results.append(test(
            "Issue has category",
            first.get("category") in VALID_CATEGORIES,
            f"category={first.get('category')}",
        ))
        results.append(test(
            "Issue has severity",
            first.get("severity") in VALID_SEVERITIES,
            f"severity={first.get('severity')}",
        ))
        results.append(test(
            "Issue has evidence_summary",
            isinstance(first.get("evidence_summary"), str) and len(first["evidence_summary"]) > 10,
            f"evidence={first.get('evidence_summary', '')[:60]}...",
        ))
        results.append(test(
            "Issue has repo metadata",
            first.get("repo_owner") == "octocat" and first.get("repo_name") == "Hello-World",
        ))

    # --- 4. Read endpoints ---
    print("\n-- Read Endpoints --")

    r = httpx.get(f"{BASE}/repos/indexed")
    results.append(test(
        "GET /repos/indexed returns 200",
        r.status_code == 200,
        f"count={r.json().get('count', 0)}",
    ))

    r = httpx.get(f"{BASE}/repos/octocat/Hello-World/index/issues")
    results.append(test(
        "GET /repos/octocat/Hello-World/index/issues returns 200",
        r.status_code == 200,
        f"count={r.json().get('count', 0)}",
    ))

    # Try to get stored index (may fail if no Firestore)
    r = httpx.get(f"{BASE}/repos/octocat/Hello-World/index")
    if r.status_code == 200:
        stored = r.json()
        results.append(test(
            "GET /repos/octocat/Hello-World/index returns stored summary",
            stored.get("owner") == "octocat",
            f"classified={stored.get('classified')}",
        ))
    else:
        results.append(test(
            "Stored index unavailable (no Firestore)",
            r.status_code == 404,
            "Expected without Firestore",
        ))

    _summary(results)


def _summary(results):
    print(f"\n{'='*60}")
    print("INDEXING TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for ok in results if ok)
    total = len(results)
    print(f"\n  {passed}/{total} passed")
    if passed == total:
        print("  All indexing tests passed!\n")
    else:
        print("  Some tests failed.\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
