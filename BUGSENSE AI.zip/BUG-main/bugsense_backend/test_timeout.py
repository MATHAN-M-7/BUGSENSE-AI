from google import genai
import inspect
print(inspect.signature(genai.Client))
client = genai.Client(api_key="fake_key", http_options={"timeout": 60000})
print("timeout in api_client:", getattr(client._api_client, "timeout", "Not found"))
print("timeout in httpx:", getattr(client._api_client.sync_client, "timeout", "Not found"))
