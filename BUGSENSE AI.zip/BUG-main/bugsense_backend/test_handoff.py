import os
import time
from cryptography.fernet import Fernet
from services import session_store
from services.redis_client import set_redis_client, reset_redis_client
from test_durable_session import MockPostgresPool

if not os.getenv("SESSION_ENCRYPTION_KEY"):
    os.environ["SESSION_ENCRYPTION_KEY"] = Fernet.generate_key().decode()

class MockRedis:
    def __init__(self):
        self.store = {}
    def set(self, name: str, value: str, ex: int | None = None):
        self.store[name] = (value, time.time() + (ex or 0))
        return True
    def getdel(self, name: str):
        if name not in self.store:
            return None
        val, exp = self.store.pop(name)
        if exp and time.time() > exp:
            return None
        return val

def run_tests():
    print("Testing session store callback handoff logic with Redis...")
    mock_pool = MockPostgresPool()
    session_store.set_db_pool(mock_pool)
    mock_redis = MockRedis()
    set_redis_client(mock_redis)
    
    # 1. Create a mock session
    session_id = session_store.create_session(
        github_user_id=12345,
        github_login="testuser",
        github_access_token="gho_test_token123",
        github_avatar_url="https://example.com/avatar.jpg",
        github_name="Test User"
    )
    print(f"Created session: {session_id}")
    
    # 2. Test valid code exchange
    handoff_code1 = session_store.create_handoff_code(session_id)
    print(f"Created handoff code 1: {handoff_code1}")
    exchanged_token = session_store.exchange_handoff_code(handoff_code1)
    if exchanged_token == session_id:
        print("[PASS] Valid code exchange passed")
    else:
        print("[FAIL] Valid code exchange failed")
        
    # 3. Test single-use
    exchanged_token_again = session_store.exchange_handoff_code(handoff_code1)
    if exchanged_token_again is None:
        print("[PASS] Single-use code test passed")
    else:
        print("[FAIL] Single-use code test failed")
        
    # 4. Test invalid code
    invalid_token = session_store.exchange_handoff_code("invalid_code_123")
    if invalid_token is None:
        print("[PASS] Invalid code test passed")
    else:
        print("[FAIL] Invalid code test failed")
        
    # 5. Test expiry
    handoff_code2 = session_store.create_handoff_code(session_id)
    # simulate key expiry in Redis
    val, _ = mock_redis.store[f"handoff_code:{handoff_code2}"]
    mock_redis.store[f"handoff_code:{handoff_code2}"] = (val, time.time() - 10)
        
    expired_token = session_store.exchange_handoff_code(handoff_code2)
    if expired_token is None:
        print("[PASS] Code expiry test passed")
    else:
        print("[FAIL] Code expiry test failed")
        
    # 6. Test existing session retrieval and logout
    retrieved = session_store.get_session(session_id)
    if retrieved and retrieved["github_login"] == "testuser":
        print("[PASS] Existing session retrieval passed")
    else:
        print("[FAIL] Existing session retrieval failed")
        
    deleted = session_store.delete_session(session_id)
    if deleted:
        print("[PASS] Existing logout test passed")
    else:
        print("[FAIL] Existing logout test failed")
        
    reset_redis_client()

if __name__ == "__main__":
    run_tests()
